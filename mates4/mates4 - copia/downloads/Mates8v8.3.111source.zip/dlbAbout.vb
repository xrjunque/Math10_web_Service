﻿Imports System.Windows.Forms

Public Class dlbAbout

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub


    Private Sub dlbAbout_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblVersion.Text = "v" + System.Windows.Forms.Application.ProductVersion + _
        " (" + getBuildDate() + ")"

    End Sub

#Region "GetbuildDate"
    Function getBuildDate() As String
        Dim e1 As String = ""
        Try
            Dim filePath As String = System.Reflection.Assembly.GetCallingAssembly().Location
            Const c_PeHeaderOffset As Int32 = 60
            Const c_LinkerTimestampOffset As Int32 = 8
            Dim b(2048) As Byte
            Dim s As System.IO.Stream = Nothing
            Try
                s = New System.IO.FileStream(filePath, System.IO.FileMode.Open, System.IO.FileAccess.Read)
                s.Read(b, 0, 2048)

            Catch ex As Exception
            Finally
                If s IsNot Nothing Then
                    s.Close()
                    Dim i As Int32 = System.BitConverter.ToInt32(b, c_PeHeaderOffset)
                    Dim secondsSince1970 As Int32 = System.BitConverter.ToInt32(b, i + c_LinkerTimestampOffset)
                    Dim dt As New DateTime(1970, 1, 1, 0, 0, 0)
                    dt = dt.AddSeconds(secondsSince1970)
                    dt = dt.AddHours(TimeZone.CurrentTimeZone.GetUtcOffset(dt).Hours)
                    e1 = String.Format("{0}/{1}/{2}", dt.Year, dt.Month, dt.Day)
                    'return dt
                End If
            End Try
        Catch ex2 As Exception

        End Try
        Return e1
    End Function
#End Region

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start(LinkLabel1.Text)
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        System.Diagnostics.Process.Start(LinkLabel2.Text) ' swDownload
    End Sub

    Private Sub lblVersion_Click(sender As System.Object, e As System.EventArgs) Handles lblVersion.Click

    End Sub

    Private Sub Label2_Click(sender As System.Object, e As System.EventArgs) Handles Label2.Click

    End Sub
End Class
