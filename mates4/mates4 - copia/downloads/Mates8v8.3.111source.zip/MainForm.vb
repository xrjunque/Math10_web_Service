﻿Imports System.Reflection
Imports System.Text.RegularExpressions
Imports System.IO


Public Class MainForm

#Region "Dims"
    Dim curFileName As String = ""
    Dim bLoaded As Boolean
    Dim n As Int32 = 1
    Public wb As C_WebBrowser
    Dim factor As Single = 1.0
    Dim iCurGo2, lstGo2 As Int32
    Dim vN(-1) As Int32
    Dim sTbVar(-1) As String
    Dim sTbQry(-1), vsResultGo2(-1) As String
    Dim mP As New matrixParser
    Dim cfg As New Config
    Dim oVars As VarsAndFns
    Dim oldsVar As String
    Dim mtx As New System.Threading.Mutex()
    Dim sComments() As String
    Dim vNames() As String, vValues() As Double
    Dim th As System.Threading.Thread

#End Region

#Region "form events"


    Private Sub Form1_Load(ByVal sender As Object, _
                ByVal e As System.EventArgs) Handles Me.Load
        Try
            bLoaded = False
            Me.Text = MathGlobal8.NameAndVersion


            populateFnsAndConstants()

            cbTimeout.SelectedIndex = 0
            updateStatusBar("")
            wb = New C_WebBrowser(WebBrowser1)
            Try
                My.Settings.Reload()
                parseOptions(My.Settings.Options)
            Catch ex As Exception

            End Try
            bLoaded = True
            Me.KeyPreview = True

        Catch ex As Exception
        End Try
    End Sub
    Private Sub WebBrowser1_DocumentTitleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles WebBrowser1.DocumentTitleChanged
        ' El código javascript del control WebBrowser1 dispara este evento 
        ' cuando se gira la rueda del mouse:
        Dim e1 As String = WebBrowser1.DocumentTitle
        Dim delta As Int32 = 0
        If InStr(e1, "#2") Then
            If My.Computer.Keyboard.CtrlKeyDown Then
                delta = Int32.Parse(Mid(e1, 3))
                factor += 0.05
                If factor >= 4.0 Then
                    factor = 4.0
                End If
                wbZoomWebBrowser(factor)
            End If
        ElseIf InStr(e1, "#1") Then
            If My.Computer.Keyboard.CtrlKeyDown Then
                delta = Int32.Parse(Mid(e1, 3))
                factor -= 0.05
                If factor <= 0.1 Then
                    factor = 0.1
                End If
                wbZoomWebBrowser(factor)
            End If

        End If
    End Sub
    Private Sub mnLogicalOperator_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles mnAND.Click, mnOR.Click, mnNOT.Click, mnNOT.Click, mnNOR.Click, mnNAND.Click
        Try
            Dim opName As String = Mid(sender.name, 3)
            rtbQuery.Text = _
                rtbQuery.Text.Insert(rtbQuery.SelectionStart, opName)
        Catch ex As Exception

        End Try
    End Sub
    Private Sub OutputToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OutputToolStripMenuItem.Click
        Dim dlgOut As New dlg_Output
        If dlg_Output.ShowDialog(Me) Then

        End If
    End Sub
    Private Sub chkVarNameLen1char_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkVarNameLen1char.Click
        verifyNumInVarsName()
    End Sub
    Sub verifyNumInVarsName()
        If chkVarNameLen1char.Checked Then
            If chkNumsInVarname.Checked Then
                updateStatusBar("A number can't be the name of a variable.")
            End If
            chkNumsInVarname.Checked = False
        End If
    End Sub
    Private Sub chkNumsInVarname_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNumsInVarname.Click
        verifyNumInVarsName()
    End Sub
    Private Sub MainForm_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If e.KeyChar = Chr(Keys.Escape) AndAlso th IsNot Nothing Then
            th.Abort()
            updateStatusBar("Cancelled.")
        End If
    End Sub
#End Region

#Region "Calculate events"

    Private Sub CALCULATE(ByVal sender As System.Object, _
            ByVal e As System.EventArgs) _
            Handles CALCULATEToolStripMenuItem.Click
        Static ar As IAsyncResult
        If Not mtx.WaitOne(0) Then
            Exit Sub
        End If
        Try
            bLoaded = False
            updateStatusBar("")
            bLoaded = True
            If chkClear.Checked Then
                wb.clear()
                n = 1
            End If
            Application.DoEvents()
            If mP Is Nothing Then
                mP = New matrixParser
            End If
            Dim e1 As String = Trim(rtbQuery.Text)
            If Len(e1) = 0 Then
                wb.Dsp(msg8.num(67), "blue", True)
                Exit Try
            End If

            'e1 = Replace(e1, "//", "'")
            'e1 = Replace(e1, vbCrLf, "|@" + vbTab)
            'e1 = Regex.Replace(e1, "\r|\n", vbCrLf)
            'e1 = Replace(e1, "|@" + vbTab, vbCrLf)
            e1 = Replace(e1, vbCrLf + vbCrLf, vbCrLf)
            Dim mc As MatchCollection = Regex.Matches(e1, MathGlobal8.sComment)
            Dim e1b As String = Regex.Replace(e1, MathGlobal8.sComment, "")

            sComments = Split(e1b, "'")
            e1b = sComments(0)
            Dim strQuery As String = e1b
            'Dim e2 As String = Replace(rtbVars.Text, "//", "'")
            'e2 = removeComments(rtbVars.Text)
            Dim e2 As String = rtbVars.Text
            If Len(e2) Then
                e2 = Replace(e2, "//", "'")
                e2 = Regex.Replace(e2, _
                MathGlobal8.sComment, "")
            End If

            Dim strVarsAndFns As String = e2

            ' set options, as rounding, in MathGlobal8 class and
            ' eventually remove blanks or set to
            ' lcase():

            ' Set the configuration:

            ' The following settings have to do
            ' with how the input data will be parsed:
            cfg.bCaseSensitive = Not chkIgnoreCase.Checked
            cfg.bIgnoreSpaces = chkIgnoreCR.Checked

            ' The next configuration settings affect
            ' on how the output data will be retrieved:
            cfg.bRounding = chkRound.Checked
            cfg.bEngNotation = chkEng.Checked
            cfg.bFractions = chkFractions.Checked
            cfg.bDetail = chkDetail.Checked
            cfg.Base = MathGlobal8.outputBase.decimal
            If chkVarNameLen1char.Checked Then
                chkNumsInVarname.Checked = False
            End If
            cfg.bVarName1Char = chkVarNameLen1char.Checked
            cfg.bNumsInVarName = chkNumsInVarname.Checked
            cfg.bUseUnits = chkUnits.Checked




            Dim sResult As String = ""

            ' INPUT for matrixParser.Parse()
            ' ==============================
            ' strQuery = the math expression to parse,
            ' for example: strQuery="2*2", "2*x+3*x", "∫(cos(x))dx", "roots(x^16-1)"
            '              or a matrix expression with columns delimited by
            '              semicolons and rows by vbCrLf as "A^-1"
            ' strVarsAndFns = "" or eventualy variables values or functions
            '                for ex. "x=-1" or  "A=2;3" + vbCrLf + "-1;2"
            ' Dim oVars As VarsAndFns = Nothing

            ' OUTPUT:
            ' =======
            ' 1) mP.toString returns the result as a string.
            ' 2) mP.retCjo() returns a complex or, eventually, an array of complex.
            ' 3) When the result is a matrix
            '   xmP.ret.exprMtx.getExpr(row, column) returns the expression
            '   contained at a row and column ((0,0) is the first row and columns)
            '   
            '   mP.ret.exprMtx.getExpr(row, column).IsReal will tell
            '   if the element's content is a real number and 
            '   mP.ret.exprMtx.getExpr(row, column).toDouble its value.
            '   mP.ret.exprMtx.rows gives the number of rows in the matrix
            '   mP.ret.exprMtx.cols gives the # of columns

            ' Example 1. We want the roots of x^16-1 and for that purpose
            ' we equal strQuery="roots(x^16-1)", execute
            ' mP = matrixParser.parse(strQuery,"", nothing)
            ' and, at the output, the roots will be in mP.retCjo(); first, the real
            ' roots (if any) and then the complex (if any):
            ' 
            ' root1:  mp.retCjo(0)  ' = -1 (real)
            ' root2:  mp.retCjo(1)  ' =  1 (real)
            ' root2:  mp.retCjo(2)  ' = -i (complex)
            ' ...
            ' root16: mp.retCjo(15) ' = (0.923879532511287 -i*0.38268343236509) (complex)

            ' Real roots, in mP.retCjo(), are ordered from most negative to most positive.
            ' If root #0 is real and not complex, i.e. the imaginary value is zero, 
            ' mP.retCjo(0).IsReal will be True.


            Dim ts As New TimeSpan(Now.Ticks)


            Dim ts2 As TimeSpan
            sResult = ""
            updateStatusBar("Press 'Esc' key to Cancel.")
            System.Threading.Thread.Sleep(0)
            Application.DoEvents()
            cfg.doTimeOut = timeout.never

            mP.cfg = cfg
            mP.cfg.doTimeOut = timeout.whenTimeIsOver

            ' uncomment for a different config set test:
            'Dim cfg2 As New Config
            'cfg2.bDetail = Not cfg.bDetail
            'cfg2.outputFormat = outputMsgFormat.plainText
            'mP.parse(strQuery, strVarsAndFns, oVars, cfg2)
            'MsgBox(mP.ret.ToString)
            'MsgBox(Join(Detall.ToStringDetail(mP.cur, mP, mP.cfg.oDetail), vbCrLf))

            Dim bdetail As Boolean = cfg.bDetail
            'cfg.bDetail = False
            Dim bSkipErr As Boolean = False
            Dim sDetail As String = String.Empty
            If True Then ' 2) Set here to 'False' for debugging purposes
                Dim oParse As New matrixParser.parseObject( _
                    mP, strQuery, strVarsAndFns, oVars, cfg)
                'Trace.WriteLine(cfg.ticksStart.ToString)
                th = New System.Threading.Thread( _
                   New Threading.ParameterizedThreadStart(AddressOf oParse.parse))
                Dim ts3 As New TimeSpan(Now.Ticks + cfg.timeOutms * 10 ^ 4)
                ts2 = New TimeSpan(Now.Ticks - ts.Ticks)
                updateStatusBar(cfg.timeOutms.ToString + "ms " + _
                     " Press 'Esc' key to Cancel. ")
                Application.DoEvents()
                th.Start(mP)
                Do While Not th.Join(5)
                    ts2 = New TimeSpan(Now.Ticks - ts.Ticks)
                    Dim ts4 As New TimeSpan(ts3.Ticks - Now.Ticks)
                    If ts4.TotalSeconds < 0 Then
                        Config.cancelID(mP.cfg.ID)
                        Application.DoEvents()
                        System.Threading.Thread.Sleep(2000)
                        cfg.doTimeOut = timeout.always
                        sResult = msg8.num(44) + vbCrLf
                        DspCalc(strQuery, sResult)
                        bSkipErr = True
                        Exit Do
                    ElseIf ts2.TotalSeconds AndAlso mP.cfg.ID Then
                        updateStatusBar( _
                         String.Format("{0:00}:{1:00}", ts2.Minutes, ts2.Seconds) + _
                         String.Format("  {0:00}:{1:00}", ts4.Minutes, ts4.Seconds) + _
                         " Press 'Esc' key to Cancel. ")
                    End If
                    Application.DoEvents()
                Loop
                th.Abort()
            Else
                For k As Int32 = 1 To 1
                    oVars = Nothing
                    mP.parse(strQuery, strVarsAndFns, oVars, cfg)
                Next
                ts2 = New TimeSpan(Now.Ticks - ts.Ticks)
            End If
            If mP.cfg.ID = 0 Then
                updateStatusBar(" ...canceled")
                If (mP.retCjo Is Nothing OrElse _
                mP.retCjo.Length = 0) AndAlso _
                (mP.ret Is Nothing OrElse _
                 mP.ret.curExpr Is Nothing) Then
                    Exit Sub
                End If
                bSkipErr = True
            Else
                updateStatusBar("")
            End If
            If Not bSkipErr Then
                If mP.errMsg IsNot Nothing AndAlso _
                mP.errMsg.Length Then
                    sResult += mP.errMsg + vbCrLf
                    If (mP.msgHTML.Length AndAlso _
                    mP.msgHTML <> mP.errMsg) OrElse _
                    (mP.errMsg.Length = 0 AndAlso _
                     mP.msgHTML.Length) Then
                        sResult += mP.msgHTML
                    End If
                    'updateStatusBar(mP.errMsg)
                    DspCalc(e1, sResult)
                    Exit Try
                End If

                If mP.msgHTML.Length Then
                    sResult += mP.errMsg + vbCrLf
                    sResult += mP.msgHTML
                    'updateStatusBar(mP.errMsg)
                    DspCalc(e1, sResult)
                    Exit Try
                End If
            End If

            If bdetail Then
                sDetail = cfg.oDetail.ToStringHTML("navy")
            End If
            cfg.doTimeOut = timeout.never
            System.Threading.Thread.Sleep(0)
            Application.DoEvents()
            cfg.bDetail = bdetail
            For ioutput = 1 To 4
                If ioutput = 1 Then
                ElseIf ioutput = 2 Then
                    If chkHexa.Checked Then
                        cfg.Base = MathGlobal8.outputBase.hexadecimal
                    Else
                        GoTo sig_i_output
                    End If
                ElseIf ioutput = 3 Then
                    If chkOctal.Checked Then
                        cfg.Base = MathGlobal8.outputBase.octal
                    Else
                        GoTo sig_i_output
                    End If
                ElseIf ioutput = 4 Then
                    If chkBinary.Checked Then
                        cfg.Base = MathGlobal8.outputBase.binary
                    Else
                        GoTo sig_i_output
                    End If
                End If

                If ioutput = 1 Then
                ElseIf ioutput = 2 Then
                    If chkHexa.Checked Then
                        cfg.Base = MathGlobal8.outputBase.hexadecimal
                        sResult += "<br /><h4>Hexadecimal:</h4>"
                    Else
                        GoTo sig_i_output
                    End If
                ElseIf ioutput = 3 Then
                    If chkOctal.Checked Then
                        cfg.Base = MathGlobal8.outputBase.octal
                        sResult += "<br /><h4>Octal:</h4>"
                    Else
                        GoTo sig_i_output
                    End If
                ElseIf ioutput = 4 Then
                    If chkBinary.Checked Then
                        cfg.Base = MathGlobal8.outputBase.binary
                        sResult += "<br /><h4>Binary:</h4>"
                    Else
                        GoTo sig_i_output
                    End If
                End If
                Dim seRet As String = ""
                Dim bIsEq As Boolean = False
                If mP.ret IsNot Nothing AndAlso _
                mP.ret.getParser IsNot Nothing Then
                    bIsEq = mP.ret.getParser.cur.bIsEquation
                ElseIf mP.ret Is Nothing Then
                    Exit Sub
                End If
                Dim bIsPoly As Boolean = False
                Dim bIsReal As Boolean = False
                If mP.ret.curExpr IsNot Nothing Then
                    bIsPoly = mP.ret.curExpr.IsPolynomial
                    bIsReal = mP.ret.curExpr.IsReal
                End If
                Dim bIsMtx As Boolean = False
                If mP.ret.exprMtx.Cols + mP.ret.exprMtx.Rows <> 2 Then
                    bIsMtx = True
                    If bIsEq AndAlso mP.ret.exprMtx.Cols <> 1 Then
                        sResult += msg8.num(50) ' found columns, expected an equation 
                        updateStatusBar(sResult)
                        DspCalc(e1, sResult)
                        Exit Try
                    End If
                End If
                sResult += mP.ToString(cfg)
                Dim bOneOrMoreVars As Boolean = (mP.ret.exprMtx.getAllVars.Length >= 1)
                Dim bOneVar As Boolean = (mP.ret.exprMtx.getAllVars.Length = 1)
                If bIsEq AndAlso bOneVar Then
                    seRet += " = 0"
                End If
                Dim sRows() As String = Regex.Split( _
                    seRet, MathGlobal8.sRow)
                Dim sCols() As String = Split( _
                    Replace(sRows(0), ";", vbTab), vbTab)
                If bIsEq AndAlso bOneOrMoreVars Then
                    If bOneVar AndAlso _
                    cfg.bDetail Then
                        Dim Pa As Polynomial = mP.ret.curExpr.getPolynomial
                        If Pa IsNot Nothing AndAlso Pa.PolyResto IsNot Nothing Then
                            seRet = "Detail:" + vbCrLf + Pa.toStringPoly(cfg) + " = 0  =>" + vbCrLf
                            Dim div As Polynomial = New Polynomial(Pa.PolyDivisor)
                            Dim resto As New Polynomial(Pa.PolyResto)
                            Pa.PolyResto = Nothing
                            Pa.PolyDivisor = Nothing
                            Pa *= div
                            Pa += resto
                            mP.ret.curExpr = New Expression(Pa)
                            seRet += Pa.toStringPoly(cfg) + " = 0" + vbCrLf
                            sResult += MathGlobal8.getTable(seRet, "navy")
                        ElseIf mP.soe IsNot Nothing Then
                            seRet = mP.soe.sErrMsg
                        End If
                    End If
                ElseIf bIsEq Then
                    If Not bIsReal OrElse mP.ret.curExpr.toDouble <> 0.0 Then
                        sResult += String.Format("<br /><h3>" + msg8.num(50) + "</h3>", _
                                        mP.ret.curExpr.toDouble)
                    Else
                        sResult += MathGlobal8.getTable(seRet, "navy")
                        sResult += "<br /><h3>0 = 0</h3>"
                    End If
                Else
                    Dim common As Expression = Nothing
                    Dim expr As Expression = Nothing
                    Dim commonStr As String = ""
                    Dim Expr1 As Expression = Nothing
                    Dim CommExpr As Expression = Nothing
                    Dim commStr As String = ""
                    If Len(seRet) Then
                        sResult += MathGlobal8.getTable(seRet, "navy")
                    End If
                    'If mP.ret.curExpr.getCommonFactor(cfg, CommExpr, Expr1, commStr) Then
                    '    seRet = " = " + commStr + vbCrLf
                    '    sResult += MathGlobal8.getTable(seRet, "navy")
                    'End If
                    If cfg.bDetail AndAlso (mP.ret.isMatrix OrElse _
                    Not mP.ret.curExpr.IsPolynomial) Then
                        sResult += "<br />" + sDetail
                    ElseIf cfg.bDetail Then
                        sResult += "<br />Detail: <br />"
                        sResult += "<br />" + sDetail
                    End If
                End If

sig_i_output:
            Next
            sResult += "<br>Time: " + String.Format("{0:0}", ts2.TotalMilliseconds) + " ms"
            sResult += "<br>"


            'lstGo2 = sTbQry.Length
            Dim iTb As Int32
            For iTb = 0 To sTbQry.Length - 1
                If sTbQry(iTb) = e1 AndAlso _
                sTbVar(iTb) = rtbVars.Text Then
                    Exit For
                End If
            Next
            If iTb < sTbQry.Length Then
                DspCalc(e1, sResult, iTb)
                Exit Try
            Else
                DspCalc(e1, sResult)
            End If
            ReDim Preserve sTbQry(lstGo2), sTbVar(lstGo2), vsResultGo2(lstGo2), vN(lstGo2)
            vN(lstGo2) = Me.n
            sTbQry(lstGo2) = e1
            sTbVar(lstGo2) = rtbVars.Text
            vsResultGo2(lstGo2) = sResult
            iCurGo2 = lstGo2
            lstGo2 += 1
            'Me.n += 1

        Catch ex As Exception
            Dim s As String = ex.ToString
            'updateStatusBar(ex.Message)
        Finally
            updateStausBarLabels()
            ar = Nothing
            mtx.ReleaseMutex()
        End Try
    End Sub

    Function removeComments(ByVal txt As String) As String
        Dim e1() As String = Nothing
        Try
            If txt = "" Then Return ""
            e1 = Split(txt, vbLf)
            For i = 0 To e1.Length - 1
                If Len(e1(i)) Then
                    e1(i) = Replace(e1(i), "//", "'")
                    Dim pos As Int32 = InStr(e1(i), "'")
                    If pos = 1 Then
                        e1(i) = ""
                    ElseIf pos > 1 Then
                        e1(i) = Trim(Mid(e1(i), 1, pos - 1))
                    End If
                End If
            Next
        Catch ex As Exception
            updateStatusBar(ex.Message)
        End Try
        Return Join(e1, vbLf)
    End Function
    Sub DspCalc(ByVal sQuery As String, ByVal sResult As String, Optional ByVal n1 As Int32 = -1)
        Try
            ' record:
            If Len(sQuery) Then
                Dim pos As Int32 = -1
                Dim i1 As Int32
                For i1 = 0 To LBHistQuery.Items.Count - 1
                    pos = Regex.Match(LBHistQuery.Items(i1).ToString, _
                              "(" + Regex.Escape(") " + sQuery) + ")$").Index
                    If pos > 0 AndAlso pos < 4 Then
                        Exit For
                    End If
                Next
                If i1 >= LBHistQuery.Items.Count Then
                    LBHistQuery.Items.Add(n.ToString + ") " + sQuery)
                End If
                If LBHistQuery.Items.Count = 0 Then
                    LBHistQuery.Items.Add(n.ToString + ") " + sQuery)
                End If
            End If
            If n1 = -1 Then
                n = Me.LBHistQuery.Items.Count
                wb.Dsp(n.ToString + ") Question:", "black", True)
            Else
                wb.Dsp((n1 + 1).ToString + ") Question:", "black", True)
            End If
            Dim qTbl As String = _
            MathGlobal8.getTable(sQuery + " = ?", "#b0b0b0")
            qTbl = Replace(qTbl, "</TD><TD>", ";")
            wb.Dsp(qTbl, "black", False)

            wb.Dsp(" Answer: ", "blue", True)
            Dim respTbl As String = sResult
            wb.Dsp(respTbl, "blue", False)
            wb.ZoomWebBrowser(factor)

        Catch ex As Exception
            updateStatusBar(ex.Message)
        End Try
    End Sub

    Private Sub rtb_KeyDown(ByVal sender As Object, _
                ByVal e As System.Windows.Forms.KeyEventArgs) _
                Handles rtbQuery.KeyDown, rtbVars.KeyDown
        ' Enter key --> Calculate
        ' Control + Enter keys --> new line
        If e.KeyCode = Keys.Enter AndAlso Not e.Control Then
            e.SuppressKeyPress = True
            e.Handled = True
            Cursor = Cursors.WaitCursor
            CALCULATE(Nothing, Nothing)
            Cursor = Cursors.Default
            e.Handled = True
        ElseIf e.KeyCode = Keys.Escape Then
            Config.cancelID(mP.cfg.ID)
            updateStatusBar(" Canceling process...")
        ElseIf e.Control AndAlso e.KeyCode = Keys.Left Then
            lblPrev_Click(Nothing, Nothing)
        ElseIf e.Control AndAlso e.KeyCode = Keys.Right Then
            lblNext_Click(Nothing, Nothing)
        End If
    End Sub

#End Region

#Region "File menu"
    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        Try
            OpenFileDialog1.Filter = "Text files |*.txt|All files|*.*"
            OpenFileDialog1.FileName = curFileName
            Dim r As DialogResult = OpenFileDialog1.ShowDialog
            If r <> Windows.Forms.DialogResult.Yes AndAlso r <> Windows.Forms.DialogResult.OK Then
                Exit Sub
            End If
            lstGo2 = 0
            ReDim Preserve sTbQry(-1), sTbVar(-1), vsResultGo2(-1), vN(-1)
            OpenFile()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub AppdenFile_Click(sender As Object, e As EventArgs) Handles AppenFile.Click
        Try
            OpenFileDialog1.Filter = "Text files |*.txt|All files|*.*"
            OpenFileDialog1.FileName = curFileName
            Dim r As DialogResult = OpenFileDialog1.ShowDialog
            If r <> Windows.Forms.DialogResult.Yes AndAlso r <> Windows.Forms.DialogResult.OK Then
                Exit Sub
            End If
            OpenFile()
        Catch ex As Exception

        End Try
    End Sub


    Sub OpenFile()
        Dim fs As FileStream = Nothing
        Dim sr As StreamReader = Nothing
        Try


            Dim bOk As Boolean = False
            fs = New FileStream(OpenFileDialog1.FileName, FileMode.Open)
            sr = New StreamReader(fs, True)

            Dim bFst As Boolean = True
            Do While Not sr.EndOfStream
                Dim e1 As String = sr.ReadLine()
                e1 = Replace(e1, "||||", "||")
                If Len(e1) >= 2 AndAlso Mid(e1, 1, 2) = "==" Then
                    Exit Do
                End If
                If bFst Then
                    'LBHistQuery.Items.Clear()
                    bFst = False
                End If
                If Len(e1) Then
                    LBHistQuery.Items.Add(Replace(e1, "||", vbCrLf))
                End If
            Loop
            bFst = True
            Do While Not sr.EndOfStream
                Dim e1 As String = sr.ReadLine()
                e1 = Replace(e1, "||||", "||")
                If Len(e1) >= 2 AndAlso Mid(e1, 1, 2) = "==" Then
                    Exit Do
                End If
                If bFst Then
                    'LBHistVars.Items.Clear()
                    bFst = False
                End If
                If Len(e1) Then
                    LBHistVars.Items.Add(Replace(e1, "||", vbCrLf))
                End If
            Loop
            bFst = True
            Do While Not sr.EndOfStream
                Dim e1 As String = sr.ReadLine()
                e1 = Replace(e1, "||||", "||")
                If Len(e1) >= 2 AndAlso Mid(e1, 1, 2) = "==" Then
                    Exit Do
                End If
                If bFst Then
                    'lstGo2 = 0
                    bFst = False
                End If
                ReDim Preserve sTbQry(lstGo2), _
                        sTbVar(lstGo2), vsResultGo2(lstGo2), vN(lstGo2)
                Dim sN As String = Replace(e1, "||", vbCrLf)
                'vN(lstGo2) = Int32.Parse(sN)
                Int32.TryParse(sN, vN(lstGo2))
                e1 = sr.ReadLine
                e1 = Replace(e1, "||||", "||")
                e1 = Replace(e1, "||", vbCrLf)
                sTbQry(lstGo2) = e1
                e1 = sr.ReadLine
                e1 = Replace(e1, "||||", "||")
                e1 = Replace(e1, "||", vbCrLf)
                sTbVar(lstGo2) = e1
                e1 = sr.ReadLine
                e1 = Replace(e1, "||||", "||")
                e1 = Replace(e1, "||", vbCrLf)
                vsResultGo2(lstGo2) = e1
                sr.ReadLine() ' lectura separación "----"
                lstGo2 += 1
            Loop
            updateStausBarLabels()
            wb.clear()
            'Me.iCurGo2 = lstGo2 - 1
            If lstGo2 = 0 Then
                MsgBox("Could not read the file or the file is empty.")
            Else
                'dspGo2()
                rtbQuery.Text = Me.sTbQry(lstGo2 - 1)
                rtbVars.Text = Me.sTbVar(lstGo2 - 1)
                CALCULATE(Nothing, Nothing)
            End If

        Catch ex As Exception
            Dim s1 As String = ex.ToString
            Dim s2 As String = s1
            MsgBox(s1)
        Finally
            If sr IsNot Nothing Then
                sr.Close()
            End If
            If fs IsNot Nothing Then
                fs.Close()
            End If
        End Try
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        Dim fs As FileStream = Nothing
        Dim sw As StreamWriter = Nothing
        Try
            SaveFileDialog1.Filter = "Text files |*.txt|All files|*.*"
            SaveFileDialog1.FileName = curFileName
            Dim r As DialogResult = SaveFileDialog1.ShowDialog
            If r <> Windows.Forms.DialogResult.Yes AndAlso r <> Windows.Forms.DialogResult.OK Then
                Exit Sub
            End If
            Dim path As String = SaveFileDialog1.FileName
            Dim e3() As String = Split(path, "\")
            fs = New FileStream(path, FileMode.Create)
            sw = New StreamWriter(fs)

            ' save LBHistQuery items:
            Dim i As Int32
            For i = 0 To LBHistQuery.Items.Count - 1
                Dim e1 As String = LBHistQuery.Items(i)
                e1 = Replace(e1, vbCrLf, "||")
                sw.WriteLine(e1)
            Next
            sw.WriteLine("==")
            For i = 0 To LBHistVars.Items.Count - 1
                Dim e1 As String = LBHistVars.Items(i)
                e1 = Replace(e1, vbCrLf, "||")
                sw.WriteLine(e1)
            Next
            sw.WriteLine("==")
            For i = 0 To lstGo2 - 1
                sw.WriteLine(Regex.Replace(vN(i).ToString, "\r|\n", "||"))
                sw.WriteLine(Regex.Replace(sTbQry(i), "\r|\n", "||"))
                If sTbVar(i) IsNot Nothing Then
                    sw.WriteLine(Regex.Replace(sTbVar(i), "\r|\n", "||"))
                Else
                    sw.WriteLine("")
                End If
                sw.WriteLine(Regex.Replace(vsResultGo2(i), "\r|\n", "||"))
                sw.WriteLine("-------")
            Next


        Catch ex As Exception
        Finally
            If sw IsNot Nothing Then
                sw.Close()
            End If
            If fs IsNot Nothing Then
                fs.Close()
            End If
        End Try
    End Sub

#End Region

#Region "Predefined: fns. & examples"

    Sub populateFnsAndConstants()
        Try
            Dim i As Int32
            Dim vCnts(MathGlobal8.vCntsCaseSen.Length - 1) As String
            Array.Copy(MathGlobal8.vCntsCaseSen, vCnts, vCnts.Length)
            i = vCnts.Length
            ReDim Preserve vCnts(i + MathGlobal8.vCntsCaseNonSen.Length - 1)
            Array.Copy(MathGlobal8.vCntsCaseNonSen, 0, _
                       vCnts, i, MathGlobal8.vCntsCaseNonSen.Length)
            Array.Sort(vCnts)
            For i = 0 To vCnts.Length - 1
                cbFns.Items.Add(vCnts(i)) ' load constants into the combo 
            Next
            cbFns.Items.Add("------")
            cbFns.Items.Add("binary prefix &b")
            cbFns.Items.Add("octal prefix &o")
            cbFns.Items.Add("hexadec.prefix &h")
            cbFns.Items.Add("∫")
            cbFns.Items.Add("------")

            Dim vFn(MathGlobal8.vFn.Length - 1) As String
            Array.Copy(MathGlobal8.vFn, vFn, vFn.Length)
            Array.Sort(vFn)
            For i = 0 To vFn.Length - 1
                cbFns.Items.Add(vFn(i)) ' load functions into the combobox
            Next
        Catch ex As Exception

        End Try
    End Sub


    Private Sub cbFns_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
            Handles cbFns.SelectedIndexChanged
        Try
            If cbFns.SelectedIndex > -1 Then
                Dim e1 As String = cbFns.SelectedItem
                If e1.Chars(0) = "-" Then
                    Exit Sub
                End If
                If InStr(e1, "prefix") Then
                    If InStr(e1, "bin") Then
                        rtbQuery.Text += "&b"
                    ElseIf InStr(e1, "oct") Then
                        rtbQuery.Text += "&o"
                    ElseIf InStr(e1, "hexa") Then
                        rtbQuery.Text += "&h"
                    End If
                    Exit Sub
                End If
                If e1 <> "pi" AndAlso e1 <> "e" Then
                    e1 += "()"
                    If e1.Chars(0) = "∫" Then
                        e1 += "dx"
                    End If
                End If
                Dim pos As Int32 = rtbQuery.SelectionStart
                If pos < rtbQuery.Text.Length Then
                    If pos < 1 Then
                        rtbQuery.Text = e1 + rtbQuery.Text
                    Else
                        rtbQuery.Text = Mid(rtbQuery.Text, 1, pos) + _
                        e1 + Mid(rtbQuery.Text, pos + 1)
                    End If
                Else
                    rtbQuery.Text += e1
                End If
                rtbQuery.SelectionStart = pos + Len(e1)
            End If
        Catch ex As Exception
            updateStatusBar(ex.Message)
        End Try
    End Sub
    Private Sub cbExamples_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbExamples.SelectedIndexChanged
        Try
            errClr()
            If cbExamples.SelectedIndex > -1 Then
                'chkIgnoreCase.Checked = False
                Dim bIgnoreSpaces As Boolean = chkIgnoreCR.Checked
                chkIgnoreCR.Checked = False
                cfg.bIgnoreSpaces = False
                cfg.bVarName1Char = False
                Dim e1 As String = ""

                e1 = cbExamples.Items(cbExamples.SelectedIndex)
                e1 = Trim(e1)
                If Len(e1) = 0 Then
                    Exit Sub
                End If
                If Len(e1) > 3 AndAlso _
                Mid(e1, 1, 3) = "---" Then
                    Exit Sub
                End If
                e1 = Replace(e1, "&amp;", "&")
                Dim e3() As String = Split(e1, "?")
                rtbQuery.Text = e3(0)
                rtbVars.Text = ""
                If e3.Length > 1 Then
                    For i As Int32 = 1 To e3.Length - 1
                        rtbVars.Text += e3(i)
                    Next
                    rtbVars.Text = Replace(rtbVars.Text, "|", vbCrLf)
                End If
                Dim bH As Boolean = chkHexa.Checked
                Dim bO As Boolean = chkOctal.Checked
                Dim bB As Boolean = chkBinary.Checked
                Dim bUnits As Boolean =chkUnits.Checked 
                chkHexa.Checked = False
                chkOctal.Checked = False
                chkBinary.Checked = False
                If InStr(e1, "&h") Then
                    chkHexa.Checked = True
                    chkOctal.Checked = True
                    chkBinary.Checked = True
                Else
                End If
                If InStr(e1, "Xc=") Then
                    chkVarNameLen1char.Checked = False
                    chkUnits.Checked = True
                Else
                    chkVarNameLen1char.Checked = True
                End If
                chkUnits.Checked = False
                CALCULATE(Nothing, Nothing)
                chkHexa.Checked = bH
                chkOctal.Checked = bO
                chkBinary.Checked = bB
                cfg.bIgnoreSpaces = bIgnoreSpaces
                chkIgnoreCR.Checked = bIgnoreSpaces
                chkUnits.Checked = bUnits
            End If

        Catch ex As Exception
            updateStatusBar(ex.Message)
        End Try
    End Sub
    Private Sub cbUnits_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbUnitsExamples.SelectedIndexChanged
        Try
            errClr()
            If cbUnitsExamples.SelectedIndex > -1 Then
                Dim e1 As String = ""

                e1 = cbUnitsExamples.Items( _
                    cbUnitsExamples.SelectedIndex)
                e1 = Trim(e1)
                If Len(e1) = 0 Then
                    Exit Sub
                End If
                If Len(e1) > 3 AndAlso _
                Mid(e1, 1, 3) = "---" Then
                    Exit Sub
                End If
                e1 = Replace(e1, "&amp;", "&")
                Dim e3() As String = Split(e1, "?")
                rtbQuery.Text = e3(0)
                rtbVars.Text = ""
                If e3.Length > 1 Then
                    For i As Int32 = 1 To e3.Length - 1
                        rtbVars.Text += e3(i)
                    Next
                    rtbVars.Text = Replace(rtbVars.Text, "|", vbCrLf)
                End If
                Dim bUnits As Boolean = chkUnits.Checked
                Dim b1Char As Boolean = chkVarNameLen1char.Checked
                chkUnits.Checked = True
                If InStr(e1, "Xc=") Then
                    chkVarNameLen1char.Checked = False
                Else
                    chkVarNameLen1char.Checked = True
                End If
                CALCULATE(Nothing, Nothing)
                'chkUnits.Checked = bUnits
                chkVarNameLen1char.Checked = b1Char
            End If

        Catch ex As Exception
            updateStatusBar(ex.Message)
        End Try
    End Sub
    Private Sub cbGreek_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbGreek.SelectedIndexChanged
        If cbGreek.SelectedIndex > -1 Then
            rtbQuery.Text = rtbQuery.Text.Insert(rtbQuery.SelectionStart, cbGreek.SelectedItem.ToString)
        End If
    End Sub

#End Region

#Region "Options"
    Private Sub chkClear_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkClear.CheckedChanged
        If bLoaded Then
            If chkClear.Checked Then
                wb.clear()
                n = 1
            End If
            updateStausBarLabels()
        End If
    End Sub


    Private Sub IncrementToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IncrementToolStripMenuItem.Click
        Try
            If factor >= 4 Then
                Exit Sub
            End If
            factor = factor + 0.25
            wbZoomWebBrowser(factor)
            rtbQuery.ZoomFactor = factor
            rtbVars.ZoomFactor = factor
            updateStausBarLabels()
        Catch ex As Exception
            updateStatusBar(ex.Message)
        End Try
    End Sub

    Private Sub DecrementToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DecrementToolStripMenuItem.Click
        Try
            If factor <= 0.5 Then
                Exit Sub
            End If
            factor = factor - 0.15
            wbZoomWebBrowser(factor)
            rtbQuery.ZoomFactor = factor
            rtbVars.ZoomFactor = factor
            updateStausBarLabels()
        Catch ex As Exception
            updateStatusBar(ex.Message)
        End Try
    End Sub

    Private Sub chkI_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkI.CheckedChanged
        If chkI.Checked Then
            cfg.sImg = "i"
        Else
            cfg.sImg = "j"
        End If
        updateStausBarLabels()
    End Sub


    Private Sub lblZoom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblZoom.Click
        Try
            Dim fOld As Single = Math.Floor(factor * 100)
            If fOld <= 75 Then
                factor = 0.81
            ElseIf fOld <= 81 Then
                factor = 1
            ElseIf fOld <= 100 Then
                factor = 1.25
            ElseIf fOld <= 125 Then
                factor = 1.5
            Else
                factor = 0.75
            End If
            Try
                wbZoomWebBrowser(factor)
            Catch ex As Exception
                factor = fOld
                Exit Sub
            End Try
            updateStausBarLabels()
        Catch ex As Exception
            updateStatusBar(ex.Message)
        End Try
    End Sub
    Private Sub lblZoom_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblZoom.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            mnFactor.Show(MousePosition)
        End If
    End Sub
    Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem2.Click
        factor = 0.75
        wbZoomWebBrowser(factor)
        updateStausBarLabels()
    End Sub

    Private Sub ToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click
        factor = 0.82
        wbZoomWebBrowser(factor)
        updateStausBarLabels()
    End Sub

    Private Sub ToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem4.Click
        factor = 1
        wbZoomWebBrowser(factor)
        updateStausBarLabels()
    End Sub

    Private Sub ToolStripMenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem5.Click
        factor = 1.25
        wbZoomWebBrowser(factor)
        updateStausBarLabels()
    End Sub

    Private Sub ToolStripMenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem6.Click
        factor = 1.5
        wbZoomWebBrowser(factor)
        updateStausBarLabels()
    End Sub

    Private Sub ToolStripMenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem8.Click
        factor = 2.0
        wbZoomWebBrowser(factor)
        updateStausBarLabels()
    End Sub
    Private Sub ToolStripMenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem7.Click
        factor = 4.0
        wbZoomWebBrowser(factor)
        updateStausBarLabels()
    End Sub
    Private Sub lblZoom_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblZoom.DoubleClick
        factor = 1
        wbZoomWebBrowser(factor)
        updateStausBarLabels()
    End Sub
    Sub wbZoomWebBrowser(ByVal factor As Single)
        wb.ZoomWebBrowser(factor)
        rtbQuery.ZoomFactor = factor
        rtbVars.ZoomFactor = factor
    End Sub
    Private Sub lblClr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblClr.Click
        chkClear.Checked = Not chkClear.Checked
        updateStausBarLabels()
    End Sub

    Private Sub lblEng_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblEng.Click
        chkEng.Checked = Not chkEng.Checked
        updateStausBarLabels()
    End Sub

    Private Sub lblCase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblCase.Click
        chkIgnoreCase.Checked = Not chkIgnoreCase.Checked
        updateStausBarLabels()
    End Sub
    Private Sub lblSpaces_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblSpaces.Click
        chkIgnoreCR.Checked = Not chkIgnoreCR.Checked
        updateStausBarLabels()
    End Sub

    Private Sub lblRnd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblRnd.Click
        chkRound.Checked = Not chkRound.Checked
        updateStausBarLabels()
    End Sub
    Private Sub lblImag_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblImag.Click
        chkI.Checked = Not chkI.Checked
        updateStausBarLabels()
    End Sub
    Private Sub cbTimeout_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cbTimeout.SelectedIndexChanged
        Try
            cfg.timeOutms = 500
            Dim i As Int32 = cbTimeout.SelectedIndex
            If i < 1 Then
                Exit Try
            End If
            Dim sTxt As String = LCase(cbTimeout.Items(i))
            Dim mult As Int32 = 1000 ' 1000 ms
            If InStr(sTxt, "minute") Then
                mult *= 60
            End If
            Dim m As Match = Regex.Match(sTxt, "[0-9\.]+")
            If m.Success Then
                mult *= Double.Parse(m.ToString)
                cfg.timeOutms = mult
            ElseIf sTxt = "never" Then
                Dim ts As New TimeSpan(9999, 9999, 9999, 9999)
                cfg.timeOutms = ts.TotalMilliseconds
            End If
        Catch ex As Exception

        End Try
    End Sub
    Function toStrOptions() As String
        Dim e1() As String = Nothing
        Try
            e1 = New String() { _
                chkClear.Checked.ToString, _
                chkEng.Checked.ToString, _
                chkIgnoreCase.Checked.ToString, _
                chkIgnoreCR.Checked.ToString, _
                chkRound.Checked.ToString, _
                chkFractions.Checked.ToString, _
                chkI.Checked.ToString, _
                "", _
                chkHexa.Checked.ToString, _
                chkOctal.Checked.ToString, _
                chkBinary.Checked.ToString, _
                chkDetail.Checked.ToString, _
                chkVarNameLen1char.Checked.ToString, _
                chkNumsInVarname.Checked.ToString, _
                factor.ToString(MathGlobal8.us), _
                cbTimeout.SelectedIndex, _
                CInt(Me.WindowState).ToString, _
                Me.Left.ToString, _
                Me.Top.ToString, _
                Me.Width.ToString, _
                Me.Height.ToString, _
                chkUnits.Checked.ToString
                }
        Catch ex As Exception
            If bLoaded Then
                MsgBox(ex.ToString)
            End If
        End Try
        Return Join(e1, "|")
    End Function
    Sub parseOptions(ByVal txt As String)
        Try
            If txt = "" Then
                Exit Sub
            End If
            Dim e1() As String = Split(txt, "|")
            chkClear.Checked = Boolean.Parse(e1(0))
            chkEng.Checked = Boolean.Parse(e1(1))
            chkIgnoreCase.Checked = Boolean.Parse(e1(2))
            chkIgnoreCR.Checked = Boolean.Parse(e1(3))
            chkRound.Checked = Boolean.Parse(e1(4))
            chkFractions.Checked = Boolean.Parse(e1(5))
            chkI.Checked = Boolean.Parse(e1(6))
            'chkDegrees.Checked = Boolean.Parse(e1(7))
            chkHexa.Checked = Boolean.Parse(e1(8))
            chkOctal.Checked = Boolean.Parse(e1(9))
            chkBinary.Checked = Boolean.Parse(e1(10))
            chkDetail.Checked = Boolean.Parse(e1(11))
            chkVarNameLen1char.Checked = Boolean.Parse(e1(12))
            chkNumsInVarname.Checked = Boolean.Parse(e1(13))
            factor = Single.Parse(e1(14), Globalization.NumberStyles.Float, MathGlobal8.us)
            cbTimeout.SelectedIndex = Int32.Parse(e1(15))
            Me.WindowState = Int32.Parse(e1(16))
            Me.Left = Int32.Parse(e1(17))
            Me.Top = Int32.Parse(e1(18))
            Me.Width = Int32.Parse(e1(19))
            Me.Height = Int32.Parse(e1(20))
            Me.chkUnits.Checked = False
            If e1.Length > 21 Then
                Me.chkUnits.Checked = Boolean.Parse(e1(21))
            End If
        Catch ex As Exception
            If bLoaded Then
                MsgBox(ex.ToString)
            End If
        End Try
    End Sub
    Sub setDefaultOptions()
        Try
            chkClear.Checked = True
            chkEng.Checked = True
            chkIgnoreCase.Checked = False
            chkIgnoreCR.Checked = False
            chkRound.Checked = True
            chkFractions.Checked = True
            chkI.Checked = True
            'chkDegrees.Checked = False
            chkHexa.Checked = False
            chkOctal.Checked = False
            chkBinary.Checked = False
            chkDetail.Checked = False
            chkVarNameLen1char.Checked = True
            chkNumsInVarname.Checked = False
            factor = 1.0
            cbTimeout.SelectedIndex = 1
            Me.WindowState = System.Windows.Forms.FormWindowState.Normal
            Me.Width = 421
            Me.Height = 266
            chkUnits.Checked = False
        Catch ex As Exception
            If bLoaded Then
                MsgBox(ex.ToString)
            End If
        End Try
    End Sub
    Private Sub SaveOptionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveOptionsToolStripMenuItem.Click
        Try
            My.Settings.Options = toStrOptions()
            My.Settings.Save()
        Catch ex As Exception
            If bLoaded Then
                MsgBox(ex.ToString)
            End If
        End Try
    End Sub

    Private Sub RestoreDefaultOptionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RestoreDefaultOptionsToolStripMenuItem.Click
        Try
            setDefaultOptions()
            My.Settings.Options = toStrOptions()
            My.Settings.Save()
        Catch ex As Exception
            If bLoaded Then
                MsgBox(ex.ToString)
            End If
        End Try
    End Sub
#End Region

#Region "Clear all choice"
    Private Sub ClearAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearAllToolStripMenuItem.Click
        Try
            iCurGo2 = 0 ': lstGo2 = 0
            ReDim vN(-1)
            ReDim sTbVar(-1)
            ReDim sTbQry(-1), vsResultGo2(-1)
            wb.clear()
            rtbQuery.Text = ""
            rtbVars.Text = ""
            n = 1
            updateStausBarLabels()
        Catch ex As Exception

        End Try
    End Sub

#End Region

#Region "Record menu"
    Private Sub LBHistQuery_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles LBHistQuery.SelectedIndexChanged
        If LBHistQuery.SelectedIndex > -1 Then
            rtbQuery.Text = LBHistQuery.Items(LBHistQuery.SelectedIndex)
            'CALCULATE(sender, e)
        End If
    End Sub
    Private Sub LBHistVars_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LBHistVars.Click
        If LBHistVars.SelectedIndex > -1 Then
            rtbVars.Text = LBHistVars.Items(LBHistVars.SelectedIndex)
        End If
    End Sub

#End Region

#Region "About"
    Private Sub AboutMates6CalculatorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutMates6CalculatorToolStripMenuItem.Click
        Dim dlgAbout1 As New dlbAbout
        dlgAbout1.ShowDialog()
    End Sub

#End Region

#Region "status bar"
    Sub errClr()
        'Me.StatusStrip.Items(0).Text = "Message: "
        lblMsg.Text = "Message: "
    End Sub
    Sub updateStatusBar(ByVal sErr As String)
        Try
            If bLoaded Then
                'Beep()
            End If
            If sErr Is Nothing Then
                lblMsg.Text = "Message: "
            Else
                lblMsg.Text = "Message: " + Trim(sErr)
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub lblClr_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblClr.MouseEnter
        If chkClear.Checked Then
            lblClr.ToolTipText = "Clear On"
        Else
            lblClr.ToolTipText = "Clear Off"
        End If
    End Sub
    Private Sub lblCase_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblCase.MouseEnter
        If chkIgnoreCase.Checked = False Then
            lblCase.ToolTipText = "Case sensitive"
        Else
            lblCase.ToolTipText = "Not case sensitive"
        End If
    End Sub
    Private Sub lblEng_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblEng.MouseEnter
        If chkEng.Checked Then
            lblEng.ToolTipText = "ENG notation"
        Else
            lblEng.ToolTipText = "General notation"
        End If
    End Sub
    Private Sub lblImg_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblImag.MouseEnter
        If chkI.Checked Then
            lblImag.ToolTipText = "'i' for imaginary"
        Else
            lblImag.ToolTipText = "'j' for imaginary"
        End If
    End Sub
    Private Sub lblNext_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblNext.MouseEnter
        lblNext.ToolTipText = "Next"
    End Sub
    Private Sub lblPrev_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblPrev.MouseEnter
        lblPrev.ToolTipText = "Previous"
    End Sub
    Private Sub lblRnd_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblRnd.MouseEnter
        If chkRound.Checked Then
            lblRnd.ToolTipText = "Round to 3 decimals"
        Else
            lblRnd.ToolTipText = "No rounding"
        End If
    End Sub
    Private Sub lblSpaces_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblSpaces.MouseEnter
        If chkIgnoreCR.Checked Then
            lblSpaces.ToolTipText = "Ignore spaces"
        Else
            lblSpaces.ToolTipText = "Take spaces into account"
        End If
    End Sub
    Sub updateStausBarLabels()
        If chkClear.Checked Then
            lblClr.Text = "CLR"
            lblClr.ToolTipText = "Clear On"
        Else
            lblClr.Text = "NO-CLR"
            lblClr.ToolTipText = "Clear Off"
        End If
        If chkEng.Checked Then
            lblEng.Text = "ENG"
            lblEng.ToolTipText = "ENG notation"
        Else
            lblEng.Text = "GNRL"
            lblEng.ToolTipText = "General notation"
        End If
        If chkRound.Checked Then
            lblRnd.Text = "RND"
            lblRnd.ToolTipText = "Round to 3 decimals"
        Else
            lblRnd.Text = "NO-RND"
            lblRnd.ToolTipText = "No rounding"
        End If
        If chkIgnoreCR.Checked Then
            lblSpaces.Text = "No-Spaces"
            lblSpaces.ToolTipText = "Ignore spaces"
        Else
            lblSpaces.Text = "Spaces"
            lblSpaces.ToolTipText = "Take spaces into account"
        End If
        If chkIgnoreCase.Checked = False Then
            lblCase.Text = "C.Sens."
            lblCase.ToolTipText = "Case sensitive"
        Else
            lblCase.Text = "Not-C.Sens."
            lblCase.ToolTipText = "Not case sensitive"
        End If
        If chkI.Checked Then
            lblImag.Text = "i"
            lblImag.ToolTipText = "'i' for imaginary"
        Else
            lblImag.Text = "j"
            lblImag.ToolTipText = "'j' for imaginary"
        End If
        If Me.iCurGo2 < Me.lstGo2 - 1 Then
            lblNext.Enabled = True
        Else
            lblNext.Enabled = False
        End If
        lblPrev.Enabled = IIf(Me.iCurGo2 > 0, True, False)

        lblZoom.Text = String.Format("{0}%", Math.Floor(factor * 100))
        'Me.StatusStrip.Refresh()
    End Sub


    Private Sub lblNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblNext.Click
        ' Go to next calc.
        If Me.iCurGo2 < Me.lstGo2 - 1 Then
            Me.iCurGo2 += 1
            dspGo2()
        End If
    End Sub

    Private Sub lblPrev_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblPrev.Click
        ' Go to previous calc.
        If Me.iCurGo2 > 0 Then
            Me.iCurGo2 -= 1
            dspGo2()
        Else
            Me.iCurGo2 = 0
        End If
    End Sub

    Sub dspGo2()
        bLoaded = False
        updateStatusBar("")
        bLoaded = True
        If chkClear.Checked Then
            wb.clear()
        End If
        Me.rtbQuery.Text = Me.sTbQry(iCurGo2)
        Me.rtbVars.Text = Me.sTbVar(iCurGo2)
        DspCalc(Me.sTbQry(iCurGo2), Me.vsResultGo2(iCurGo2), vN(iCurGo2))
        updateStausBarLabels()
    End Sub

#End Region

#Region "Context Menu"
    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Clear.Click
        Try
            Dim ctr As RichTextBox = CType(ContextMenuStrip1.SourceControl, RichTextBox)
            ctr.Clear()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FontToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FontToolStripMenuItem.Click
        Try
            Dim ctr As RichTextBox = CType(ContextMenuStrip1.SourceControl, RichTextBox)
            Dim nom As String = LCase(ctr.Name)
            With FontDialog1
                .Font = ctr.Font
                .ShowApply = True
                Dim r As DialogResult = .ShowDialog
                If r = Windows.Forms.DialogResult.Yes OrElse _
                r = Windows.Forms.DialogResult.OK Then
                    ctr.SelectAll()
                    ctr.SelectionFont = .Font
                End If
            End With
        Catch ex As Exception

        End Try
    End Sub
    Private Sub SelectAllAndCopy_Click(sender As Object, e As EventArgs) Handles SelectAllAndCopy.Click
        Try
            Dim ctr As RichTextBox = CType(ContextMenuStrip1.SourceControl, RichTextBox)
            ctr.SelectAll()
            ctr.Copy()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ClearAllPaste_Click(sender As Object, e As EventArgs) Handles ClearAllPaste.Click
        Try
            Dim ctr As RichTextBox = CType(ContextMenuStrip1.SourceControl, RichTextBox)
            ctr.SelectAll()
            ctr.Paste()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        Try
            Dim ctr As RichTextBox = CType(ContextMenuStrip1.SourceControl, RichTextBox)
            ctr.Copy()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Paste_Click(sender As Object, e As EventArgs) Handles Paste.Click
        Try
            Dim ctr As RichTextBox = CType(ContextMenuStrip1.SourceControl, RichTextBox)
            ctr.Paste()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub GoToQuery(sender As Object, e As EventArgs)
        Try
            Int32.TryParse(sender.tag, Me.iCurGo2)
            dspGo2()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub ContextMenuStrip1_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip1.Opening
        getGotoMenu(sender)
    End Sub
    Sub getGotoMenu(sender As Object)
        Try
            Dim vMnItem(Me.lstGo2 - 1) As ToolStripMenuItem
            Dim bIsContextMenu As Boolean = (InStr(LCase(sender.name), "context") > 0)
            With sender
                If bIsContextMenu Then
                    CType(.Items("GotoToolStripMenuItem"),  _
                        ToolStripMenuItem).DropDownItems.Clear()
                Else
                    .DropDownItems.Clear()
                End If
                For i As Int32 = 0 To Me.lstGo2 - 1
                    vMnItem(i) = New ToolStripMenuItem
                    Dim e1 As String = Me.sTbQry(i)
                    Dim e2 As String = Me.sTbVar(i)
                    Dim title As String = String.Empty
                    Dim i1 As Int32 = 20
                    Dim i2 As Int32 = 15
                    If Len(e1) > i1 Then
                        e1 = Mid(e1, 1, i1)
                    End If
                    If Len(e1) Then
                        e1 = Replace(e1, vbCr, "")
                        e1 = Replace(e1, vbLf, "|")
                        e1 = Replace(e1, "||", "|")
                        e1 = Replace(e1, vbTab, ";")
                        e1 = Replace(e1, ",", ";")
                        e1 = Replace(e1, ";;", ";")
                        If Len(e1) > 1 AndAlso e1.Chars(Len(e1) - 1) = "|" Then
                            e1 = Mid(e1, 1, Len(e1) - 1)
                        End If
                    End If
                    If Len(e2) > i2 Then
                        e2 = Mid(e2, 1, i2)
                    End If
                    If Len(e2) Then
                        e2 = Replace(e2, vbCr, "")
                        e2 = Replace(e2, vbLf + vbLf, vbLf)
                        e2 = Replace(e2, vbLf, "|")
                        e2 = Replace(e2, "||", "|")
                        e2 = Replace(e2, vbTab, ";")
                        e2 = Replace(e2, ",", ";")
                        e2 = Replace(e2, ";;", ";")
                        If Len(e2) > 1 AndAlso e2.Chars(Len(e2) - 1) = "|" Then
                            e2 = Mid(e2, 1, Len(e2) - 1)
                        End If
                    End If
                    vMnItem(i).Text = (i + 1).ToString + ") " + e1
                    If Len(e2) Then vMnItem(i).Text += " @ " + e2
                    vMnItem(i).Tag = i
                    AddHandler vMnItem(i).Click, AddressOf Me.GoToQuery
                    If bIsContextMenu Then
                        CType(.Items("GotoToolStripMenuItem"),  _
                            ToolStripMenuItem).DropDownItems.Add(vMnItem(i))
                    Else
                        .DropDownItems.Add(vMnItem(i))
                    End If
                Next
            End With
        Catch ex As Exception
            Dim s1 As String = ex.ToString
        End Try
    End Sub
    Private Sub GotoToolStripMenuItem1_DropDownOpening(sender As Object, e As EventArgs) Handles GotoToolStripMenuItem1.DropDownOpening
        getGotoMenu(sender)
    End Sub
    Private Sub mnGotoPrev_Click(sender As Object, e As EventArgs) Handles mnGotoPrev.Click
        lblPrev_Click(Nothing, Nothing)
    End Sub

    Private Sub mnGotoNext_Click(sender As Object, e As EventArgs) Handles mnGotoNext.Click
        lblNext_Click(Nothing, Nothing)
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        Try
            For i = iCurGo2 To Me.sTbQry.Length - 2
                Me.sTbQry(i) = Me.sTbQry(i + 1)
                Me.sTbVar(i) = Me.sTbVar(i + 1)
            Next
            dspGo2()
        Catch ex As Exception

        End Try
    End Sub

#End Region

End Class
