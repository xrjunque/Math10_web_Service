﻿<ComClass(Lagrangian.ClassId, Lagrangian.InterfaceId, Lagrangian.EventsId)> _
Public Class Lagrangian

#Region "GUID de COM"
    ' Estos GUID proporcionan la identidad de COM para esta clase 
    ' y las interfaces de COM. Si las cambia, los clientes 
    ' existentes no podrán obtener acceso a la clase.
    Public Const ClassId As String = "97de663b-871a-4493-bd35-125a75dbf98d"
    Public Const InterfaceId As String = "23d42bcc-83fd-4d78-80cb-6e5d0480b97a"
    Public Const EventsId As String = "4ed9d793-de60-4023-8474-69c3d7671c13"
#End Region

    ' Una clase COM que se puede crear debe tener Public Sub New() 
    ' sin parámetros, si no la clase no se 
    ' registrará en el registro COM y no se podrá crear a 
    ' través de CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub
    Public nId As Int32
    Dim PolyFn As Polynomial
    Dim ptsMtx As Matrix
    Dim nIntervals As Int32
    Public retPoly As Polynomial
    Public Sub New(ByVal pointsMtx As Matrix)
        Me.ptsMtx = pointsMtx
        nIntervals = Me.ptsMtx.vVect.Length - 1
    End Sub

    Private Function getPointsExpr(ByVal PolyFn As Polynomial, _
                                         ByVal a As Double, _
                                         ByVal b As Double, _
                                         ByVal nIntervals As Int32) As Matrix
        Dim Mc As New Matrix()
        Dim db As Double
        Try
            If Me.nIntervals = 0 Then
                If nIntervals < 1 Then
                    nIntervals = 1
                End If
                Me.nIntervals = nIntervals
            End If
            ReDim Mc.vVect(nIntervals)
            Dim i As Int32
            For i = 0 To nIntervals
                Mc.vVect(i) = New Vector(0.0)
                ReDim Mc.vVect(i).vPoly(1)
                db = ((nIntervals - i) * a + b * i) / nIntervals
                Dim cjo As New Complex(db, 0)
                Mc.vVect(i).vPoly(0) = New Polynomial(cjo)
                Mc.vVect(i).vPoly(1) = New Polynomial(PolyFn.evalCjo(cjo))
            Next
        Catch ex As Exception
            Throw New Exception( _
            String.Format(msg8.msg(24), _
            db.ToString(MathGlobal8.us)))
        End Try
        Return Mc
    End Function
    Public Function lagrangianinterpolation() As Polynomial
        Try
            retPoly = New Polynomial(0.0)
            ' For Lagrangian interpolation let's obtain Lagragian polynomial, this is,
            ' calculate Gn(x) = retPoly = sum[k=0 to n] of( products(j=0 to n, j<>k) of ((x-xj)/(xk - xj)).
            ' i.e.:
            '                     n              n
            '                   ------        -------
            '                   \              |   |  (x - xj)
            ' Gn(x) = retPoly = /      f(xk) * |   | ----------
            '                   -----          |   |  (xk- xj)
            '                   k=0             k<>j
            '
            ' where x is the variable of our Polynomial
            ' and xj, xk (0<=j,k<=n  are the given points
            ' (we have previouly taken nInterval=n points equidistant
            ' between the given points a and b)
            ' and f(xk) is the value, in the point xk, of the function to approximate.
            '
            Dim j, k As Int32
            Dim x As Polynomial = Polynomial.GetPolynomial("x")
            For k = 0 To nIntervals
                Dim polyNumerator As New Polynomial(1.0)
                Dim cjoDenominator As New Complex(1.0, 0.0) ' f(xk)
                For j = 0 To nIntervals
                    If j <> k Then
                        polyNumerator *= (x - ptsMtx.vVect(j).vPoly(0))
                        cjoDenominator *= (ptsMtx.vVect(k).vPoly(0).cf(0) - _
                                   ptsMtx.vVect(j).vPoly(0).cf(0))
                    End If
                Next
                retPoly += polyNumerator * ptsMtx.vVect(k).vPoly(1) / New Polynomial(cjoDenominator)
            Next
        Catch ex As Exception
            Throw ex
        End Try
        Return retPoly
    End Function
    Public Overrides Function ToString() As String
        If retPoly Is Nothing Then
            lagrangianinterpolation()
        End If
        Dim e1 As String = "Polynomial approximation:" + vbCrLf
        e1 += retPoly.ToString()
        Return e1
    End Function
End Class
