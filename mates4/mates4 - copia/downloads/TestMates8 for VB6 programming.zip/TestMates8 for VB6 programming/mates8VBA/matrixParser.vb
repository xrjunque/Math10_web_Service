﻿Imports System.Text.RegularExpressions

<Serializable(), ComClass(matrixParser.ClassId, matrixParser.InterfaceId, matrixParser.EventsId)> _
Public Class matrixParser

#Region "GUID de COM"
    ' Estos GUID proporcionan la identidad de COM para esta clase 
    ' y las interfaces de COM. Si las cambia, los clientes 
    ' existentes no podrán obtener acceso a la clase.
    Public Const ClassId As String = "fde75148-0856-4817-90d6-e609c7234acd"
    Public Const InterfaceId As String = "1fcd5014-44a9-47a4-b56e-aab1e1a0ebbf"
    Public Const EventsId As String = "e95d85da-6ae5-4deb-ab2b-becb6ac6df9b"
#End Region

    ' Una clase COM que se puede crear debe tener Public Sub New() 
    ' sin parámetros, si no la clase no se 
    ' registrará en el registro COM y no se podrá crear a 
    ' través de CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub

    Public ret As retMtx
    Friend vars As VarsAndFns
    Dim parser As exprParser
    Public soe As SystemOfEquations = Nothing
    Dim msgHTML1 As String = "", errMsg1 As String = ""
    Public retCjo(-1) As Complex
    Public retVarNames(-1) As String
    Friend cfg As Config
    Dim maxCols As Int32
    Friend bCaseS As Boolean
    Friend cur As currentMatch

    Public Sub New(ByVal ep As exprParser, ByVal vars As VarsAndFns)
        Me.vars = New VarsAndFns(vars)
        Dim ret(0) As exprParser
        Try
            Dim arr() As exprParser = {ep}
            Array.Copy(arr, ret, 1)
        Catch ex As Exception
            Throw ex
        End Try
        parser = ret(0)
    End Sub
    Function tryParse(ByVal sExpression As String, _
                      ByVal sVars As String, _
                      ByRef result As matrixParser, _
                      ByRef msg As String, _
                      ByRef vars As VarsAndFns, _
                      Optional ByRef cfg As Config = Nothing) As Boolean
        Dim m8 As matrixParser = Me
        Dim bRet As Boolean = False
        Dim bErr As Boolean
        Dim bDetail As Boolean
        Dim LP As Int32 = 0
        Dim RP As Int32 = 0
        Try
            msg = ""
            If cfg IsNot Nothing Then
                Me.cfg = cfg
            ElseIf Me.cfg Is Nothing Then
                Me.cfg = Config.cfg
            End If
            cfg = Me.cfg
            If cfg.oDetail IsNot Nothing Then
                cfg.oDetail.Clear()
            End If
            Me.soe = Nothing
            ReDim retCjo(-1)
            bDetail = cfg.bDetail
            If sExpression Is Nothing Then
                Return False
            End If
            soe = Nothing
            ' supress leading and trailing white spaces:
            sExpression = Regex.Replace(sExpression, "(^(\+|\s)+)|((" + _
                     MathGlobal8.sCol + "|" + MathGlobal8.sRow + "|\s+)$)", "")

            If sExpression.Length = 0 Then
                Return False
            End If
            Dim bVarIsNothing As Boolean
            cfg.initialize()
            If vars Is Nothing Then
                bVarIsNothing = True
                'cfg.initialize()
                vars = New VarsAndFns(cfg)
                If cfg.bUseUnits Then
                    Units.initUnitVars(vars)
                End If
                Dim posAt As Int32 = InStr(sExpression, "@")
                If posAt And posAt < Len(sExpression) Then
                    sVars += vbCrLf + Mid(sExpression, posAt + 1)
                    If posAt > 1 Then
                        sExpression = Left(sExpression, posAt - 1)
                    End If
                End If
                If Len(sVars) Then
                    If Not VarsAndFns.tryParseVariables(sVars, vars, msg) Then
                        m8.errMsg1 = msg
                        Exit Try
                    End If
                    cfg.oDetail.Clear()
                End If
                'Else
                'cfg.initialize()
            End If
            'If cfg.bUseUnits AndAlso vars.getVarIDByName("m", False) = -1 Then
            '    Units.initUnitVars(vars)
            '    cfg.mathGlobal.Initialize(cfg)
            'End If

            m8.vars = vars
            m8.parser = New exprParser(m8, sExpression, sVars, cfg, m8.vars)
            m8.parser.getVars = m8.vars
            cfg.cur = m8.parser.cur
            If cfg.bDetail Then
                cfg.oDetail.cur = cfg.cur
            End If
            cfg.bDetail = bDetail
            m8.parser.cfg = cfg
            If m8.cur.bIsMtxExpr Then
                m8.ret = m8.mtxExpr()
            Else
                m8.parser.getParent = Nothing
                m8.ret = m8.parser.nextExpr()
                m8.ret.curExpr.IsEquation = m8.cur.bIsEquation
            End If
            If bDetail Then
                cfg.oDetail = m8.ret.cfg.oDetail
            End If
            If m8.cur.LP <> m8.cur.RP Then
                Dim sErr As String = String.Empty
                Dim pos As Int32
                currentMatch.checkParentheses( _
                    cfg, sExpression, True, sErr, pos)
            End If
            If Not cur.bEnd Then
                bErr = True
                errMsg1 = msg8.num(13) + vbCrLf '+ cur.toStrCurMatch(True)
            Else
                bRet = True
            End If
        Catch ex As Exception
            If m8.vars IsNot Nothing Then
                ' try evaluating "a posteriori":
                Try
                    If InStr(ex.Message, "Found a matrix") Then
                        Dim sRow() As String = Regex.Split(sExpression, MathGlobal8.sRow)
                        For i As Int32 = 0 To sRow.Length - 1
                            LP = Regex.Matches(sRow(i), "\(").Count
                            RP = Regex.Matches(sRow(i), "\)").Count
                            If LP <> RP Then
                                bErr = True
                                msg = ex.Message + vbCrLf + vbCrLf + _
                                   "(" + String.Format(msg8.num(63), LP, RP, i + 1) + ")"
                                Exit For
                            End If
                        Next
                        If Not bErr Then
                            For i As Int32 = 0 To sRow.Length / 1
                                Dim sCol() As String = Regex.Split(sRow(i), MathGlobal8.sCol)
                                For j As Int32 = 0 To sCol.Length - 1
                                    LP = Regex.Matches(sCol(j), "\(").Count
                                    RP = Regex.Matches(sCol(j), "\)").Count
                                    If LP <> RP Then
                                        bErr = True
                                        msg = ex.Message + vbCrLf + vbCrLf + _
                                           String.Format(msg8.num(64), LP, RP, i + 1, j + 1)
                                        If bErr AndAlso _
                                        m8.parser IsNot Nothing AndAlso _
                                        m8.cur IsNot Nothing AndAlso _
                                        Not m8.cur.bEnd Then
                                            msg += "<br />" + Replace( _
                                                m8.cur.toStrCurMatch(( _
                                                cfg.outputFormat = outputMsgFormat.HTML)), _
                                                ",", "<span style='color:red'>,</span>")
                                            m8.cur.msg = ""
                                        End If
                                        Exit For
                                    End If
                                Next
                            Next
                        End If
                    End If
                Catch ex3 As Exception

                End Try
                If LP = RP Then
                    If bRet Then
                        Try
                            Dim vars2 As New VarsAndFns(m8.vars) ' save current vars
                            m8.vars = New VarsAndFns(cfg) ' use no variables
                            If m8.ret IsNot Nothing AndAlso _
                            m8.cur.bIsMtxExpr Then
                                m8.ret = m8.mtxExpr()
                            ElseIf m8.ret IsNot Nothing Then
                                m8.parser.getParent = Nothing
                                m8.ret = m8.parser.nextExpr()
                            End If
                            If bDetail Then
                                cfg.oDetail = m8.ret.cfg.oDetail
                            End If
                            If Not m8.ret Is Nothing Then
                                For i As Int32 = 0 To m8.ret.rows - 1
                                    For j As Int32 = 0 To m8.ret.cols - 1
                                        Try
                                            Dim expr As Expression = m8.ret.exprMtx.getExpr(i, j)
                                            If expr IsNot Nothing Then
                                                m8.ret.exprMtx.getExpr(i, j) = expr.evalExprToExpr(vars2)
                                            End If
                                        Catch ex3 As Exception

                                        End Try
                                    Next
                                Next
                            End If
                        Catch ex2 As Exception

                        End Try
                        msg = ex.Message ' ex.ToString + ex.StackTrace ' ex.Message
                        bErr = True
                        If m8.parser IsNot Nothing Then
                            m8.cur.msg = msg '  "B" + ex.ToString + ex.StackTrace ' ex.Message
                        End If
                    Else
                        msg = ex.Message
                    End If
                End If
            End If
        Finally
            Dim sErrCurMatch As String = ""
            Try
                If bErr AndAlso _
                m8.parser IsNot Nothing AndAlso _
                m8.cur IsNot Nothing AndAlso _
                Not m8.cur.bEnd AndAlso LP = RP Then
                    sErrCurMatch = "<br />" + m8.cur.toStrCurMatch(True)
                    m8.cur.msg = ""
                End If
            Catch ex2 As Exception

            End Try
            If m8.parser IsNot Nothing Then
                m8.msgHTML1 = m8.cur.msg + sErrCurMatch
            Else
                m8.errMsg1 = msg
            End If
        End Try
        result = m8
        Return bRet
    End Function
    Public Sub setConfig(cfg As Config)
        Me.cfg = cfg
        Me.cfg.initialize()
    End Sub
    Public Class parseObject
        Public sExpression As String
        Public oVars As VarsAndFns
        Public sVars As String
        Public cfg As Config
        Public msgErr As String
        Public msgHTML As String
        Public mP As matrixParser
        Public Sub New(ByRef mP As matrixParser, _
                     ByVal sExpression As String, _
                     Optional ByVal sVars As String = "", _
                     Optional ByRef vars As VarsAndFns = Nothing, _
                     Optional ByRef cfg As Config = Nothing)
            Me.mP = mP
            Me.sExpression = sExpression
            Me.oVars = vars
            Me.sVars = sVars
            Me.cfg = cfg
        End Sub
        Public Sub parse()
            mP.parse(sExpression, sVars, oVars, cfg)
        End Sub
    End Class
    Public Sub parse(ByVal sExpression As String, _
                     Optional ByVal sVars As String = "", _
                     Optional ByRef vars As VarsAndFns = Nothing, _
                     Optional ByRef cfg As Config = Nothing)
        'Dim msg As String = ""
        Dim result As New matrixParser()
        Try
            Dim i, j As Int32
            If InStr(sExpression, "?") Then
                ' arrange input string:
                Dim e1() As String = Split(sExpression, "?")
                sExpression = e1(0)
                If e1.Length > 1 Then
                    e1(0) = ""
                    sVars = Join(e1, "|")
                End If
            End If
            If Not tryParse(sExpression, sVars, result, Me.errMsg1, vars, cfg) Then
                If result IsNot Nothing Then
                    Me.msgHTML1 = result.msgHTML1
                    Me.errMsg1 = result.errMsg1
                End If
                Exit Try
            End If
            Dim oVar As New VarsAndFns(cfg)
            Dim rup As New ReduceExprUsingPolynomials(oVar)
            For i = 0 To ret.exprMtx.Rows - 1
                For j = 0 To ret.exprMtx.ColsInRow(i) - 1
                    Dim expr As Expression = ret.exprMtx.getExpr(i, j)
                    If expr IsNot Nothing Then
                        If ret.exprMtx.getExpr(i, j).IsComplex Then
                        ElseIf ret.exprMtx.getExpr(i, j).IsPolynomial Then
                            ret.exprMtx.getExpr(i, j).getPolynomial.opReduceCommonExponents()
                            ret.exprMtx.getExpr(i, j).getPolynomial.tryReducePolyResto()
                        Else
                            'ret.exprMtx.getExpr(i, j) = _
                            'ret.exprMtx.getExpr(i, j).reduceSummands()

                            expr.reduce()
                            Dim exprReduced As Expression = rup.ReduceUsingPolynomials(expr)
                            exprReduced = rup.ReduceUsingPolynomials(exprReduced)
                            If cfg.bDetail Then
                                Dim e1 As String = expr.ToStringExpr(cfg)
                                Dim e2 As String = exprReduced.ToStringExpr(cfg)
                                If e1 <> e2 Then
                                    cfg.oDetail.Add(e1 + " =" + vbCrLf + "=" + e2)
                                    'cfg.oDetail.Add("= " + e2)
                                End If
                            End If
                            ret.exprMtx.getExpr(i, j) = exprReduced ' rup.ReduceUsingPolynomials(expr)
                            'If Len(expr.ToString) * 2 < Len(ret.exprMtx.getExpr(i, j).ToString) Then
                            '    ret.exprMtx.getExpr(i, j) = expr
                            'End If
                        End If
                    End If
                Next
            Next

            If ret.getParser IsNot Nothing AndAlso _
            ret.getParser.cur.bIsDiffEq Then
                ret.curExpr.cfg.cur = ret.getParser.cur
                ret.vars = _
                    Differential_Equations.resolveSolvable(ret.curExpr, ret)
            ElseIf ret.getParser IsNot Nothing AndAlso _
            ret.getParser.cur.bIsEquation Then
                'Dim nEq As Int32 = 0
                For i = 0 To ret.exprMtx.Rows - 1
                    'If ret.exprMtx.getExpr(i, 0).IsEquation Then
                    '    nEq += 1
                    'End If
                    ret.exprMtx.getExpr(i, 0).IsEquation = True
                Next
                'If nEq <> 0 AndAlso nEq <> ret.exprMtx.Rows Then
                '    errMsg1 = msg8.num(13) + vbCrLf '+ cur.toStrCurMatch(True)
                '    Exit Try
                'End If

                'Dim cfg1 As New Config(cfg)
                'Dim bDetail As Boolean = cfg.bDetail
                'cfg1.bDetail = False
                Dim bDetail As Boolean = cfg.bDetail
                'cfg.bDetail = False
                soe = New SystemOfEquations( _
                 Nothing, ret.exprMtx, getVars, Me.getParser.cur, cfg)
                If soe Is Nothing Then
                    Exit Try
                End If
                If Not soe.resolveSysOfEqs(cfg) Then
                    If soe.sErrMsg.Length Then
                        Me.errMsg1 = soe.sErrMsg
                    ElseIf soe.tipo = eqSysType.isAPolynomial Then
                        ret.curExpr = New Expression(soe.poly)
                        ' a non-lineal eq. transformed into a polynomial:
                        ReDim retCjo(soe.resultValues.Length - 1), _
                            retVarNames(0)
                        For i = 0 To soe.resultValues.Length - 1
                            retCjo(i) = soe.resultValues(i)
                        Next
                        retVarNames = soe.resultVars
                    Else
                        If Len(soe.sErrMsg) = 0 Then
                            soe = Nothing
                        End If
                    End If
                ElseIf soe.tipo <> eqSysType.isAPolynomial Then
                    'ReDim retCjo(soe.resultValues.Length - 1), _
                    '    retVarNames(soe.resultVars.Length - 1)
                    'For i = 0 To soe.resultValues.Length - 1
                    '    'Dim varId As Int32 = vars.getVarIDByName( _
                    '    '    soe.resultVars(i))
                    '    retCjo(i) = soe.resultValues(i)
                    'Next
                    'retVarNames = soe.resultVars
                    retCjo = soe.resultValues
                    retVarNames = soe.resultVars
                Else
                    ret.curExpr = New Expression(soe.poly)
                    retCjo = soe.resultValues
                    retVarNames = soe.resultVars
                    'retVarNames = soe.resultVars
                    'ReDim retCjo(soe.resultValues.Length - 1)
                    ''retCjo = _
                    '' ret.exprMtx.RowsToArrayCjo()
                    'For i = 0 To soe.resultValues.Length - 1
                    '    'Dim varId As Int32 = vars.getVarIDByName( _
                    '    '    soe.resultVars(i))
                    '    retCjo(i) = soe.resultValues(i)
                    'Next
                End If
                cfg.bDetail = bDetail
            Else
                retVarNames = vars.getNamesList
                If ret.exprMtx.Cols = 1 Then
                    ReDim retCjo(ret.exprMtx.Rows - 1)
                    Dim bRetCjoIsNull As Boolean = True
                    For i = 0 To ret.exprMtx.Rows - 1
                        If ret.exprMtx.getExpr(i, 0) IsNot Nothing Then
                            'Throw New Exception(msg8.num(13)) ' n/a
                            'Else
                            If ret.exprMtx.getExpr(i, 0).IsComplex Then
                                retCjo(i) = ret.exprMtx.getExpr(i, 0).toComplex
                                bRetCjoIsNull = False
                            ElseIf ret.exprMtx.getExpr(i, 0).IsPolynomial Then
                                ret.exprMtx.getExpr(i, 0).getPolynomial.tryReducePolyResto()
                                Dim expr As Expression = ret.exprMtx.getExpr(i, 0)
                                If expr IsNot Nothing AndAlso _
                                cfg.bUseUnits AndAlso _
                                cfg.bReduceUnits AndAlso _
                                expr.IsPolynomial Then
                                    expr = Units.reduceUnits(expr)
                                    ret.exprMtx.getExpr(i, 0) = expr
                                End If
                            Else
                                'ret.exprMtx.getExpr(i, 0) = _
                                'ret.exprMtx.getExpr(i, 0).reduceSummands()
                                'ret.exprMtx.getExpr(i, 0).reduce()
                                Dim expr As Expression = _
                                    New Expression(ret.exprMtx.getExpr(i, 0))
                                If expr IsNot Nothing AndAlso _
                                cfg.bUseUnits AndAlso _
                                cfg.bReduceUnits AndAlso _
                                expr.IsPolynomial Then
                                    expr = Units.reduceUnits(expr)
                                End If
                                Dim exprReduced As Expression = rup.ReduceUsingPolynomials(expr)
                                exprReduced = rup.ReduceUsingPolynomials(exprReduced)
                                If cfg.bDetail Then
                                    Dim e1 As String = expr.ToStringExpr(cfg)
                                    Dim e2 As String = exprReduced.ToStringExpr(cfg)
                                    If e1 <> e2 Then
                                        cfg.oDetail.Add(e1 + " =" + vbCrLf + "=" + e2)
                                        'cfg.oDetail.Add("= " + e2)
                                    End If
                                End If
                                ret.exprMtx.getExpr(i, 0) = exprReduced ' rup.ReduceUsingPolynomials(expr)
                                'If Len(expr.ToString) * 1.2 < Len(ret.exprMtx.getExpr(i, 0).ToString) Then
                                'ret.exprMtx.getExpr(i, 0) = expr
                                'End If
                            End If
                        End If
                    Next
                    If bRetCjoIsNull OrElse i < ret.rows Then
                        ReDim retCjo(-1)
                    End If
                Else
                    'Dim i, j As Int32
                    For i = 0 To ret.exprMtx.Rows - 1
                        For j = 0 To ret.exprMtx.ColsInRow(i) - 1
                            Dim expr As Expression = ret.exprMtx.getExpr(i, j)
                            If expr IsNot Nothing Then
                                If ret.exprMtx.getExpr(i, j).IsComplex Then
                                ElseIf ret.exprMtx.getExpr(i, j).IsPolynomial Then
                                    ret.exprMtx.getExpr(i, j).getPolynomial.tryReducePolyResto()
                                    If cfg.bUseUnits AndAlso _
                                    cfg.bReduceUnits AndAlso _
                                    expr.IsPolynomial Then
                                        expr = Units.reduceUnits(ret.exprMtx.getExpr(i, j))
                                    End If
                                Else
                                    'ret.exprMtx.getExpr(i, j) = _
                                    'ret.exprMtx.getExpr(i, j).reduceSummands()
                                    If cfg.bUseUnits AndAlso expr.IsPolynomial Then
                                        expr = Units.reduceUnits(expr)
                                    End If

                                    expr.reduce()
                                    Dim exprReduced As Expression = rup.ReduceUsingPolynomials(expr)
                                    exprReduced = rup.ReduceUsingPolynomials(exprReduced)
                                    If cfg.bDetail Then
                                        Dim e1 As String = expr.ToStringExpr(cfg)
                                        Dim e2 As String = exprReduced.ToStringExpr(cfg)
                                        If e1 <> e2 Then
                                            cfg.oDetail.Add(e1 + " =" + vbCrLf + "=" + e2)
                                            'cfg.oDetail.Add("= " + e2)
                                        End If
                                    End If
                                    ret.exprMtx.getExpr(i, j) = exprReduced ' rup.ReduceUsingPolynomials(expr)
                                    'If Len(expr.ToString) * 2 < Len(ret.exprMtx.getExpr(i, j).ToString) Then
                                    '    ret.exprMtx.getExpr(i, j) = expr
                                    'End If
                                End If
                            End If
                        Next
                    Next

                    'Dim oVar As New VarsAndFns(cfg)
                    'Dim mtx As Matrix = ReduceExprUsingPolynomials.ReduceUsingPolynomials(ret.exprMtx, oVar)
                    'ret.exprMtx = ReduceExprUsingPolynomials.reducedPolynToExprMatrix(New ExprMatrix(mtx), oVar)

                End If
            End If
        Catch ex As Exception
            Me.errMsg1 = ex.Message ' ex.tostring
        Finally
            If ret Is Nothing AndAlso _
            Len(Me.errMsg1) = 0 Then
                Me.errMsg1 = msg8.num(13)
            End If
        End Try
    End Sub
    Public ReadOnly Property msgHTML As String
        Get
            Return msgHTML1
        End Get
    End Property
    Public ReadOnly Property errMsg As String
        Get
            Return errMsg1
        End Get
    End Property
    Public Function getVars() As VarsAndFns
        Return vars
    End Function
    Public Function getParser() As exprParser
        Return Me.parser
    End Function
    Public Sub setParser(ByVal parser As exprParser)
        Me.parser = parser
    End Sub
    Public Function mtxExpr(Optional maxCols As Int32 = 0) As retMtx
        Dim ret As New retMtx(parser)
        Try
            Me.maxCols = maxCols
            If cur.bEnd AndAlso _
            parser.ret IsNot Nothing Then
                ret.exprMtx = New ExprMatrix(parser.ret.curExpr)
                Exit Try
            End If
            ret = term()
            Do While Not cur.bEnd
                If Regex.IsMatch(cur.str, "[+]") Then
                    Dim retB As retMtx = term()
                    ret.exprMtx += retB.exprMtx
                ElseIf Regex.IsMatch(cur.str, "[-]") Then
                    Dim retB As retMtx = term()
                    ret.exprMtx -= retB.exprMtx
                Else
                    Exit Do
                End If
            Loop

            If ret.exprMtx IsNot Nothing AndAlso _
            ret.exprMtx.getExpr(0, 0) IsNot Nothing Then
                ret.exprMtx.getExpr(0, 0).IsEquation = parser.bIsEquation
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message)
        Finally
            If ret Is Nothing Then
                Throw New Exception(msg8.num(13))
            End If
            Me.ret = ret
        End Try
        'Me.ret = ret ' New retMtx(ret)
        Return ret
    End Function
    Private Function term() As retMtx
        Dim ret As New retMtx(parser)
        Try
            ret = exponente()
            Do While Not cur.bEnd
                ret.exprMtx.cfg = cfg
                If Regex.IsMatch(cur.str, "[*]") Then
                    Dim retB As retMtx = exponente()
                    ret.exprMtx *= retB.exprMtx
                ElseIf Regex.IsMatch(cur.str, "[/]") Then
                    Dim retB As retMtx = exponente()
                    ret.exprMtx /= retB.exprMtx
                Else
                    Exit Do
                End If
            Loop
        Catch ex As Exception
            Throw New Exception(ex.Message)
        Finally
            If ret Is Nothing Then
                Throw New Exception(msg8.num(13))
            End If
        End Try
        Return ret
    End Function
    Private Function exponente() As retMtx
        Dim ret As New retMtx(parser)
        Try
            ret = factor()
            Do While Not cur.bEnd AndAlso _
            Regex.IsMatch(cur.str, "[\^]")
                Dim rmExp(0) As retMtx
                rmExp(0) = factor()
                'rmExp(0).cfg = Me.cfg
                Dim irve As Int32 = 0
                Do While Not cur.bEnd AndAlso _
                Regex.IsMatch(cur.str, "[\^]")
                    irve += 1
                    ReDim Preserve rmExp(irve)
                    rmExp(irve) = factor()
                    'rmExp(irve).cfg = cfg
                Loop
                For i As Int32 = irve - 1 To 1 Step -1
                    rmExp(i - 1).exprMtx ^= rmExp(i).exprMtx
                Next
                ret.exprMtx ^= rmExp(0).exprMtx
            Loop
        Catch ex As Exception
            Throw New Exception(ex.Message)
        Finally
            If ret Is Nothing Then
                Throw New Exception(msg8.num(13))
            End If
        End Try
        Return ret
    End Function
    Private Function factor() As retMtx  ' expression treatment
        Dim ret As New retMtx(parser)
        Try
siguiente:
            ret = Me.parser.nextExpr()

            If Me.cur.bEnd OrElse _
            Me.cur.tipo = currentMatch.exprType.RP Then
                Dim tipo As currentMatch.exprType
                Dim subT1 As currentMatch.exprSubType1
                Dim subT2 As currentMatch.exprSubType1
                Dim m As Match = cur.testNextMatch(0, tipo, subT1, subT2)
                If subT1 <> currentMatch.exprSubType1.mtxOp AndAlso _
                subT1 <> currentMatch.exprSubType1.mtxFn Then
                    Exit Try
                End If
            ElseIf Me.cur.tipo = currentMatch.exprType.LP Then
                'Dim sgn As Int32 = ret.sgn
                ret = Me.parser.nextExpr()
                'ret.sgn *= sgn
            ElseIf Me.cur.tipo = currentMatch.exprType.custFn Then
                Dim fn As customFn = Nothing
                ' retrive custom function fn:
                vars.IsCustomFn(Me.cur.str, fn)
                'Dim sgn As Int32 = ret.sgn
                ' get fn's parameters:
                Dim sParams As String = ""

                Dim fnRV As retMtx = Me.parser.nextExpr()
                sParams += fnRV.curExpr.ToStringExpr(cfg)
                Do While Me.cur.m.Groups("col").Success OrElse _
                    Me.cur.m.Groups("param").Success
                    Me.cur.doNext()
                    fnRV = Me.parser.nextExpr()
                    sParams += customFn.sParamDelimiter + fnRV.curExpr.ToStringExpr(cfg)
                Loop
                ' eval the function at sParams:
                ret.curExpr = _
                        fn.evalMtx(sParams)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
        Return ret
    End Function
    Public Overloads Function ToString(cfg As Config) As String
        Try
            Dim format As outputMsgFormat = cfg.outputFormat
            If soe Is Nothing And ret IsNot Nothing Then
                Dim e1 As String = ret.toStringRetVal(cfg)
                If cfg.bUseUnits Then
                    Dim sL As String = Trim(e1)
                    If sL.Chars(0) = "-" Then
                        sL = Mid(sL, 2)
                    End If
                    If cfg.bUseUnits Then
                        e1 = Replace(e1, "*", " ")
                        If Len(sL) < 4 AndAlso _
                        Regex.IsMatch(sL, Units.vUCS) Then
                            If sL.Chars(0) < "0" OrElse _
                             sL.Chars(0) > "9" Then
                                If sL = e1 Then
                                    e1 = "1 " + sL
                                Else
                                    e1 = "-1 " + sL
                                End If
                            End If
                        End If
                    End If
                End If
                e1 = Regex.Replace(e1, "(?<!(\^|e))\-", " -") ' "-" --> " -", except "^-" or "e-" for ex. "x^-3" "1.2e-2"
                e1 = Replace(e1, "+", " +")
                If format = outputMsgFormat.HTML Then
                    e1 = MathGlobal8.getTable(e1, "black")
                End If
                Return e1
            ElseIf soe IsNot Nothing Then
                Dim e1 As String = soe.ToStringInfo(cfg)
                e1 = Regex.Replace(e1, "(?<!(\^|e))\-", " -") ' "-" --> " -", except "^-" or "e-" for ex. "x^-3" "1.2e-2"
                e1 = Replace(e1, "+", " +")
                If soe.getPolynomial IsNot Nothing Then
                    Me.retCjo = soe.getPolynomial.roots.cjo
                End If
                If format = outputMsgFormat.HTML Then
                    Return MathGlobal8.getTable(e1, "black")
                Else
                    e1 = ""
                    For i = 0 To Me.retCjo.Length - 1
                        e1 += Me.retCjo(i).toStringComplex(cfg)
                        If soe.unit IsNot Nothing Then
                            e1 += " " + soe.unit.ToString
                        End If
                        e1 += vbCrLf
                    Next
                    Return e1
                End If
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Return MyBase.ToString()
    End Function
    Public Overloads Function ToString() As String
        Dim cfg As Config = Config.cfg
        Dim omf As outputMsgFormat = cfg.outputFormat
        cfg.outputFormat = outputMsgFormat.plainText
        Dim e1 As String = ToString(cfg)
        cfg.outputFormat = omf
        Return e1
    End Function
    Public Function toStringMatrixParser(cfg As Config) As String
        Try
            If soe Is Nothing And ret IsNot Nothing Then
                Return ret.toStringRetVal(cfg)
            ElseIf soe IsNot Nothing Then
                Dim e1 As String = soe.ToStringInfo(cfg)
                If soe.getPolynomial IsNot Nothing Then
                    Me.retCjo = soe.getPolynomial.roots.cjo
                End If
                Return e1
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Return MyBase.ToString()
    End Function
    Public ReadOnly Property toStrMtxParser As String
        Get
            Return toStringMatrixParser(Config.cfg)
        End Get
    End Property
End Class

