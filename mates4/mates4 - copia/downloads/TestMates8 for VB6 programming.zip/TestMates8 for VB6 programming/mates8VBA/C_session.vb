﻿'<Serializable(), ComClass(C_session.ClassId, C_session.InterfaceId, C_session.EventsId)> _
<Serializable()> _
Public Class C_session

    '#Region "GUID de COM"
    '    ' Estos GUID proporcionan la identidad de COM para esta clase 
    '    ' y las interfaces de COM. Si las cambia, los clientes 
    '    ' existentes no podrán obtener acceso a la clase.
    '    Public Const ClassId As String = "1899b7a2-b202-4427-9a53-aad6ac3895b8"
    '    Public Const InterfaceId As String = "3301ee91-89e8-4344-8959-f2de75f46ff0"
    '    Public Const EventsId As String = "7e58d7ad-f6ad-47e6-af54-266a213ffc5d"
    '#End Region

    ' Una clase COM que se puede crear debe tener Public Sub New() 
    ' sin parámetros, si no la clase no se 
    ' registrará en el registro COM y no se podrá crear a 
    ' través de CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub
    Public Shared xi1(), xf1(), yAuto1() As Double
    Public Shared psfn(), psf2(), psf3() As String
    Public Shared Property sfn(id As Int32) As String
        Get
            Return psfn(id)
        End Get
        Set(value As String)
            psfn(id) = value
        End Set
    End Property
    Public Shared Property sf2(id As Int32) As String
        Get
            Return psf2(id)
        End Get
        Set(value As String)
            psf2(id) = value
        End Set
    End Property
    Public Shared Property sf3(id As Int32) As String
        Get
            Return psf3(id)
        End Get
        Set(value As String)
            psf3(id) = value
        End Set
    End Property
    Public Shared Property xi(ByVal id As Int32) As Double
        Get
            Return xi1(id)
        End Get
        Set(ByVal value As Double)
            xi1(id) = value
        End Set
    End Property
    Public Shared Property xf(ByVal id As Int32) As Double
        Get
            Return xf1(id)
        End Get
        Set(ByVal value As Double)
            xf1(id) = value
        End Set
    End Property
    Public Shared Property yAuto(ByVal id As Int32) As Double
        Get
            Return yAuto1(id)
        End Get
        Set(ByVal value As Double)
            yAuto1(id) = value
        End Set
    End Property
End Class
