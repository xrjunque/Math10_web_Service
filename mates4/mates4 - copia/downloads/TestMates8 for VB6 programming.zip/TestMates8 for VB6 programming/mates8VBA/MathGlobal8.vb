﻿Imports System.Reflection
Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Runtime.Serialization

<Serializable(), ComClass(MathGlobal8.ClassId, MathGlobal8.InterfaceId, MathGlobal8.EventsId)> _
Public Class MathGlobal8

#Region "GUID de COM"
    ' Estos GUID proporcionan la identidad de COM para esta clase 
    ' y las interfaces de COM. Si las cambia, los clientes 
    ' existentes no podrán obtener acceso a la clase.
    Public Const ClassId As String = "22197c30-c4a0-4f4d-bb74-340d1bce815c"
    Public Const InterfaceId As String = "b720c9fd-291e-486a-9872-1de4180b85d0"
    Public Const EventsId As String = "f320cb37-324f-4f78-a55f-f2808c1702ce"
#End Region

    ' Una clase COM que se puede crear debe tener Public Sub New() 
    ' sin parámetros, si no la clase no se 
    ' registrará en el registro COM y no se podrá crear a 
    ' través de CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub

    Public Shared us As New Globalization.CultureInfo("en-US")
    Public Shared vSubstitute() As String = {"(+", ":", "÷", "–", Chr(&HBC), Chr(&HBD), Chr(&HBE), Chr(&HB2), Chr(&HB3), _
     ChrW(&H2212), ChrW(&H3C0), "〖", "〗", "⅞", "**", "", _
                        "П", "⁹", "⁸", "⁷", "⁶", "⁵", "⁴", "³", "²", _
                        "−", "×", "arcsin", "arccos", "arctan", _
                        "arccot", "arccsc", "arcsec", "limit", _
                        "infinite", "infinity", "infinit" _
                        }
    Public Shared vSubstituteBy() As String = {"(", "/", "/", "-", "(1/4)", "(1/2)", "(3/4)", "^2", "^3", _
     "-", "PI", "(", ")", "(7/8)", "^", "-", _
                        "(PI)", "^9", "^8", "^7", "^6", "^5", "^4", "^3", "^2", _
                        "-", "*", "asin", "acos", "atan", _
                        "acot", "acsc", "asec", "lim", _
                        "∞", "∞", "∞" _
                        }
    ' ³ ² ¼ ½ ¾
    ' ³ ² ¼ ½ ¾
    Public Shared sSubstitute As String
    Public Shared reSubstitute As Regex

    Public Shared vFn() As String = { _
        "identity", "echelon", "cof", "eigenvalues", "eigenvectors", "transpose", "adj", "trace", "roots", "rank", _
        "det", "factor", "jacobian", "lagrangianinterpolation", "orthog", "jordan", _
        "floor", "logten", "round", _
        "acosh", "acoth", "acsch", "asech", "asinh", "atanh", "factor", "roots", _
        "coth", "csch", "rank", "sech", _
        "acos", "acot", "acsc", "asec", "asin", "atan", "conj", "cosh", "logtwo", "norm", "sign", "sinh", "sqrt", "tanh", _
        "abs", "arg", "cos", "cot", "csc", "exp", "log", "mod", "sec", "sin", "sqr", "tan", _
        "gcd", "lim", _
        "im", "ln", "re", "diff"}
    Public Shared vInvFn() As String = { _
        "", "", "", "", "", "", "", "", "", "", _
        "", "", "", "", "", "", _
        "", "", "", _
        "cosh", "coth", "csch", "sech", "sinh", "tanh", "", "", _
        "acoth", "acsch", "", "asech", _
        "cos", "cot", "csc", "sec", "sin", "tan", "", "acosh", "", "", "", "asinh", "", "atanh", _
        "", "", "acos", "acot", "acsc", "ln", "exp", "", "asec", "asin", "", "atan", _
        "", "", _
        "", "exp", "", ""}
    Shared vIntegral() As String = {"integral", "integrate", "∫", "det"}
    'Shared vMtxFn(-1) As String '= { _
    '"lagrangianinterpolation", _
    '"jacobian", "orthog", "factor"}
    Public Shared sFn As String
    Public Shared vCntsCaseNonSen() As String = {"pi"}
    Public Shared vCntsCaseSen() As String = {"e"}
    Shared sCnts As String = Join(vCntsCaseSen, "|") + _
        "|(?i)" + Join(vCntsCaseNonSen, "|") + "(?-i)"

    Public Shared sGreek As String = _
    "ΑαΒβΓγΔδΕεΖζΗηΘθΙιΚκΛλΜμΝνΞξΟοΠπΡρΣσΤτΥυΦφΧχΨψΩω" + "∞"
    Public nomVarsToAppend As String = ""
    Public Shared vOpWeight() As Int32 = {1, 2, 3, 3, 4, 5, 6}

    Public Shared vOp() As String = {"+", "-", "*", "/", "%", "^", "!"}
    Public Shared vLgOp() As String = {"and", "or", "xor", "not", "nand", "nor"}

    Public Shared sCnt As String '= "(?<cnt>(?i)(" + sCnts + "){1}(?-i))"
    Public Shared sLP As String = "(?<lp>\(|\{|\[){1}"
    Public Shared sRP As String = "(?<rp>\)|\}|\]){1}"
    Public Shared sCol As String = "(?<col>(\;|\t|\,){1})"
    Public Shared sRow As String = "(?<row>(\r\n|\r|\n|\|){1,})"
    Public Shared sSpace As String = "(?<space>[ ]+)"
    Public Shared sOp As String = "(?<op>\" + Join(vOp, "|\") + "{1})"
    Public Shared sLgOp As String = "(?<lgOp>(?i)" + Join(vLgOp, "|") + "(?-i))"
    Shared sMtxOp As String = "((\r|\n|\|)+(?<mtxOp>\" + Join(vOp, "|\") + ")(\r|\n|\|)+)"
    Shared sHex As String = "(?<hex>(?i)&h([.0-9b-f]|[a](?!nd))*(?-i))"
    Shared sDec As String = "(?<dec>&(d|D)[.0-9]*)"
    Shared sOct As String = "(?<oct>&(o|O)[.0-7]*)"
    Shared sBin As String = "(?<bin>&(b|B)[.0-7]*)"
    Shared sSqrt As String = "(?<fn>(?<sqr>√))"
    'Public Shared sNum = "(?<num>(([0-9]{1,3},[0-9]{3}(?![0-9])|[0-9])+\.?[0-9]*|[0-9]*\.?[0-9]+)([eE][-+]?[0-9]+)?)"
    Public Shared sNum As String = "(?<num>((\d{1,3}((\,\d{3})+)(\.[0-9]+)?)|[\.\d]+)([eE][-+]?[0-9]+)?)"
    Shared sRad As String = "(?<rad>&(?i)rad(?-i))"
    Shared sDeg As String = "(?<deg>&(?i)deg(?-i))"
    Shared sGrad As String = "(?<grad>&(?i)grad(?-i))"
    Dim vAll() As String

    Public sVar As String = "(?<var>_([0-9a-zA-Z_" + sGreek + "])*{})"
    Public sAt As String = "(?<at>@(.)+)(?='|$|" + sRow + ")"
    Public Shared sComment As String = "(?<comment>\/\*(.)+\*\/|((\'|\/\/)(.)+(" + sRow + "?|$)))"
    Public sVar2 As String
    Dim sDerResp As String
    Dim sIntegResp As String

    Dim sAll As String
    'Public Shared integralCnst As String = "_constant"
    Dim iIntegralCnst As Int32 = 1
    Public Const rad2Degrees As Double = 180 / Math.PI
    Public Const rad2Centesimal As Double = 200 / Math.PI
    Public Const degree2Radians As Double = Math.PI / 180
    Public Const centesimal2Rad As Double = Math.PI / 200
    Public Const maxPolyDegree As Int32 = 130
    Friend Shared ticksStart, timeOutms, lnCount As Long


    Public Sub New(cfg As Config)
        Initialize(cfg)
    End Sub
    Public Function sAll2() As String
        If InStr(sAll, "{}") = 0 Then
            Return sAll
        Else
            If nomVarsToAppend.Length = 0 Then
                Return Replace(sAll, "{}", "")
            End If
        End If
        Return Replace(sAll, "{}", "|" + nomVarsToAppend)
        'Return Replace(sAll, "{}", "|" +oVars.getVarsStrListToAppend 
    End Function
    Public Sub Initialize(cfg As Config)
        'Optional ByVal sImaginary As String = "i")
        Try
            'If cfg Is Nothing Then
            'cfg = New Config
            'End If
            iIntegralCnst = 1
            Dim i, j, k As Int32
            'sImg1 = cfg.sImg
            'sFn = "(?<fn>(?i)(?<mtxFn>" + Join(vMtxFn, "|") + ")|" + Join(vFn, "|") + _
            '    "|(?<integral>" + Join(vIntegral, "|") + ")" + _
            '     "(?-i))"
            sFn = "(?<fn>(?i)" + Join(vFn, "|") + _
                "|(?<integral>" + Join(vIntegral, "|") + ")" + _
                 "(?-i))"
            Dim sMsg As String = String.Empty

            If cfg.bUseUnits Then
                sFn = Units.vUCS + "|" + sFn
            End If

            If cfg.bVarName1Char Then
                sVar2 = "(?<var2>([a-zA-Z" + sGreek + "]){1})"
            ElseIf Not cfg.bNumsInVarName Then
                sVar2 = "(?<var2>([a-zA-Z" + sGreek + "]){1}([a-zA-Z" + sGreek + "]){0,1})"
            Else
                sVar2 = "(?<var2>([a-zA-Z" + sGreek + "]){1}([0-9a-zA-Z" + sGreek + "]){0,1})"
            End If
            sDerResp = "(?<Dx>(?i)(derivative|derivate|d)(?<DOrder>[1-9]?)(?<resp>" + _
                                            sVar + "|" + sVar2 + "?)" + "(?-i))(?=\()"
            sIntegResp = "(?<Idx>d(?i)(?<IResp>" + _
                                            sVar + "|" + sVar2 + "?)" + "(?-i)(?<!=\)))"
            sSubstitute = ""
            For i = 0 To vSubstitute.Length - 1
                For j = 0 To vSubstitute(i).Length - 1
                    Dim b() As Byte = System.Text.UnicodeEncoding.Unicode.GetBytes( _
                        vSubstitute(i).Chars(j))
                    Dim asc1 As Int32 = 0
                    For k = b.Length - 1 To 0 Step -1
                        asc1 = asc1 * 256 + CInt(b(k))
                    Next
                    Dim sHex As String = Hex(asc1)
                    Do While sHex.Length < 4
                        sHex = "0" + sHex
                    Loop
                    sSubstitute += String.Format("\u{0}", sHex)
                Next
                sSubstitute += "|"
            Next
            sSubstitute = "(?<substitute>" + Left(sSubstitute, Len(sSubstitute) - 1) + ")"

            Dim sImag As String

            If cfg.bVarName1Char Then
                sCnt = "(?<cnt>(" + sCnts + "){1})"
                sImag = "(?<img>" + cfg.sImg + "{1})"
            Else
                ' e+g = 2.718.. + g, but
                ' ae+g is a variable. The same stands for "pi" or "i".
                ' So "aee+g" becomes ---> "2.718*ae + g".
                ' Constants (or 'i'/'j') can't be preceeded or followed by a letter:
                sCnt = "(?<cnt>(?i)(?<![A-Za-z]+)(" + sCnts + "){1}(?![A-Za-z]+)(?-i))"
                sImag = "(?<img>(?<![A-Za-z]+)" + cfg.sImg + "(?![A-Za-z]+){1})"
            End If
            vAll = New String() {sComment, _
                                 sSubstitute, sFn, sDerResp, sIntegResp, sNum, sHex, sDec, sOct, sBin, _
                                 sRad, sDeg, sGrad, _
                                  sLgOp, sVar, sCnt, sImag, sVar2, sMtxOp, sOp, sLP, sRP, _
                                 sSqrt, _
                                   sCol, sRow, _
                                 "(?<param>" + customFn.sParamDelimiter + ")",
                                 sSpace, _
                                  sAt, _
                                  "(?<eq>\=)", "(?<resto>.+)"}
            sAll = "(?<all>\G" + Join(vAll, "|") + ")"
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    'Public Shared Function regOptions() As RegexOptions
    '    Dim regOpt As RegexOptions
    '    If bIgnoreSpaces Then
    '        regOpt = RegexOptions.IgnorePatternWhitespace
    '    End If
    '    If Not bCaseSensitive Then
    '        regOpt = (regOpt Or RegexOptions.IgnoreCase)
    '    End If
    '    Return regOpt
    'End Function
    Public Shared sIntConst As String = "_K"
    Public ReadOnly Property integralCnst As String
        Get
            Dim e1 As String = String.Format(sIntConst + "{0}", iIntegralCnst)
            iIntegralCnst += 1
            Return e1
        End Get
    End Property
    Public Shared Function TryParseDbl(ByVal m As Match, ByRef result As Double) As Boolean
        If Double.TryParse(m.ToString, _
            Globalization.NumberStyles.Float Or _
            Globalization.NumberStyles.AllowThousands, _
            MathGlobal8.us, _
             result) Then
            Return True
        End If
        Return False
    End Function
    Public Shared Function TryParseDbl(ByVal e1 As String, ByRef result As Double) As Boolean
        If Double.TryParse(e1, _
            Globalization.NumberStyles.Float Or _
            Globalization.NumberStyles.AllowThousands, _
            MathGlobal8.us, _
             result) Then
            Return True
        End If
        Return False
    End Function
    Public Shared Function CloneObject(ByVal obj As Object) As Object
        Static bf As New Formatters.Binary.BinaryFormatter( _
                Nothing, New StreamingContext( _
                StreamingContextStates.Clone))
        Dim ret As Object = Nothing
        Try
            Dim ms As New IO.MemoryStream(1000)
            bf.Serialize(ms, obj)
            ms.Seek(0, SeekOrigin.Begin)
            ret = bf.Deserialize(ms)
            ms.Close()
        Catch ex As Exception
            Throw ex
        End Try
        Return ret
    End Function
    Public Shared Function CloneMatch(ByVal m As Match) As Match
        Dim ret(0) As Match
        Try
            Dim arr() As Match = {m}
            Array.Copy(arr, ret, 1)
        Catch ex As Exception
            Throw ex
        End Try
        Return ret(0)
        'Static bf As New Formatters.Binary.BinaryFormatter( _
        '        Nothing, New StreamingContext( _
        '        StreamingContextStates.Clone))
        'Dim ret As Object = Nothing
        'Try
        '    Dim ms As New IO.MemoryStream(5000)
        '    'Dim bf As New Formatters.Binary.BinaryFormatter( _
        '    'Nothing, New StreamingContext(StreamingContextStates.Clone))
        '    bf.Serialize(ms, m)
        '    ms.Seek(0, SeekOrigin.Begin)
        '    ret = bf.Deserialize(ms)
        '    ms.Close()
        'Catch ex As Exception
        '    Throw ex
        'End Try
        'Return ret
    End Function
    Public Shared ReadOnly Property isTimeout As Boolean
        Get
            lnCount += 1
            If lnCount > 5000000 Then
                lnCount = 0
                Return True
            End If
            Dim ln As Long = Now.Ticks
            If ln < ticksStart + timeOutms * 10 ^ 4 Then
                Return False
            End If
            Return False
        End Get
    End Property

    Public Shared Function IsOperand(ByVal m As Match) As Boolean
        Return m.Groups("num").Success OrElse _
                m.Groups("cnt").Success OrElse _
                m.Groups("img").Success OrElse _
                IsVariable(m)
    End Function
    Public Shared Function IsVariable(ByVal m As Match) As Boolean
        Return m.Groups("var").Success OrElse _
                m.Groups("var2").Success
    End Function
    Shared Function getTable(ByVal e1 As String, ByVal borderColor As String) As String
        Dim t As String = "<TABLE BORDER=""1"" CELLPADDING=""1"" CELLSPACING=""2"" BORDERCOLOR=""#d0d0d0"" >"

        Try
            Dim i, j As Int32
            e1 = Replace(e1, "<br />", vbCrLf)
            e1 = Replace(e1, "<br/>", vbCrLf)
            e1 = Replace(e1, "<br>", vbCrLf)
            e1 = Replace(e1, "|", vbCrLf)
            Dim vRow() As String = Split(e1, vbCrLf)
            For i = 0 To vRow.Length - 1
                vRow(i) = Replace(vRow(i), vbTab, ";")
                vRow(i) = Replace(vRow(i), ";;", ";")
                Dim vCol() As String = Split(vRow(i), ";")
                Dim t2 As String = ""
                't2 = "<TR ALIGN=""LEFT"" borderColor=" + borderColor + ">"
                t2 = "<TR ALIGN=""LEFT"" borderColor=""#d0d0d0"">"
                Dim bAdd As Boolean = False
                For j = 0 To vCol.Length - 1
                    t2 += "<TD wrap> " + vCol(j) + "</TD>"
                    If Len(Trim(vCol(j))) Then
                        bAdd = True
                    End If
                Next
                t2 += "</TR>"
                If bAdd Then
                    t += t2
                End If
            Next
            t += "</TABLE>"
            't = Replace(t, "<", "&lt;")
            't = Replace(t, ">", "&gt;")
        Catch ex As Exception
        End Try
        Return t
    End Function
    Shared Function NameAndVersion() As String
        Dim sNV As String = String.Empty
        Try
            Dim asmbly As Assembly = System.Reflection.Assembly.GetAssembly(GetType(MathGlobal8))
            Dim name As AssemblyName = asmbly.GetName()
            sNV = name.Version.ToString
            sNV = name.Name + " -- " + Left(sNV, Len(sNV) - 2)
        Catch ex As Exception

        End Try
        Return sNV
    End Function
    Public Enum outputBase
        [decimal]
        hexadecimal
        octal
        binary
    End Enum
End Class
