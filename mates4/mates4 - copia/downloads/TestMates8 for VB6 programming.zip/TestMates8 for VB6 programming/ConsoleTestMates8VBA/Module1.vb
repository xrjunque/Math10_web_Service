﻿Imports mates8VBA
Imports cfg = mates8VBA.MathGlobal8

Module Module1

    Dim N As Int32 = 1

    Sub Main()
        testMates8VBA()
    End Sub
    Sub testMates8VBA()
        Try
            Dim mP As New matrixParser
            Dim strQuery As String = String.Empty
            Dim oVars As VarsAndFns = Nothing
            Dim sOut As String = ""
            Dim strVarsAndFns As String = ""
            Dim cfg As New Config

            ' Set configuration for input data:
            cfg.bEngNotation = True ' exponents multiples of 3 (10.3e3, 1.2e6, ...)
            cfg.bIgnoreSpaces = True
            cfg.bCaseSensitive = True
            cfg.bVarName1Char = True ' variables name length = 1 char (not 2 chars, unless preceeded by underscore _longName)
            cfg.bNumsInVarName = False ' var. name will not be, for ex. x1, y3 or z0

            ' the following are examined only when 
            ' 'ToString" type methods are invoked:
            cfg.bFractions = True
            cfg.bRounding = True ' round to 3 decimals 
            cfg.bDetail = False ' no detailed info
            cfg.Base = MathGlobal8.outputBase.decimal
            cfg.outputFormat = outputMsgFormat.plainText
            cfg.timeOutms = 6000

            ' set config. into mP, mostly for
            ' input data as in toStringXXXX() methods
            ' cfg is needed to be passed as parameter (except for matrixParser 
            ' mP.toString()). These are toStringExpr(cfg), toStringMatrixParser(cfg),
            ' toStringMtx(cfg), toStringPoly(cfg), toStringComplex(cfg),
            ' for expressions, matrices, polynomials and complex numbers,
            ' respectively.
            mP.setConfig(cfg)

            Console.WriteLine("Please, wait..." & vbCrLf)

            strQuery = "Dt(y)=9.8-0.196y@y(0)=48" ' differential equation, initial value y(0)=48
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)
            strQuery = "lim(integral(1/(1+x2))dx,x,infinity)" ' limit of (1+1/n)^n when n --> infinity
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)
            strQuery = "(x2+2x2y-2xy+2xy2-3y2)/(x+y)"
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)
            strQuery = "3&h+10.8" ' 3 plus 10.8 (hexadecimal) = 3 + 16.5 = 6/2+33/2 = 39/2
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)
            strQuery = "x^2-√-x=0" ' solve
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "Xc=1/(2*pi*f*_Capacity)" ' solve the equation
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            cfg.bUseUnits = True ' use predefined quantities Ohm and MHz
            cfg.bVarName1Char = False ' Xc var. is 2 char long
            mP.parse(strQuery, "Xc=50Ohm|f=10 MHz", Nothing)
            getOutput(mP, cfg, sOut)
            cfg.bUseUnits = False
            cfg.bVarName1Char = True

            sig(sOut, N)

            'strQuery = "(x)/(15√(40^2+x^2))+(x-100)/(6√((100-x)^2+60^2)) =0"
            'sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            'mP.parse(strQuery, "", Nothing)
            'getOutput(mP, cfg, sOut)

            'sig(sOut, N)

            'strQuery = "x(1-(1/x))^(x-1) - (x-1)x(1-(1/x))^(x-2)*(1/x)=0"
            'sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            'mP.parse(strQuery, "", Nothing)
            'getOutput(mP, cfg, sOut)

            'sig(sOut, N)

            strQuery = "(x-2⅞)(x+2⅞)"
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "roots(det(A))@A=(1-x;2|3;2-x)" ' roots of matrix's A determinant
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "roots(det(A-B))@A=(1,2|3,2)|B=_lambda*(1,0|0,1)" ' roots of matrix's A-B determinant
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "cof(A)@A=(1-x;2|3;2-x)" ' cofactor
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "adj(A)@A=(1-x;2|3;2-x)" ' adjoint
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "jordan(A)@A=(2,0,0,0|1,2,0,0|0,1,3,0|0,0,1,3)" ' Jordan form
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            'strQuery = "sqr(12x+4+sqr(16x^4+40x^2+6x+10))=3+2x"
            'sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' 2*x+3*x
            'mP.parse(strQuery, "", Nothing)
            'getOutput(mP, cfg, sOut)

            'sig(sOut, N)

            'strQuery = "∫(x^2-10x+4)/x^3 dx"
            'sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            'mP.parse(CStr(strQuery), "", Nothing)
            'getOutput(mP, cfg, sOut)

            'sig(sOut, N)

            strQuery = "(√(y-1)+1) /* my comment */ *(√(y-1)+1)"
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(CStr(strQuery), "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "x+y @ x=3@ y=5"
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(CStr(strQuery), "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            'strQuery = "integral( sin(at-ax)*sin(ax))dx"
            'sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            'mP.parse(CStr(strQuery), "", Nothing)
            'getOutput(mP, cfg, sOut)

            'sig(sOut, N)

            'strQuery = "(x (-14+3 x) (6-7 x^2+x^3))/(abs(6-7 x^2+x^3))=0"
            'sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            'mP.parse(CStr(strQuery), "", Nothing)
            'getOutput(mP, cfg, sOut)

            'sig(sOut, N)

            'strQuery = "∫(exp(-s*t)*sin(t))dt"
            'sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            'mP.parse(CStr(strQuery), "", Nothing)
            'getOutput(mP, cfg, sOut)

            'sig(sOut, N)

            'strQuery = "2pi∫(x3*(1+9x4)^0.5)dx"
            'sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            'mP.parse(CStr(strQuery), "", Nothing)
            'getOutput(mP, cfg, sOut)

            'sig(sOut, N)

            'strQuery = "∫(t/(x2+1))dx"
            'sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            'mP.parse(CStr(strQuery), "", Nothing)
            'getOutput(mP, cfg, sOut)

            'sig(sOut, N)

            ' Prefix for hexadecimal numbers is &h, for octal &o, binary prefixed by &b
            ' 255 as hexadecimal (&hFF),  logical optor. AND, 15 as hexa.(&hF)
            ' logical operators valid are "and", "or", "xor", "not", "nand", "nor"
            strQuery = "(&hff AND &hf)+3" ' ...and add 3 (decimal)
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "∫(cos(x))dx"
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)


            strQuery = "integral(cos(x))dx"
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery ' Integral(cos(x))dx
            mP.parse(strQuery, "", Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "f(3)-f(2)"
            strVarsAndFns = "f(x)=x^2-1"
            oVars = Nothing
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(strQuery, strVarsAndFns, oVars)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            cfg.bIgnoreSpaces = False ' carrige return (vbCrLf) must be considered in strVarsAndFns:
            mP.setConfig(cfg) ' set new configuration value
            strQuery = "A^-1"
            strVarsAndFns = "A=2;3" & vbCrLf & "-1;-2" ' watch for row and columns' delimiter
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery & " " & strVarsAndFns
            mP.parse(strQuery, strVarsAndFns, Nothing)
            getOutput(mP, cfg, sOut)
            sOut = sOut & vbCrLf & "element at row #2, column #2 is:  " & _
                                      mP.ret.exprMtx.getExpr(1, 1).ToStringExpr(cfg) & vbCrLf
            sOut = sOut & vbCrLf

            sig(sOut, N)


            strQuery = "A*A^-1"
            strVarsAndFns = "A=2;3" & vbCrLf & "-1;-2" ' watch for row and columns' delimiter
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery & " " & strVarsAndFns
            mP.parse(strQuery, strVarsAndFns, Nothing)
            getOutput(mP, cfg, sOut)
            sOut = sOut & vbCrLf & "element at row #2, column #2 is:  " & _
                                      mP.ret.exprMtx.getExpr(1, 1).toDouble.ToString & vbCrLf
            sOut = sOut & vbCrLf

            sig(sOut, N)


            strQuery = "A^-1"
            strVarsAndFns = "A=z;x" & vbCrLf & "-3;-2" ' watch for row and columns' delimiter
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery & " " & strVarsAndFns
            mP.parse(strQuery, strVarsAndFns, Nothing)
            getOutput(mP, cfg, sOut)
            sOut = sOut & vbCrLf & "element at row #2, column #2 is:  " & _
                                      mP.ret.exprMtx.getExpr(1, 1).ToStringExpr(cfg) & vbCrLf
            sOut = sOut & vbCrLf

            sig(sOut, N)



            strQuery = "A*A^-1"
            strVarsAndFns = "A=z;x" & vbCrLf & "-3;-2" ' watch for row and columns' delimiter
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery & " " & strVarsAndFns
            mP.parse(strQuery, strVarsAndFns, Nothing)
            getOutput(mP, cfg, sOut)
            sOut = sOut & vbCrLf & "element at row #2, column #2 is:  " & _
                                      mP.ret.exprMtx.getExpr(1, 1).ToStringExpr(cfg) & vbCrLf
            sOut = sOut & vbCrLf

            sig(sOut, N)



            strQuery = "A^-1*A"
            strVarsAndFns = "A=z;x" & vbCrLf & "-3;-2" ' watch for row and columns' delimiter
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery & " " & strVarsAndFns
            mP.parse(strQuery, strVarsAndFns, Nothing)
            getOutput(mP, cfg, sOut)
            sOut = sOut & vbCrLf & "element at row #2, column #2 is:  " & _
                                      mP.ret.exprMtx.getExpr(1, 1).ToStringExpr(cfg) & vbCrLf
            sOut = sOut & vbCrLf

            sig(sOut, N)

            strQuery = "D2x(y)-2*Dx(y)+y"
            strVarsAndFns = "y=x*exp(x)"
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(strQuery, strVarsAndFns, Nothing)
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            strQuery = "roots(x^16-1)"
            'strQuery = "(x-1)(x-2)(x-3)(x-4)(x-5)(x-6)(x-7)(x-8)(x-9)(x-10)(x-11)(x-12)(x-13)(x-14)(x-15)(x-16)(x-17)(x-18)(x-19)=0"
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery
            mP.parse(strQuery, "", Nothing)
            sOut = sOut & vbCrLf & vbCrLf _
                & "= " & mP.ret.toStringRetVal(cfg) & vbCrLf  ' the resulting polynomial
            getOutput(mP, cfg, sOut)

            sig(sOut, N)

            ' Now, evaluate "2x^2+5" for x=-1, x=2, x=3 and x=-i
            strQuery = "2x^2+5"
            sOut = sOut & CStr(N) & ". Parsing and evaluating: " & strQuery & vbCrLf
            ' 1) Call parse method:
            mP.parse(strQuery, "", Nothing)

            ' 2) An AST tree has been created; call the evalExpression() method
            '    for each value of x:
            sOut = sOut & "  Evaluating " + strQuery + " at x=-1: "
            Dim cmplx As Complex = mP.ret.curExpr.evalExpression(New Complex(-1))
            sOut = sOut & "  Result= " & cmplx.ToString & vbCrLf ' =7
            sOut = sOut & "  Evaluating " + strQuery + " at x=2: "
            cmplx = mP.ret.curExpr.evalExpression(New Complex(2))
            sOut = sOut & "  Result= " & cmplx.ToString & vbCrLf ' =13
            sOut = sOut & "  Evaluating " + strQuery + " at x=3: "
            cmplx = mP.ret.curExpr.evalExpression(New Complex(3))
            sOut = sOut & "  Result= " & cmplx.ToString & vbCrLf ' =23
            sOut = sOut & "  Evaluating " + strQuery + " at x=-i: "
            cmplx = mP.ret.curExpr.evalExpression(New Complex(0, -1))
            sOut = sOut & "  Result= " & cmplx.ToString & vbCrLf ' =3

            sOut = sOut & " Multiply previous expression " + strQuery + " by 'Pi:'"
            sOut = sOut & vbCrLf
            Dim product As Expression = _
                (New Expression(Math.PI)) * mP.ret.curExpr
            sOut = sOut & "...* Pi = " + product.ToString
            sOut = sOut & vbCrLf

            sOut = sOut & " ... and multiply same expression " + strQuery + " by 'i*Pi:'"
            sOut = sOut & vbCrLf
            product = _
                (New Expression(New Complex(0, Math.PI))) * mP.ret.curExpr
            sOut = sOut & "...* i * Pi = " + product.ToString
            sOut = sOut & vbCrLf

            sig(sOut, N)

            sOut = sOut & vbCrLf
            sOut = sOut & "Current version is: " & vbCrLf
            sOut = sOut & mates8VBA.MathGlobal8.NameAndVersion
            sOut = sOut & vbCrLf


            Console.WriteLine(sOut)
        Catch ex As Exception
            Console.WriteLine(ex.ToString)
        End Try
        Console.WriteLine("Press 'Enter' key to exit.")
        Console.ReadLine()
    End Sub
    Sub sig(ByRef sOut As String, ByRef N As Int32)
        sOut = sOut & vbCrLf
        sOut = sOut & vbCrLf & "-----------------------------" & vbCrLf
        N = N + 1
    End Sub


    Sub getOutput(ByVal mP As matrixParser, ByVal cfg As Config, ByRef sOut As String)
        Try
            sOut = sOut & vbCrLf & "Result: " & vbCrLf
            If Len(mP.errMsg) Then
                sOut = sOut & mP.errMsg & vbCrLf
            Else
                'If mP.ret.rows + mP.ret.cols = 2 Then
                '    For i As Int32 = 0 To mP.retCjo.Length - 1
                '        sOut = sOut & mP.retCjo(i).toStringComplex(cfg) & vbCrLf
                '    Next
                'Else
                '    sOut = sOut & mP.ToString(cfg) & vbCrLf
                'End If
                sOut = sOut & mP.ToString(cfg) & vbCrLf
            End If


        Catch ex As Exception

        End Try
    End Sub
End Module
