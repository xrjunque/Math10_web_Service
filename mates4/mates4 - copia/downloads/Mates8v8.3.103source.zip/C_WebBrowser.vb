﻿Imports System.Text.RegularExpressions
Imports Mates8


Public Class C_WebBrowser
    Public webbrowser1 As System.Windows.Forms.WebBrowser
    Dim vPosOldVerde(-1) As Long, vRefVerde(-1) As String
    Dim vID(-1) As Object, iID As Int32
    Dim us As New System.Globalization.CultureInfo("en-US")
    'Dim path As String
    Dim bInit As Boolean = False
    Public fontName As String = "Arial, Verdana"
    Dim olfFontName As String = ""
    Private Sub New()
        'path = System.Windows.Forms.Application.ExecutablePath
        'Dim e1() As String = Split(path, "\")
        'ReDim Preserve e1(e1.Length - 2)
        'path = Join(e1, "\")
    End Sub
    Public Sub New(ByVal webBrowser1 As System.Windows.Forms.WebBrowser)
        Me.webbrowser1 = webBrowser1
        'path = System.Windows.Forms.Application.ExecutablePath
        'Dim e1() As String = Split(path, "\")
        'ReDim Preserve e1(e1.Length - 2)
        'path = Join(e1, "\")
    End Sub
    Public Sub clear()
        Dsp("", "black", False, , True)
    End Sub
    Sub Dsp(ByVal e1 As String, ByVal clr As String, _
            ByVal br As Boolean, _
            Optional ByVal sangrado As Boolean = False, _
            Optional ByVal bClear As Boolean = False, _
             Optional ByVal find As String = "last")
        Dim e2 As String = ""
        If bInit Then
            If webbrowser1 Is Nothing OrElse webbrowser1.Document Is Nothing Then
            Else
                e2 = webbrowser1.Document.Body.InnerHtml
            End If
            If Len(e1) Then
                Dim e4() As String = Split(e1, " ")
                Dim i As Int32
                For i = 0 To e4.Length - 1
                    If (Len(e4(i)) > 7 AndAlso Mid(e4(i), 1, 7) = "http://") _
                     OrElse (Len(e4(i)) > 4 AndAlso Mid(e4(i), 1, 4) = "www.") Then
                        Dim e6 As String = "<a "
                        e6 += " style=""cursor:hand"" target=""_blanck"""
                        e6 += " href=""" + e4(i) + """>" + e4(i) + "</a>"
                        e4(i) = e6
                    End If
                Next
                If e4.Length = 1 Then
                    e1 = e4(0)
                Else
                    e1 = Join(e4, " ")
                End If
            End If
        End If
        bInit = True
        If olfFontName <> fontName Then
            e2 = ""
        End If

        If e2 = "" Then
            Dim h As Int32 = webbrowser1.Width - 80
            e2 = "<html><head id=""hd"">" + vbCrLf
            'e2 += "<script type=""javascript"">" + vbCrLf
            'e2 += "function go(to) {document.title=to;}" + vbCrLf
            'e2 += "</script>" + vbCrLf
            'e2 += css
            'e2 += "</head><body id=""bd""><table><tr><td WRAP><div id=""div1"" style=""width:" + h.ToString()
            'e2 += "px;font-family:Verdana;font-size:x-small; cursor:auto""></div>"
            'e2 += "<div id=""last""></div><br /></td></tr></table></body></html>" + vbCrLf
            Dim css As String = "<style>" + vbCrLf
            css += "BODY {" + vbCrLf
            css += "display:block;" + vbCrLf
            css += "border-width: 1px;" + vbCrLf
            css += "border-style: solid;" + vbCrLf
            css += "border-color: 000;" + vbCrLf
            css += "padding:5px;" + vbCrLf
            css += "margin-top:5px;" + vbCrLf
            css += "width:150px;" + vbCrLf
            css += "height:50px;" + vbCrLf
            css += "overflow:   scroll;" + vbCrLf
            css += "font-family:   " + fontName + ";" + vbCrLf
            Me.olfFontName = fontName
            css += "}" + vbCrLf
            css += "</style>" + vbCrLf

            e2 += css
            Dim sMW As String = "" ' mousewheel:
            sMW += "<script type=""text/javascript"" language=""javascript"">" + vbCrLf
            sMW += "function handle(delta) {" + vbCrLf
            sMW += "        if (delta < 0)" + vbCrLf
            sMW += "                document.title='#1'+(-delta);" + vbCrLf ' fire a navigation event
            sMW += "        else" + vbCrLf
            sMW += "                document.title='#2'+delta;" + vbCrLf ' fire a different navigation event
            sMW += "}" + vbCrLf
            'sMW += "" + vbCrLf
            sMW += "function wheel(event){" + vbCrLf
            sMW += "        var delta = 0;" + vbCrLf
            sMW += "        if (!event) event = window.event;" + vbCrLf
            sMW += "        if (event.wheelDelta) {" + vbCrLf
            sMW += "                delta = event.wheelDelta/120; " + vbCrLf
            sMW += "        } else if (event.detail) {" + vbCrLf
            sMW += "                delta = -event.detail/3;" + vbCrLf
            sMW += "        }" + vbCrLf
            sMW += "        if (delta)" + vbCrLf
            sMW += "                handle(delta);" + vbCrLf
            sMW += "        if (event.preventDefault)" + vbCrLf
            sMW += "                event.preventDefault();" + vbCrLf
            sMW += "        event.returnValue = false;" + vbCrLf
            sMW += "}" + vbCrLf
            sMW += "if (window.addEventListener)" + vbCrLf
            sMW += "        window.addEventListener('DOMMouseScroll', wheel, sMW +false);" + vbCrLf
            sMW += "window.onmousewheel = document.onmousewheel = wheel;" + vbCrLf
            'sMW += "" + vbCrLf
            sMW += "</script>" + vbCrLf
            e2 += sMW
            e2 += "</head>"
            e2 += "<body onload=""alert(1);"" id=""bd"">" + vbCrLf
            'e2 += sMW + vbCrLf
            e2 += "<table><tr><td WRAP><div id=""div1"" style="""
            e2 += "font-family:Verdana;font-size:x-small; cursor:auto""></div>"
            e2 += "<div id=""last""></div><br /></td></tr></table>"
            e2 += "<div id=""mw""></div>"
            e2 += "</body></html>" + vbCrLf
            webbrowser1.DocumentText = "<html></html>"
            Dim b() As Byte = System.Text.Encoding.UTF8.GetBytes(e2)
            webbrowser1.Document.Write(e2)
            webbrowser1.Document.GetElementById("bd").SetAttribute("style", "font-Family:Verdana")
        Else
        End If
        Dim e3 As String = ""
        If sangrado Then e3 = "&nbsp;&nbsp;&nbsp;"
        'SyncLock "wbDsp"
        Dim e5 As String = e3 + e1
        If Len(e5) > 25 Then
            'e5 = Regex.Replace(e5, "(?<!\^)\-", " -") ' "-" --> " -", except "^-" for ex. "x^-3"
            'e5 = Replace(e5, "+", " +")
            'e5 = Replace(e5, "+", " +")
            'e5 = Replace(e5, "-", " -")
        End If
        If bClear Then
            webbrowser1.Document.GetElementById("div1").InnerHtml = "<font color=""" + clr + """>" + e5 + "</font>"
        Else
            webbrowser1.Document.GetElementById("div1").InnerHtml += "<font color=""" + clr + """>" + e5 + "</font>"
        End If
        'End SyncLock
        If br Then webbrowser1.Document.GetElementById("div1").InnerHtml += "<br />"
        webbrowser1.Document.GetElementById("bd").InnerHtml += "<div id=""last""></div>"
        'dividirPalabras()
        With webbrowser1.Document
            Try
                If find.Length Then
                    Dim last As HtmlElement = webbrowser1.Document.GetElementById(find)
                    last.ScrollIntoView(False)
                End If
            Catch ex As Exception

            End Try
        End With
    End Sub
    Sub elemDiv(ByVal nomDiv As String, ByVal value As String, Optional ByVal bOuterHtml As Boolean = False)
        Try
            'SyncLock "elemDiv"
            If bOuterHtml Then
                webbrowser1.Document.GetElementById(nomDiv).OuterHtml = value
            Else
                webbrowser1.Document.GetElementById(nomDiv).InnerHtml = value
            End If
            'End SyncLock
            'webbrowser1.Document.GetElementById(nomDiv).
            dividirPalabras()
        Catch ex As Exception

        End Try

    End Sub
    Sub elemDivAdd(ByVal nomDiv As String, ByVal value As String)
        Try
            'SyncLock "elemDivAdd"
            webbrowser1.Document.GetElementById(nomDiv).InnerHtml += value
            'End SyncLock
            dividirPalabras()
        Catch ex As Exception

        End Try
    End Sub
    'Sub tablaVerde(ByVal ID As String, ByVal cur1 As Double, ByVal total As Double, _
    '               ByVal titulo As String, _
    '                    Optional ByVal bYaExiste As Boolean = False)
    '    'cur /= 1000 : total /= 1000
    '    Dim pos As Int32 = Array.IndexOf(Me.vRefVerde, ID)
    '    If pos = -1 Then
    '        ReDim Preserve Me.vRefVerde(Me.vRefVerde.Length), Me.vPosOldVerde(Me.vPosOldVerde.Length)
    '        pos = Me.vRefVerde.Length - 1
    '    End If
    '    Dim valueOld As Long = Me.vPosOldVerde(pos)
    '    Dim Cur As Double
    '    Dim paso As Double = CDbl(Cur - valueOld) / 4
    '    If paso < 1 Then
    '        valueOld = cur1
    '        paso = cur1
    '        If paso = 0 Then paso = 10
    '    End If

    '    ' deshabilitamos la progresión pq. afecta a la interfaz de usuario:
    '    valueOld = cur1
    '    paso = cur1
    '    Cur = cur1
    '    'For Cur = valueOld To cur1 Step paso
    '    Dim img As String = "<img border=""0"" style=""position:relative;top:1px;left:-2px;"" src=""" _
    '    + path + "\1px.gif"" width=""||"" height=""17"">"
    '    Dim transparent As String = "<img border=""0"" style=""position:relative;top:0px;left:0px;"" src=""" _
    '    + path + "\1trans.gif"" width=""||"" height=""17"">"
    '    Dim e2 As String = "<div id=""tbVerde" + ID + """>"
    '    Dim e1 As String = ""
    '    Dim pje As Double = Math.Floor(Cur * 100 / total)
    '    Dim px As Int32 = pje * 148 / 100
    '    Dim pxResto As Int32 = 148 - px
    '    e1 += "<div>" + titulo + "</div>"
    '    e1 += "<center><table><tr><td style=""height:17px;left:-2px;top:2px;width:"
    '    e1 += String.Format(us, "{0:0}", px) + "px; background-color:LawnGreen;"">"
    '    e1 += Replace(img, "||", px.ToString()) + "</td>"
    '    e1 += "<td style=""width:" + String.Format(us, "{0:0}", pxResto) + "px"">"
    '    e1 += Replace(transparent, "||", pxResto.ToString()) + "</td>"
    '    e1 += "</tr><tr>"
    '    e1 += "<td colspan=""2"" style=""position:relative;top:-22px;left:-4px"" align=""center"">"
    '    e1 += "<div style=""font-size:12pt;position:relative;left:1px;top:-1px;border: 1px solid black;width:252px;height:21px"">"
    '    'e1 += String.Format(us, "{0:###,###,##0.0}", cur) + "</div></td>"
    '    e1 += strFormatLenArch(Cur) + "</div></td>"
    '    e1 += "</tr></table></center>"
    '    If Not bYaExiste Then
    '        Dsp(e2 + e1 + "</div>", "", False)
    '    Else
    '        Me.elemDiv(ID, e1)
    '    End If
    '    dividirPalabras()
    '    'bYaExiste = True
    '    'System.Threading.Thread.Sleep(10)
    '    'Next
    '    Me.vPosOldVerde(pos) = cur1
    'End Sub
    Sub dividirPalabras()
        'Exit Sub
repite:
        Dim e1 As String = ""
        Try
            e1 = webbrowser1.Document.Body.InnerHtml
        Catch ex As Exception
            Exit Sub
        End Try
        Dim ln As Int32 = 35
        Dim ms As MatchCollection = Regex.Matches(e1, "\>[^\< ]{" + ln.ToString + ",}\<")
        Dim m As Match
        Dim bHallado As Boolean = False
        For Each m In ms
            Dim j As Int32
            Dim e3 As String = ""
            For j = 1 To m.Value.Length Step ln
                If j + ln + 5 < m.Value.Length AndAlso j + ln - 1 < m.Value.Length Then
                    'If Regex.IsMatch(Mid(m.Value, 2, Len(m.Value) - 1), "[\>\<]") Then
                    'e3 += Mid(m.Value, j) : Exit For
                    'End If
                    e3 = Mid(m.Value, 1, ln - 1) + "<BR>"
                    'ElseIf j + ln + 5 >= m.Value.Length Then
                    e3 += Mid(m.Value, ln, m.Value.Length - j - 1)
                    Exit For
                Else
                    'e3 += Mid(m.Value, j)
                    'Exit For
                End If
            Next
            e1 = Mid(e1, 1, m.Index) + e3 + Mid(e1, m.Index + m.Value.Length + 1)
            bHallado = True
        Next
        If bHallado Then
            webbrowser1.Document.Body.InnerHtml = e1
            GoTo repite
        End If
    End Sub
    Public Shared Function strFormatLenArch(ByVal length As Long) As String
        Dim us As New System.Globalization.CultureInfo("en-US")
        Dim e3 As String = ""
        If length / 1000 > 1000 Then
            e3 = String.Format(us, "{0:##,###,###.00} MB", length / 10 ^ 6)
        ElseIf length > 1000 Then
            e3 = String.Format(us, "{0:##,###,###.0} KBytes", length / 1000)
        Else
            e3 = String.Format(us, "{0:#,###} Bytes", length / 1000)
        End If
        Return e3
    End Function
    Sub ZoomWebBrowser(ByVal factor As Single)
        Try
            Dim factorStr As String = (factor * 100).ToString(MathGlobal8.us) + "%"
            If webbrowser1.Document IsNot Nothing Then
                webbrowser1.Document.Body.Style += ";zoom:" + factorStr
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
Public Class C_TablaVerde
    Shared vTV(-1) As C_TablaVerde, iTV As Int32 = 0
End Class
