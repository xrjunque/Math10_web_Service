﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
                mtx.Close()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.rtbQuery = New System.Windows.Forms.RichTextBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.Clear = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Paste = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectAllAndCopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearAllPaste = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnGotoPrev = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnGotoNext = New System.Windows.Forms.ToolStripMenuItem()
        Me.GotoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.FontToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.rtbVars = New System.Windows.Forms.RichTextBox()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppenFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.RestoreDefaultOptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveOptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.OutputToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.GotoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CALCULATEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FunctionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cbFns = New System.Windows.Forms.ToolStripComboBox()
        Me.cbExamples = New System.Windows.Forms.ToolStripComboBox()
        Me.cbGreek = New System.Windows.Forms.ToolStripComboBox()
        Me.LogicalOperatorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnAND = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnOR = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnNOT = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnXOR = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnNOR = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnNAND = New System.Windows.Forms.ToolStripMenuItem()
        Me.cbUnitsExamples = New System.Windows.Forms.ToolStripComboBox()
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkClear = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkEng = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkIgnoreCase = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkIgnoreCR = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkRound = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkFractions = New System.Windows.Forms.ToolStripMenuItem()
        Me.IncrementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecrementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkI = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkHexa = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkOctal = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkBinary = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkDetail = New System.Windows.Forms.ToolStripMenuItem()
        Me.cbTimeout = New System.Windows.Forms.ToolStripComboBox()
        Me.chkVarNameLen1char = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkNumsInVarname = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkUnits = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnClearAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.LBHistQuery = New System.Windows.Forms.ToolStripComboBox()
        Me.LBHistVars = New System.Windows.Forms.ToolStripComboBox()
        Me.ClearAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutMates6CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.lblMsg = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblSpring = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblPrev = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblNext = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblClr = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblEng = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblSpaces = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblCase = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblRnd = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblZoom = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblImag = New System.Windows.Forms.ToolStripStatusLabel()
        Me.mnFactor = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        Me.mnFactor.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BackColor = System.Drawing.SystemColors.Control
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 24)
        Me.SplitContainer1.Margin = New System.Windows.Forms.Padding(5)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.WebBrowser1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel1)
        Me.SplitContainer1.Size = New System.Drawing.Size(405, 203)
        Me.SplitContainer1.SplitterDistance = 153
        Me.SplitContainer1.SplitterWidth = 7
        Me.SplitContainer1.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Margin = New System.Windows.Forms.Padding(4)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.rtbQuery)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.rtbVars)
        Me.SplitContainer2.Panel2MinSize = 5
        Me.SplitContainer2.Size = New System.Drawing.Size(155, 180)
        Me.SplitContainer2.SplitterDistance = 101
        Me.SplitContainer2.SplitterWidth = 5
        Me.SplitContainer2.TabIndex = 8
        '
        'rtbQuery
        '
        Me.rtbQuery.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rtbQuery.ContextMenuStrip = Me.ContextMenuStrip1
        Me.rtbQuery.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbQuery.Location = New System.Drawing.Point(0, 0)
        Me.rtbQuery.Name = "rtbQuery"
        Me.rtbQuery.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.rtbQuery.Size = New System.Drawing.Size(157, 103)
        Me.rtbQuery.TabIndex = 1
        Me.rtbQuery.Text = ""
        Me.ToolTip1.SetToolTip(Me.rtbQuery, "Enter your math expression " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and click 'Calculate' or " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "press 'Enter' key." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(Pres" & _
        "s 'Ctrl'+'Enter' for" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "a new line)")
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Clear, Me.CopyToolStripMenuItem, Me.Paste, Me.SelectAllAndCopy, Me.ClearAllPaste, Me.ToolStripSeparator2, Me.mnGotoPrev, Me.mnGotoNext, Me.GotoToolStripMenuItem, Me.ToolStripSeparator5, Me.ToolStripMenuItem1, Me.ToolStripSeparator3, Me.FontToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(206, 242)
        '
        'Clear
        '
        Me.Clear.Name = "Clear"
        Me.Clear.Size = New System.Drawing.Size(205, 22)
        Me.Clear.Text = "C&lear"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.CopyToolStripMenuItem.Text = "&Copy"
        '
        'Paste
        '
        Me.Paste.Name = "Paste"
        Me.Paste.Size = New System.Drawing.Size(205, 22)
        Me.Paste.Text = "&Paste"
        '
        'SelectAllAndCopy
        '
        Me.SelectAllAndCopy.Name = "SelectAllAndCopy"
        Me.SelectAllAndCopy.Size = New System.Drawing.Size(205, 22)
        Me.SelectAllAndCopy.Text = "&Select All && Copy"
        '
        'ClearAllPaste
        '
        Me.ClearAllPaste.Name = "ClearAllPaste"
        Me.ClearAllPaste.Size = New System.Drawing.Size(205, 22)
        Me.ClearAllPaste.Text = "Clear All && &Paste"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(202, 6)
        '
        'mnGotoPrev
        '
        Me.mnGotoPrev.Name = "mnGotoPrev"
        Me.mnGotoPrev.ShortcutKeyDisplayString = "Ctrl+Left"
        Me.mnGotoPrev.Size = New System.Drawing.Size(205, 22)
        Me.mnGotoPrev.Text = "Go to Previous"
        '
        'mnGotoNext
        '
        Me.mnGotoNext.Name = "mnGotoNext"
        Me.mnGotoNext.ShortcutKeyDisplayString = "Ctrl+Right"
        Me.mnGotoNext.Size = New System.Drawing.Size(205, 22)
        Me.mnGotoNext.Text = "Go to Next"
        '
        'GotoToolStripMenuItem
        '
        Me.GotoToolStripMenuItem.Name = "GotoToolStripMenuItem"
        Me.GotoToolStripMenuItem.ShortcutKeyDisplayString = ""
        Me.GotoToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.GotoToolStripMenuItem.Text = "&Go to..."
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(202, 6)
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(205, 22)
        Me.ToolStripMenuItem1.Text = "Remove record entry "
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(202, 6)
        '
        'FontToolStripMenuItem
        '
        Me.FontToolStripMenuItem.Name = "FontToolStripMenuItem"
        Me.FontToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.FontToolStripMenuItem.Text = "&Font..."
        '
        'rtbVars
        '
        Me.rtbVars.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rtbVars.ContextMenuStrip = Me.ContextMenuStrip1
        Me.rtbVars.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbVars.Location = New System.Drawing.Point(0, 0)
        Me.rtbVars.Name = "rtbVars"
        Me.rtbVars.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.rtbVars.Size = New System.Drawing.Size(157, 74)
        Me.rtbVars.TabIndex = 0
        Me.rtbVars.Text = ""
        Me.ToolTip1.SetToolTip(Me.rtbVars, "Enter, if needed,, varName=value" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Examples:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "x=3" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "y=-2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(Press 'Ctrl'+'Enter' for" & _
        "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "a new line. Press" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "'Enter' to calculate)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WebBrowser1.Location = New System.Drawing.Point(2, 2)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(240, 176)
        Me.WebBrowser1.TabIndex = 3
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BackColor = System.Drawing.Color.Black
        Me.Panel2.Location = New System.Drawing.Point(1, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(244, 1)
        Me.Panel2.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1, 182)
        Me.Panel1.TabIndex = 1
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.mnEdit, Me.CALCULATEToolStripMenuItem, Me.FunctionsToolStripMenuItem, Me.OptionsToolStripMenuItem, Me.mnClearAll, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(7, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(405, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenToolStripMenuItem, Me.AppenFile, Me.SaveToolStripMenuItem, Me.ToolStripSeparator1, Me.RestoreDefaultOptionsToolStripMenuItem, Me.SaveOptionsToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.OpenToolStripMenuItem.Text = "&Open..."
        '
        'AppenFile
        '
        Me.AppenFile.Name = "AppenFile"
        Me.AppenFile.Size = New System.Drawing.Size(196, 22)
        Me.AppenFile.Text = "&Append file..."
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.SaveToolStripMenuItem.Text = "&Save..."
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(193, 6)
        '
        'RestoreDefaultOptionsToolStripMenuItem
        '
        Me.RestoreDefaultOptionsToolStripMenuItem.Name = "RestoreDefaultOptionsToolStripMenuItem"
        Me.RestoreDefaultOptionsToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.RestoreDefaultOptionsToolStripMenuItem.Text = "&Restore default options"
        '
        'SaveOptionsToolStripMenuItem
        '
        Me.SaveOptionsToolStripMenuItem.Name = "SaveOptionsToolStripMenuItem"
        Me.SaveOptionsToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.SaveOptionsToolStripMenuItem.Text = "Save &current options"
        '
        'mnEdit
        '
        Me.mnEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OutputToolStripMenuItem, Me.ToolStripSeparator4, Me.GotoToolStripMenuItem1})
        Me.mnEdit.Name = "mnEdit"
        Me.mnEdit.Size = New System.Drawing.Size(39, 20)
        Me.mnEdit.Text = "&Edit"
        '
        'OutputToolStripMenuItem
        '
        Me.OutputToolStripMenuItem.Name = "OutputToolStripMenuItem"
        Me.OutputToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.OutputToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.OutputToolStripMenuItem.Text = "&Output..."
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(159, 6)
        '
        'GotoToolStripMenuItem1
        '
        Me.GotoToolStripMenuItem1.Name = "GotoToolStripMenuItem1"
        Me.GotoToolStripMenuItem1.Size = New System.Drawing.Size(162, 22)
        Me.GotoToolStripMenuItem1.Text = "&Goto..."
        '
        'CALCULATEToolStripMenuItem
        '
        Me.CALCULATEToolStripMenuItem.Name = "CALCULATEToolStripMenuItem"
        Me.CALCULATEToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.CALCULATEToolStripMenuItem.Text = "&CALCULATE"
        '
        'FunctionsToolStripMenuItem
        '
        Me.FunctionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cbFns, Me.cbExamples, Me.cbGreek, Me.LogicalOperatorsToolStripMenuItem, Me.cbUnitsExamples})
        Me.FunctionsToolStripMenuItem.Name = "FunctionsToolStripMenuItem"
        Me.FunctionsToolStripMenuItem.Size = New System.Drawing.Size(76, 20)
        Me.FunctionsToolStripMenuItem.Text = "&Predefined"
        '
        'cbFns
        '
        Me.cbFns.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbFns.Name = "cbFns"
        Me.cbFns.Size = New System.Drawing.Size(140, 29)
        Me.cbFns.Text = "Functions"
        '
        'cbExamples
        '
        Me.cbExamples.DropDownWidth = 350
        Me.cbExamples.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbExamples.Items.AddRange(New Object() {"---Basic operations:---", "1600/((1-(1+1/4)^30)/(1-(1+1/4)))", "gcd(12,36,6,24) ' Greatest common divisor", "", "---Custom functions:---", "P(x)/Q(x)?P(x)=x^2-1|Q(x)=x-1", "f(1,3)?f(x,y)=y-x", "f(2,-1)@f(x,y)=x,y|x*y,-2*x*y", "", "---Evaluating:---", "x^2-9*x+20?x=5", "x^2-9x+20?x=4.5", "2+x/(y*a)?x=12|y=4|a=-3", "               ", "---Hex, octal, binary, decimal:", "&hF+&o17+&b1111+&d15", "&HF+&d3+10+&H10", "", "---Logical operators:", "(&hffAND&h0f)+3", "                ", "---Modulus:", "((x5+3x3+4)*(6x6+4x3))%11", "                ", "---POLYNOMIALS:", "---Root finder:", "roots(x16-1)", "(x-1)*(x+1)", "x^2-9x+20=0", "gcd((3x2-3)(x+2),-(3x-3)(x+2),(2x+4)) ' Greatest common divisor", "---Orthogonality:", "orthog(-1;1;2*t;3*t^2+5)", "---Interpolation:---", "x|*|lagrangianinterpolation(-2;1|0;-1|2;1)", "lagrangianinterpolation(-1;1;10;abs(x)) ' 10 intervals at [-1,1] with 11 Chebyshe" & _
                "v nodes for f(x)=|x|. See http://svn.assembla.com/svn/mna/tps/tp4ej5Paulina.pdf", "                ", "---Derivatives:---", "Dx(cosh(x))", "Dy(sin(x^2*y^2+y))", "Dy(z)?z=x+y|x=y^2", "                ", "---2nd.derivative:---", "D2x(3x^2-2x+5)", "                ", "---Jacobian:---", "jacobian(1,000x^2-2x+5;sin(x2)|xsinh(y);xasinh(y))", "                ", "---Vector,operation:", "1,2|*|3|-1", "", "---MATRIX,operations:", "(1,0|0,-1|^|-1)|*|1,0|0,-1", "(1,2|3,4|+|1,0|0,1)|*|-1,0|0,1", "((1,0|0,3|-|5,0|3,-2)|^|-1)|*|(-4,0|-3,5)", "(x,0|0,1|^|-1)|*|a?a=x,0|0,1", "x+1,0|0,-1|^|-1|*|a?a=(x+1),0|0,-1", "A+(-B*C)?A=1,2|3,-1||B=A|C=1,0|0,1", "Dx(x^2-sin(x),-6*x^2-x+3|tan(x)+x^2,sinh(x))", "integral(x^2*y-y^2,-6*x*y^2-x+3|1/(y+1),sinh(y))dy", "---Inverse,matrix:", "(1,2|3,-1)|^|-1", "A^-1?A=1,2|3,-1", "A^-1*A?A=1,2|3,-1", "A^-1*A?A=z,x|2,-3", "a*a^-1*a-a?a=sin(x),1|-1,-sin(x)", "---Transpose:", "transpose(1,2|3,4)", "---Cofactor:", "cof(1;3;1|1;1;2|2;3;4) /* see www.utdallas.edu/dept/abp/PDF_Files/LinearAlgebra_F" & _
                "older/Cofactors.pdf */", "---Adjoint:", "Adj(1;3;1|1;1;2|2;3;4) /* see www.utdallas.edu/dept/abp/PDF_Files/LinearAlgebra_F" & _
                "older/Cofactors.pdf */", "---Echelon:", "Echelon(1,2,1|-2,-3,1|3,5,0) /* see http://en.wikipedia.org/wiki/Row_echelon_form" & _
                " */", "---Rank:", "Rank(1,2,1|-2,-3,1|3,5,0) /* see http://en.wikipedia.org/wiki/Rank_(linear_algebr" & _
                "a) */", "---Determinant:", "det(A)?A=(1-x;2|3;2-x)", "roots(det(A))?A=(1-x;2|3;2-x)", "det(A)=0?A=(1-x;2|3;2-x)", "roots(det(A))@A=(3,a,a,a,a|a,3,a,a,a|a,a,3,a,a|a,a,a,3,a|a,a,a,a,3)", "det(A)-(4a+3)*(3-a)^4?A=(3,a,a,a,a|a,3,a,a,a|a,a,3,a,a|a,a,a,3,a|a,a,a,a,3)", "det(A-B)=0?A=(1,2|3,2)|B=λ*(1,0|0,1)", "---Eigenvalues:---", "eigenvalues(A)?A=2,1|1,2", "---Eigenvectors:---", "eigenvectors(A)?A=2,1|1,2", "---Jordan form:---", "A*T-T*jordan(A)?A=2,0,1|0,2,0|1,0,2|T=eigenvectors(A)", "---SYSTEM OF EQUATIONS:---", "---Linear:---", "_XC=1/(2*pi*f*C)?_XC=50|f=10e6", "x+y=2|x-y=1", "---Non-Linear:---", "x2-10x+y2+8=0|x*y2+x-10y+8=0", "                ", "---INTEGRATION:", "---Integration of polynomials:", "integral(6x-2)", "integral(3x2+y)dx", "∫(x2+y)dy", "                ", "---Inmediate integrals:", "∫(sin(x))dx", "∫(ln(x))dx", "                ", "---Definite integrals:", "integral(1,2,x)dx", "integral(1,2,x*y)dy", "∫(1,2,x)dx", "∫(a,b,x*y)dx?a=1|b=2", "∫(a,b,S(x))dx;pi(10^(3/2)-1)/27?a=0|b=1|f(x)=x3|S(x)=2*pi*f(x)*sqr(1+(Dx(f(x)))^2" & _
                ")", "                ", "---Partial fractions integration:", "∫1/(x(x-2)^2)dx", "(x(x-2)^2)*Dx(∫1/(x(x-2)^2)dx)", "                ", "---Trigonometric integration:", "∫(sec(x)*tan2(x))dx", "                ", "---Integration by parts:", "13*∫(sin(3*x)*exp(2*x))dx", "", "--- Other examples:", "∫(√x+(1/√x))^2|∫((√x+(1/√x))^2)dx|(√x+(1/√x))^2"})
        Me.cbExamples.Name = "cbExamples"
        Me.cbExamples.Size = New System.Drawing.Size(121, 29)
        Me.cbExamples.Text = "Examples"
        '
        'cbGreek
        '
        Me.cbGreek.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbGreek.Items.AddRange(New Object() {"Α", "α", "Β", "β", "Γ", "γ", "Δ", "δ", "Ε", "ε", "Ζ", "ζ", "Η", "η", "Θ", "θ", "Ι", "ι", "Κ", "κ", "Λ", "λ", "Μ", "μ", "Ν", "ν", "Ξ", "ξ", "Ο", "ο", "Π", "π", "Ρ", "ρ", "Σ", "σ", "Τ", "τ", "Υ", "υ", "Φ", "φ", "Χ", "χ", "Ψ", "ψ", "Ω", "ω"})
        Me.cbGreek.Name = "cbGreek"
        Me.cbGreek.Size = New System.Drawing.Size(121, 29)
        Me.cbGreek.Text = "Greek chars."
        '
        'LogicalOperatorsToolStripMenuItem
        '
        Me.LogicalOperatorsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnAND, Me.mnOR, Me.mnNOT, Me.mnXOR, Me.mnNOR, Me.mnNAND})
        Me.LogicalOperatorsToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.LogicalOperatorsToolStripMenuItem.Name = "LogicalOperatorsToolStripMenuItem"
        Me.LogicalOperatorsToolStripMenuItem.Size = New System.Drawing.Size(200, 26)
        Me.LogicalOperatorsToolStripMenuItem.Text = "&Logical Operators"
        '
        'mnAND
        '
        Me.mnAND.Name = "mnAND"
        Me.mnAND.Size = New System.Drawing.Size(125, 26)
        Me.mnAND.Text = "&AND"
        '
        'mnOR
        '
        Me.mnOR.Name = "mnOR"
        Me.mnOR.Size = New System.Drawing.Size(125, 26)
        Me.mnOR.Text = "&OR"
        '
        'mnNOT
        '
        Me.mnNOT.Name = "mnNOT"
        Me.mnNOT.Size = New System.Drawing.Size(125, 26)
        Me.mnNOT.Text = "&NOT"
        '
        'mnXOR
        '
        Me.mnXOR.Name = "mnXOR"
        Me.mnXOR.Size = New System.Drawing.Size(125, 26)
        Me.mnXOR.Text = "&XOR"
        '
        'mnNOR
        '
        Me.mnNOR.Name = "mnNOR"
        Me.mnNOR.Size = New System.Drawing.Size(125, 26)
        Me.mnNOR.Text = "NO&R"
        '
        'mnNAND
        '
        Me.mnNAND.Name = "mnNAND"
        Me.mnNAND.Size = New System.Drawing.Size(125, 26)
        Me.mnNAND.Text = "NAN&D"
        '
        'cbUnitsExamples
        '
        Me.cbUnitsExamples.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbUnitsExamples.Items.AddRange(New Object() {"10*150m /* 10 times 150meters */", "0.001uF /* 0.001 microFarads */", "1/(2*pi*10MHz*318pF) /* Reactance for a 10MegaHertz signal and a 318picoFarads ca" & _
                "pacitor */", "Xc=1/(2*pi*f*_Capacity)|/* make sure 'Options/Units' is checked for units and all" & _
                "ow more than one char for variables */?|Xc=50Ohm|f=10 MHz ", "100N/(10m)/(10s) /* a 100Newton force applied 10meters during 10 seconds*/"})
        Me.cbUnitsExamples.Name = "cbUnitsExamples"
        Me.cbUnitsExamples.Size = New System.Drawing.Size(121, 26)
        Me.cbUnitsExamples.Text = "Units' examples"
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.chkClear, Me.chkEng, Me.chkIgnoreCase, Me.chkIgnoreCR, Me.chkRound, Me.chkFractions, Me.IncrementToolStripMenuItem, Me.DecrementToolStripMenuItem, Me.chkI, Me.chkHexa, Me.chkOctal, Me.chkBinary, Me.chkDetail, Me.cbTimeout, Me.chkVarNameLen1char, Me.chkNumsInVarname, Me.chkUnits})
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.U), System.Windows.Forms.Keys)
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.OptionsToolStripMenuItem.Text = "&Options"
        '
        'chkClear
        '
        Me.chkClear.Checked = True
        Me.chkClear.CheckOnClick = True
        Me.chkClear.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkClear.Name = "chkClear"
        Me.chkClear.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.chkClear.Size = New System.Drawing.Size(205, 22)
        Me.chkClear.Text = "C&lear"
        '
        'chkEng
        '
        Me.chkEng.Checked = True
        Me.chkEng.CheckOnClick = True
        Me.chkEng.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEng.Name = "chkEng"
        Me.chkEng.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.chkEng.Size = New System.Drawing.Size(205, 22)
        Me.chkEng.Text = "&Eng. notation"
        '
        'chkIgnoreCase
        '
        Me.chkIgnoreCase.CheckOnClick = True
        Me.chkIgnoreCase.Name = "chkIgnoreCase"
        Me.chkIgnoreCase.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.G), System.Windows.Forms.Keys)
        Me.chkIgnoreCase.Size = New System.Drawing.Size(205, 22)
        Me.chkIgnoreCase.Text = "I&gnore Case"
        '
        'chkIgnoreCR
        '
        Me.chkIgnoreCR.CheckOnClick = True
        Me.chkIgnoreCR.Name = "chkIgnoreCR"
        Me.chkIgnoreCR.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.chkIgnoreCR.Size = New System.Drawing.Size(205, 22)
        Me.chkIgnoreCR.Text = "Ignore &'CR'"
        '
        'chkRound
        '
        Me.chkRound.Checked = True
        Me.chkRound.CheckOnClick = True
        Me.chkRound.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkRound.Name = "chkRound"
        Me.chkRound.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.chkRound.Size = New System.Drawing.Size(205, 22)
        Me.chkRound.Text = "&Round"
        '
        'chkFractions
        '
        Me.chkFractions.Checked = True
        Me.chkFractions.CheckOnClick = True
        Me.chkFractions.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkFractions.Name = "chkFractions"
        Me.chkFractions.Size = New System.Drawing.Size(205, 22)
        Me.chkFractions.Text = "&Fractions"
        '
        'IncrementToolStripMenuItem
        '
        Me.IncrementToolStripMenuItem.Image = CType(resources.GetObject("IncrementToolStripMenuItem.Image"), System.Drawing.Image)
        Me.IncrementToolStripMenuItem.Name = "IncrementToolStripMenuItem"
        Me.IncrementToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.IncrementToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.IncrementToolStripMenuItem.Text = "&Increment"
        '
        'DecrementToolStripMenuItem
        '
        Me.DecrementToolStripMenuItem.Image = CType(resources.GetObject("DecrementToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DecrementToolStripMenuItem.Name = "DecrementToolStripMenuItem"
        Me.DecrementToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.DecrementToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.DecrementToolStripMenuItem.Text = "&Decrement"
        '
        'chkI
        '
        Me.chkI.Checked = True
        Me.chkI.CheckOnClick = True
        Me.chkI.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkI.Name = "chkI"
        Me.chkI.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.chkI.Size = New System.Drawing.Size(205, 22)
        Me.chkI.Text = "i as i&maginary"
        '
        'chkHexa
        '
        Me.chkHexa.CheckOnClick = True
        Me.chkHexa.Name = "chkHexa"
        Me.chkHexa.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.H), System.Windows.Forms.Keys)
        Me.chkHexa.Size = New System.Drawing.Size(205, 22)
        Me.chkHexa.Text = "&Hexadecimal"
        '
        'chkOctal
        '
        Me.chkOctal.CheckOnClick = True
        Me.chkOctal.Name = "chkOctal"
        Me.chkOctal.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.chkOctal.Size = New System.Drawing.Size(205, 22)
        Me.chkOctal.Text = "&Octal"
        '
        'chkBinary
        '
        Me.chkBinary.CheckOnClick = True
        Me.chkBinary.Name = "chkBinary"
        Me.chkBinary.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.chkBinary.Size = New System.Drawing.Size(205, 22)
        Me.chkBinary.Text = "&Binary"
        '
        'chkDetail
        '
        Me.chkDetail.CheckOnClick = True
        Me.chkDetail.Name = "chkDetail"
        Me.chkDetail.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.chkDetail.Size = New System.Drawing.Size(205, 22)
        Me.chkDetail.Text = "De&tail"
        '
        'cbTimeout
        '
        Me.cbTimeout.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbTimeout.Items.AddRange(New Object() {"Timeout:", "0.5 s", " 1 second", " 2 seconds", " 3 seconds", "10 seconds", "30 seconds", "  1 minute"})
        Me.cbTimeout.Name = "cbTimeout"
        Me.cbTimeout.Size = New System.Drawing.Size(121, 23)
        '
        'chkVarNameLen1char
        '
        Me.chkVarNameLen1char.Checked = True
        Me.chkVarNameLen1char.CheckOnClick = True
        Me.chkVarNameLen1char.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkVarNameLen1char.Name = "chkVarNameLen1char"
        Me.chkVarNameLen1char.Size = New System.Drawing.Size(205, 22)
        Me.chkVarNameLen1char.Text = "Var.name length=1char."
        '
        'chkNumsInVarname
        '
        Me.chkNumsInVarname.CheckOnClick = True
        Me.chkNumsInVarname.Name = "chkNumsInVarname"
        Me.chkNumsInVarname.Size = New System.Drawing.Size(205, 22)
        Me.chkNumsInVarname.Text = "Allow nums. in var.name"
        '
        'chkUnits
        '
        Me.chkUnits.CheckOnClick = True
        Me.chkUnits.Name = "chkUnits"
        Me.chkUnits.ShortcutKeyDisplayString = "Ctrl+U"
        Me.chkUnits.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.U), System.Windows.Forms.Keys)
        Me.chkUnits.Size = New System.Drawing.Size(205, 22)
        Me.chkUnits.Text = "&Units"
        '
        'mnClearAll
        '
        Me.mnClearAll.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LBHistQuery, Me.LBHistVars, Me.ClearAllToolStripMenuItem})
        Me.mnClearAll.Name = "mnClearAll"
        Me.mnClearAll.Size = New System.Drawing.Size(56, 20)
        Me.mnClearAll.Text = "&Record"
        '
        'LBHistQuery
        '
        Me.LBHistQuery.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBHistQuery.Name = "LBHistQuery"
        Me.LBHistQuery.Size = New System.Drawing.Size(121, 29)
        Me.LBHistQuery.Text = "Queries"
        '
        'LBHistVars
        '
        Me.LBHistVars.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBHistVars.Name = "LBHistVars"
        Me.LBHistVars.Size = New System.Drawing.Size(121, 29)
        Me.LBHistVars.Text = "Vars.& Fns."
        '
        'ClearAllToolStripMenuItem
        '
        Me.ClearAllToolStripMenuItem.Name = "ClearAllToolStripMenuItem"
        Me.ClearAllToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.ClearAllToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ClearAllToolStripMenuItem.Text = "Clear &All"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutMates6CalculatorToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(24, 20)
        Me.HelpToolStripMenuItem.Text = "&?"
        '
        'AboutMates6CalculatorToolStripMenuItem
        '
        Me.AboutMates6CalculatorToolStripMenuItem.Name = "AboutMates6CalculatorToolStripMenuItem"
        Me.AboutMates6CalculatorToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.AboutMates6CalculatorToolStripMenuItem.Text = "&About..."
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'ToolTip1
        '
        Me.ToolTip1.AutoPopDelay = 1750
        Me.ToolTip1.InitialDelay = 500
        Me.ToolTip1.ReshowDelay = 100
        '
        'StatusStrip
        '
        Me.StatusStrip.BackColor = System.Drawing.SystemColors.Control
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblMsg, Me.lblSpring, Me.lblPrev, Me.lblNext, Me.lblClr, Me.lblEng, Me.lblSpaces, Me.lblCase, Me.lblRnd, Me.lblZoom, Me.lblImag})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 205)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.ShowItemToolTips = True
        Me.StatusStrip.Size = New System.Drawing.Size(405, 22)
        Me.StatusStrip.TabIndex = 2
        Me.StatusStrip.Text = "StatusStrip1"
        '
        'lblMsg
        '
        Me.lblMsg.Name = "lblMsg"
        Me.lblMsg.Size = New System.Drawing.Size(59, 17)
        Me.lblMsg.Text = "Message: "
        '
        'lblSpring
        '
        Me.lblSpring.BackColor = System.Drawing.SystemColors.Control
        Me.lblSpring.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpring.Name = "lblSpring"
        Me.lblSpring.Size = New System.Drawing.Size(86, 17)
        Me.lblSpring.Spring = True
        '
        'lblPrev
        '
        Me.lblPrev.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrev.Name = "lblPrev"
        Me.lblPrev.Size = New System.Drawing.Size(13, 17)
        Me.lblPrev.Text = "<"
        Me.lblPrev.ToolTipText = "Previous calculation"
        '
        'lblNext
        '
        Me.lblNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNext.Name = "lblNext"
        Me.lblNext.Size = New System.Drawing.Size(13, 17)
        Me.lblNext.Text = ">"
        Me.lblNext.ToolTipText = "Next calculation"
        '
        'lblClr
        '
        Me.lblClr.AutoToolTip = True
        Me.lblClr.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.lblClr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClr.Name = "lblClr"
        Me.lblClr.Size = New System.Drawing.Size(28, 17)
        Me.lblClr.Text = "CLR"
        '
        'lblEng
        '
        Me.lblEng.AutoToolTip = True
        Me.lblEng.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEng.Name = "lblEng"
        Me.lblEng.Size = New System.Drawing.Size(30, 17)
        Me.lblEng.Text = "ENG"
        '
        'lblSpaces
        '
        Me.lblSpaces.AutoToolTip = True
        Me.lblSpaces.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblSpaces.Name = "lblSpaces"
        Me.lblSpaces.Size = New System.Drawing.Size(43, 17)
        Me.lblSpaces.Text = "Spaces"
        '
        'lblCase
        '
        Me.lblCase.AutoToolTip = True
        Me.lblCase.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCase.Name = "lblCase"
        Me.lblCase.Size = New System.Drawing.Size(44, 17)
        Me.lblCase.Text = "C.Sens."
        '
        'lblRnd
        '
        Me.lblRnd.AutoToolTip = True
        Me.lblRnd.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblRnd.Name = "lblRnd"
        Me.lblRnd.Size = New System.Drawing.Size(31, 17)
        Me.lblRnd.Text = "RND"
        '
        'lblZoom
        '
        Me.lblZoom.AutoToolTip = True
        Me.lblZoom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblZoom.Name = "lblZoom"
        Me.lblZoom.Size = New System.Drawing.Size(33, 17)
        Me.lblZoom.Text = "100%"
        '
        'lblImag
        '
        Me.lblImag.AutoToolTip = True
        Me.lblImag.Name = "lblImag"
        Me.lblImag.Size = New System.Drawing.Size(10, 17)
        Me.lblImag.Text = "i"
        '
        'mnFactor
        '
        Me.mnFactor.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem7, Me.ToolStripMenuItem8, Me.ToolStripMenuItem6, Me.ToolStripMenuItem5, Me.ToolStripMenuItem4, Me.ToolStripMenuItem3, Me.ToolStripMenuItem2})
        Me.mnFactor.Name = "mnFactor"
        Me.mnFactor.Size = New System.Drawing.Size(103, 158)
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(102, 22)
        Me.ToolStripMenuItem7.Text = "&400%"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(102, 22)
        Me.ToolStripMenuItem8.Text = "&200%"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(102, 22)
        Me.ToolStripMenuItem6.Text = "1&50%"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(102, 22)
        Me.ToolStripMenuItem5.Text = "1&25%"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(102, 22)
        Me.ToolStripMenuItem4.Text = "&100%"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(102, 22)
        Me.ToolStripMenuItem3.Text = "&81%"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(102, 22)
        Me.ToolStripMenuItem2.Text = "&75%"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 22.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(405, 227)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.Name = "MainForm"
        Me.Text = "Mates8 Calculator"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.mnFactor.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutMates6CalculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents OptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkClear As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkEng As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkIgnoreCase As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkRound As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FunctionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CALCULATEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbFns As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents mnClearAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LBHistQuery As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents LBHistVars As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents IncrementToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DecrementToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents cbExamples As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents lblClr As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblEng As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblCase As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblRnd As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblSpring As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents rtbVars As System.Windows.Forms.RichTextBox
    Friend WithEvents rtbQuery As System.Windows.Forms.RichTextBox
    Friend WithEvents lblZoom As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents mnFactor As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblImag As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblNext As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblPrev As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ClearAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblMsg As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents chkHexa As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkBinary As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbGreek As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkIgnoreCR As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkDetail As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkOctal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogicalOperatorsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnAND As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnOR As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnNOT As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnXOR As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnNOR As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnNAND As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents lblSpaces As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents mnEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OutputToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkFractions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbTimeout As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents chkVarNameLen1char As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkNumsInVarname As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RestoreDefaultOptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveOptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents Clear As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GotoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FontToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SelectAllAndCopy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearAllPaste As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Paste As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents AppenFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GotoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnGotoPrev As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnGotoNext As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkUnits As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbUnitsExamples As System.Windows.Forms.ToolStripComboBox

End Class
