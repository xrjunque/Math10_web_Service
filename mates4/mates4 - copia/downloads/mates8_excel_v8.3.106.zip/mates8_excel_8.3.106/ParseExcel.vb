﻿Imports System.Drawing
Imports System.Text.RegularExpressions

Public Class ParseExcel
    Public Shared us As New Globalization.CultureInfo("en-US")
    Dim hoja As Excel.Worksheet
    Dim vsToCalc(-1) As String, iToCalc As Int32

    Dim rowResponse As Int32
    Dim resp As String
    Dim sVariables As String = "variables"
    Dim sResponse As String = "response"
    Dim sCalculate As String = "calculate:"
    Dim oVars As VarsAndFns 'as variables
    Dim m8 As New matrixParser
    Dim sVarAll As String
    Friend cfg As New Config
    Public Sub New(ByVal hoja As Excel.Worksheet)
        Me.hoja = hoja
    End Sub
    Public Sub DoAll(ByVal bClearAll As Boolean)
        Try
            Dim curRow As Int32 = 0
            iToCalc = 0
            If bClearAll Then
                clearAll()
            Else
                clear()
                oVars = Nothing
                sVarAll = ""
                getConfig()
                getVars()
                getExpressionsAndCalc()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Sub clearAll()
        Try
            Dim row As Int32
            Dim o = Nothing
            Dim col As Int32
            For row = 1 To hoja.UsedRange.Rows.Count
                o = hoja.Cells.Cells(row, 1).value
                If o IsNot Nothing AndAlso Len(o) Then
                    If InStr(LCase(CStr(o)), sVariables) > 0 Then
                        rowResponse = row
                        Exit For
                    End If
                End If
            Next
            For row = rowResponse + 1 To hoja.UsedRange.Rows.Count
                For col = 1 To hoja.UsedRange.Columns.Count
                    o = hoja.Cells.Cells(row, 1).value
                    If col = 1 AndAlso _
                    o IsNot Nothing AndAlso _
                    InStr(o, "=") = 0 Then
                    Else
                        hoja.Cells.Cells(row, col).value = ""
                    End If
                Next
            Next
        Catch ex As Exception

        End Try
    End Sub
    Sub clear()
        Try
            Dim row As Int32
            Dim o = Nothing
            Dim col As Int32
            For row = 1 To hoja.UsedRange.Rows.Count
                o = hoja.Cells.Cells(row, 1).value
                If o IsNot Nothing AndAlso Len(o) Then
                    If InStr(LCase(CStr(o)), sResponse) > 0 Then
                        rowResponse = row
                        Exit For
                    End If
                End If
            Next
            For row = rowResponse + 1 To hoja.UsedRange.Rows.Count
                For col = 1 To hoja.UsedRange.Columns.Count
                    hoja.Cells.Cells(row, col).value = ""
                Next
            Next
        Catch ex As Exception

        End Try
    End Sub
    Sub getConfig()
        Try
            Dim row As Int32
            Dim o = Nothing
            Dim bFound As Boolean = False
            cfg.Base = MathGlobal8.outputBase.decimal
            cfg.outputFormat = outputMsgFormat.plainText

            For row = 1 To hoja.UsedRange.Rows.Count
                o = hoja.Cells.Cells(row, 1).value
                If bFound Then
                    Dim s As String = LCase(o)
                    Dim oVal As Object = hoja.Cells.Cells(row, 2).value
                    Dim bIsTrue As Boolean = False
                    If oVal IsNot Nothing Then
                        oVal = LCase(oVal)
                        If InStr(oVal, "t") Then
                            bIsTrue = True
                        End If
                    End If
                    If InStr(s, "round") Then
                        cfg.bRounding = bIsTrue
                    ElseIf InStr(s, "frac") Then
                        cfg.bFractions = bIsTrue
                    ElseIf InStr(s, "case") Then
                        cfg.bCaseSensitive = bIsTrue
                    ElseIf InStr(s, "space") Then
                        cfg.bIgnoreSpaces = bIsTrue
                    ElseIf InStr(s, "eng") Then
                        cfg.bEngNotation = bIsTrue
                    ElseIf InStr(s, "hex") Then
                        cfg.Base = MathGlobal8.outputBase.hexadecimal
                    ElseIf InStr(s, "oct") Then
                        cfg.Base = MathGlobal8.outputBase.octal
                    ElseIf InStr(s, "bin") Then
                        cfg.Base = MathGlobal8.outputBase.binary
                    ElseIf InStr(s, "units") Then
                        cfg.bUseUnits = bIsTrue
                    ElseIf InStr(s, "timeout") Then
                        Select Case CStr(oVal)

                            Case "10" : cfg.timeOutms = 10 * 1000
                            Case "20" : cfg.timeOutms = 20 * 1000
                            Case "30" : cfg.timeOutms = 30 * 1000
                            Case "60" : cfg.timeOutms = 60 * 1000

                            Case Else : cfg.timeOutms = 6 * 1000

                        End Select
                    End If
                End If
                If o Is Nothing OrElse InStr(o, ":") Then
                    If LCase(o) <> "config:" Then
                        Exit For
                    End If
                    bFound = True
                End If
            Next
        Catch ex As Exception

        End Try
    End Sub
    Public Sub setConfig()
        Try
            Dim row As Int32
            Dim o = Nothing
            Dim bFound As Boolean = False
            cfg.Base = MathGlobal8.outputBase.decimal
            For row = 1 To hoja.UsedRange.Rows.Count
                o = hoja.Cells.Cells(row, 1).value
                If bFound Then
                    Dim s As String = LCase(o)
                    Dim oVal As Object = hoja.Cells.Cells(row, 2).value
                    Dim bIsTrue As Boolean = False
                    If oVal IsNot Nothing Then
                        oVal = LCase(oVal)
                        If InStr(oVal, "t") Then
                            bIsTrue = True
                        End If
                    End If
                    If InStr(s, "round") Then
                        oVal = cfg.bRounding.ToString
                    ElseIf InStr(s, "frac") Then
                        oVal = cfg.bRounding.ToString
                    ElseIf InStr(s, "case") Then
                        oVal = cfg.bRounding.ToString
                    ElseIf InStr(s, "space") Then
                        oVal = cfg.bRounding.ToString
                    ElseIf InStr(s, "eng") Then
                        oVal = cfg.bRounding.ToString
                    ElseIf InStr(s, "hex") Then
                        oVal = (cfg.Base = MathGlobal8.outputBase.hexadecimal)
                    ElseIf InStr(s, "oct") Then
                        oVal = (cfg.Base = MathGlobal8.outputBase.octal)
                    ElseIf InStr(s, "bin") Then
                        oVal = (cfg.Base = MathGlobal8.outputBase.binary)
                    End If
                    hoja.Cells.Cells(row, 2).value = oVal.ToString
                End If
                If o Is Nothing OrElse InStr(o, ":") Then
                    If LCase(o) <> "config:" Then
                        Exit For
                    End If
                    bFound = True
                End If
            Next
        Catch ex As Exception

        End Try
    End Sub
    Sub getVars()
        Try
            Dim row As Int32
            Dim o = Nothing
            Dim bFound As Boolean = False
            For row = 1 To hoja.UsedRange.Rows.Count
                o = hoja.Cells.Cells(row, 1).text
                If bFound Then
                    If o IsNot Nothing AndAlso Len(o) Then
                        If InStr(o, "=") = 0 Then
                            Exit For
                        Else
                            If Len(sVarAll) Then
                                sVarAll += vbCrLf
                            End If
                            sVarAll += o
                            For mtxRow As Int32 = row To hoja.UsedRange.Rows.Count
                                Dim mtxCol As Int32
                                For mtxCol = 2 To hoja.UsedRange.Columns.Count
                                    o = hoja.Cells.Cells(mtxRow, mtxCol).text
                                    If o Is Nothing OrElse o = "" Then
                                        Exit For
                                    End If
                                    If mtxCol > 2 Then
                                        sVarAll += ";"
                                    End If
                                    sVarAll += o
                                Next
                                If mtxCol = 2 Then
                                    Exit For
                                End If
                                sVarAll += vbCrLf
                            Next
                        End If
                    End If
                    Dim s As String = LCase(o)
                    Dim oVal As Object = hoja.Cells.Cells(row, 2).value
                ElseIf o IsNot Nothing AndAlso Len(o) AndAlso _
                    InStr(o, "=") = 0 Then
                    If InStr(LCase(o), "variable") Then
                        bFound = True
                    End If
                End If
            Next
            getoVars()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Sub getoVars()
        Try
            m8.parse("1", sVarAll, oVars, cfg)
            If m8.errMsg.Length Then
                MsgBox(m8.errMsg)
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Sub getExpressionsAndCalc()
        Try
            Dim row As Int32
            Dim o = Nothing
            Dim bFound As Boolean = False
            Dim firstRow As Int32 = 1
            Dim lastRow As Int32 = 1
            For row = 1 To hoja.UsedRange.Rows.Count
                o = hoja.Cells.Cells(row, 1).text
                If bFound Then
                    If o IsNot Nothing AndAlso Len(o) Then
                        If InStr(o, ":") Then
                            Exit For
                        Else
                            For mtxRow As Int32 = row - 1 To hoja.UsedRange.Rows.Count
                                o = hoja.Cells.Cells(mtxRow, 2).text
                                Dim o1 = hoja.Cells.Cells(row, 1).text
                                If o1 IsNot Nothing AndAlso InStr(o1, ":") Then
                                    lastRow = mtxRow
                                    Exit For 
                                End If
                                If o Is Nothing OrElse o = "" Then
                                Else
                                    ReDim Preserve Me.vsToCalc(iToCalc)
                                    Me.vsToCalc(iToCalc) = o
                                    iToCalc += 1
                                End If
                            Next
                            Exit For
                        End If
                    End If
                    Dim s As String = LCase(o)
                    Dim oVal As Object = hoja.Cells.Cells(row, 2).value
                ElseIf o IsNot Nothing AndAlso Len(o) AndAlso _
                    InStr(o, "=") = 0 Then
                    If InStr(LCase(o), "calc") AndAlso _
                    InStr(o, ":") Then
                        firstRow = row
                        lastRow = row
                        bFound = True
                    End If
                End If
            Next
            For row = firstRow To hoja.UsedRange.Rows.Count
                o = hoja.Cells.Cells(row, 1).text
                If o IsNot Nothing AndAlso Len(o) Then
                    If InStr(LCase(o), "res") Then
                        firstRow = row + 1
                        Exit For
                    End If
                End If
            Next
            For iCur As Int32 = 0 To iToCalc - 1
                ' Calculate:
                m8.parse(Me.vsToCalc(iCur), "", oVars, cfg)
                ' and display:
                firstRow = dspResultado(firstRow, iCur)
            Next
        Catch ex As Exception

        End Try
    End Sub

    Function dspResultado(ByVal curRow As Int32, ByVal curRespuesta As Int32) As Int32
        Dim retRow As Int32
        Try
            Dim i, j, row As Int32
            Dim o
            If curRow = 0 Then
                For row = hoja.UsedRange.Rows.Count To 1 Step -1
                    o = hoja.Cells.Cells(row, 1).value
                    If o IsNot Nothing AndAlso Len(o) Then
                        If InStr(LCase(CStr(o)), sResponse) > 0 Then
                            Exit For
                        End If
                    End If
                Next
                If row < 1 Then
                    MsgBox("Couldn't find a cell for 'Response'")
                    Exit Function
                End If
                row += 1
            Else
                row = curRow
            End If

            Dim sResponseDsp As String = String.Empty
            If m8.errMsg.Length Then
                sResponseDsp = m8.errMsg
            Else
                sResponseDsp = m8.ToString(cfg)
            End If
            hoja.Cells.Cells(row, 1).value = " " + vsToCalc(curRespuesta) + " ="
            If m8.errMsg.Length Then
                hoja.Cells.Cells(row, 2).value = m8.errMsg
            Else
                Dim e1() As String = Split( _
                        sResponseDsp, vbCrLf)
                Dim ncols As Int32
                For i = 0 To e1.Length - 1
                    Dim e2() As String = Split(e1(i), ";")
                    ncols = e2.Length
                    For j = 0 To e2.Length - 1
                        hoja.Cells.Cells(row + i, 2 + j).value = "'" + e2(j)
                    Next
                Next
            End If
            retRow = row + i + 1
        Catch ex As Exception
            Throw ex
        End Try
        Return retRow
    End Function
End Class
