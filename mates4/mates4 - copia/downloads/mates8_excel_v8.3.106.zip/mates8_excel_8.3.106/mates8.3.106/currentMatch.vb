﻿Imports System.Text.RegularExpressions
Imports System.Text

<Serializable()> _
Public Class currentMatch
    Friend imc As Int32
    Friend vMc() As Match
    Dim _tipo As exprType
    Dim _subT1 As exprSubType1
    Dim _subT2 As exprSubType2
    Friend oldT1, oldT1bis As exprSubType1
    Friend oldT2 As exprSubType2
    Friend oldTipo As exprType
    Public str As String
    Public bIsEquation As Boolean

    Friend LP As Int32 = 0
    Friend RP As Int32 = 0
    Public msg As String
    Dim vars As VarsAndFns
    Dim re As Regex
    Public bIsMtxExpr As Boolean
    Public fstVarName As String
    Friend iCur1 As Int32
    Dim bIntegral As Boolean
    Dim curBase As exprSubType1 = exprSubType1.decBase
    Dim curAngle As exprSubType1 = exprSubType1.radian
    Dim bGoToNext As Boolean
    Dim sInsChar As String
    Public bOldFnHasLP As Boolean
    Public curValue As Double
    Friend cfg As Config
    Friend oVarsAt(-1) As VarsAndFns, iAt As Int32 = 0

    'Public Sub New(cfg As Config)
    '    Me.cfg = cfg
    'End Sub
    Private err1 As Exception
    Friend sb As StringBuilder
    Dim sOld As String
    Dim currType, oldType As tknGnralType
    Friend DxOrder As Int32
    Public bVerify As Boolean = True
    Public dcm As Detall_curMatch
    Public Shared sClr1 As String = "<span style=""color:orange"">"
    Public Shared sClr2 As String = "<span style=""color:#FF3333"">"
    Public Shared sClr3 As String = "<span style=""color:brown"">"
    Public Shared sEndTag As String = "</span>"
    Public Function Clone() As currentMatch
        Return Me.MemberwiseClone
    End Function
    Public Function parseCurMatch(ByVal expression As String, _
                                  ByRef vars As VarsAndFns, cfg As Config) As currentMatch
        Dim curMatch As currentMatch = Me
        Dim sbMtx As New System.Text.StringBuilder(expression.Length)
        Try
            Me.cfg = cfg
            sb = New StringBuilder(expression.Length)
            ' Is there any '( = )' wrong sequence?
            Dim m0 As Match = Regex.Match(expression, "\(([^\(\)\=]+)?\=([^\(\)]+)?\)")
            If m0.Success Then
                Dim e0 As String = expression
                Dim sErr As String = String.Format(msg8.num(57)) + vbCrLf
                Dim sL As String = String.Empty
                Dim sR As String = String.Empty
                Dim pos As Int32 = m0.Index
                If pos > 1 Then
                    sL = Mid(e0, 1, pos)
                End If
                If pos + m0.Length < Len(e0) Then
                    sR = Mid(e0, 1 + pos + m0.Length)
                End If
                If cfg.outputFormat = outputMsgFormat.plainText Then
                    sErr += vbCrLf + sL + "[ " + m0.ToString + "]" + sR + vbCrLf
                ElseIf cfg.outputFormat = outputMsgFormat.HTML Then
                    sErr += vbCrLf + sL + "<span style='color:red'>" + m0.ToString + "</span>" + sR + vbCrLf
                ElseIf cfg.outputFormat = outputMsgFormat.RichTextFormat Then
                    sErr += vbCrLf + sL + "[ " + m0.ToString + "]" + sR + vbCrLf
                End If
                Throw New Exception(sErr)
            End If
            If cfg.bIgnoreSpaces Then
                expression = Regex.Replace(expression, _
                        "\s+", "")
            End If
otroIntento:
            Dim posEq As Int32 = InStr(expression, "=")
            If posEq > 0 Then
                Dim e1 As String = _
                     Regex.Replace(expression, MathGlobal8.sComment, "")
                Dim mOpEq As Match = Regex.Match(expression, "[-+*\/\^\%]\=")
                Dim posAt As Int32 = InStr(e1, "@")
                If mOpEq.Success Then
                    Dim str1 As String = String.Empty
                    If posEq > 2 Then str1 = Mid(expression, 1, posEq - 2)
                    If cfg.outputFormat = outputMsgFormat.HTML Then
                        str1 += "<span style=""color:red"">" + _
                        mOpEq.ToString.Chars(0) + "</span>"
                        If mOpEq.ToString.Length > 1 Then
                            str1 += mOpEq.ToString.Substring(1)
                        End If
                        str1 += "<br />" + vbCrLf
                    Else
                        str1 += " [ " + _
                        mOpEq.ToString.Chars(0) + " ] "
                        If mOpEq.ToString.Length > 1 Then
                            str1 += mOpEq.ToString.Substring(1)
                        End If
                        str1 += vbCrLf
                    End If
                    Throw New Exception(str1 + msg8.num(57))
                ElseIf posAt > 0 AndAlso posAt < posEq Then
                ElseIf posAt > posEq Then
                    Throw New Exception(msg8.num(13)) ' n/a
                Else
                    Dim mcEq As MatchCollection = Regex.Matches(e1, _
                            "(^\s*|" + MathGlobal8.sCol + "\s*|" + MathGlobal8.sRow + "\s*)\=" + _
                            "|\=($\s*|" + MathGlobal8.sCol + "|" + MathGlobal8.sRow + "\s*)")
                    If mcEq.Count Then
                        Throw New Exception(msg8.num(41)) ' eq. missing Left or R. member
                    End If
                    e1 = Replace(e1, "|", vbCrLf)
                    e1 = Regex.Replace(e1, _
                            "\=(?<R>[^\r\n]+)(?=[\r\n\|]+|$)", "-(${R})")
                    'If posEq <= 1 OrElse pos = Len(e1) Then
                    '    Throw New Exception(msg8.num(41)) ' eq. missing Left or R. member
                    'ElseIf pos > 0 AndAlso pos < Len(e1) Then
                    '    If InStr(e1, ",") Then
                    '        expression = Replace(expression, ",", vbCrLf)
                    '        GoTo otroIntento
                    '    Else
                    '        Throw New Exception(msg8.num(61)) ' more than 1 equal sign
                    '    End If
                    'End If
                    expression = e1
                    bIsEquation = True
                End If
            End If
            With curMatch
                Dim sVar As String = ""
                If vars IsNot Nothing Then
                    .vars = vars
                    sVar = vars.getVarsStrListToAppend
                End If
parseAgain:
                If Len(sVar) > 1 Then
                    cfg.mathGlobal.nomVarsToAppend = sVar
                Else
                    cfg.mathGlobal.nomVarsToAppend = ""
                End If
                .re = New Regex( _
                    Replace( _
                    cfg.mathGlobal.sAll2, "@", ""))

                iAt = 0
                sVar = ""
                Dim bDoParseAgain As Boolean = False
                Dim mc As MatchCollection = .re.Matches(expression)
                ReDim vMc(mc.Count - 1)
                mc.CopyTo(vMc, 0)
                Dim bLastWasMtx As Boolean = False
                Dim prevMtxOp As Boolean = False

                ' Find out if current expression is
                ' a matrix expression, i.e. contains matrix operators
                ' or columns and/or rows; or has a matrix
                ' result, i.e. a matrix function as in "roots(x2-1)":
                For i As Int32 = 0 To .vMc.Length - 1
                    If .vMc(i).Groups("comment").Success Then
                        bDoParseAgain = True
                    ElseIf .vMc(i).Groups("at").Success Then
                        If (curMatch.bIsEquation AndAlso curMatch.vMc(i).ToString.Chars(0) = "=") Then
                            Dim str1 As String = String.Empty
                            For i1 As Int32 = 0 To i - 1
                                str1 += .vMc(i1).ToString
                            Next
                            If cfg.outputFormat = outputMsgFormat.HTML Then
                                str1 += "<span style=""color:red"">" + vMc(i).ToString + "</span>"
                            Else
                                str1 += " [ " + vMc(i).ToString + " ] "
                            End If
                            For i1 As Int32 = i + 1 To .vMc.Length - 1
                                str1 += .vMc(i1).ToString
                            Next
                            If cfg.outputFormat = outputMsgFormat.HTML Then
                                str1 += "<br />"
                            Else
                                str1 += vbCrLf
                            End If
                            str1 += msg8.num(61)
                            Throw New Exception(str1)
                        ElseIf .vMc(i).ToString.Chars(0) <> "@" Then
                            Dim str1 As String = String.Empty
                            If cfg.outputFormat = outputMsgFormat.HTML Then
                                str1 = "<span style=""color:red"">" + _
                                .vMc(i).ToString.Chars(0) + "</span>"
                                If .vMc(i).ToString.Length > 1 Then
                                    str1 += .vMc(i).ToString.Substring(1)
                                End If
                            Else
                                str1 = " [ " + _
                                .vMc(i).ToString.Chars(0) + " ] "
                                If .vMc(i).ToString.Length > 1 Then
                                    str1 += .vMc(i).ToString.Substring(1)
                                End If
                            End If
                            Throw New Exception(String.Format( _
                            msg8.num(5), str1))
                        End If
                        ReDim Preserve .oVarsAt(iAt)
                        .oVarsAt(iAt) = New VarsAndFns(cfg)
                        Dim sVarsAt As String = .vMc(i).ToString.Substring(1)
                        Try
                            VarsAndFns.parseVariables(cfg, sVarsAt, .oVarsAt(iAt))
                        Catch ex As Exception
                            Throw New Exception(msg8.num(13)) ' n/a
                        End Try
                        vars = New VarsAndFns(.oVarsAt(iAt))
                        sVar = .oVarsAt(iAt).getVarsStrListToAppend
                        'For j As Int32 = 0 To oVarsAt.Length - 1
                        '    Dim fn As customFn = Nothing
                        '    If oVarsAt(iAt).IsCustomFn(j, fn) Then

                        '    End If
                        'Next
                        If .vMc(i).Groups("row").Success Then
                            iAt += 1
                            sbMtx.Append(vbCrLf)
                        End If
                        bDoParseAgain = True
                        prevMtxOp = False
                    ElseIf .vMc(i).Groups("mtxFn").Success OrElse _
                    .vMc(i).Groups("mtxOp").Success OrElse _
                    .vMc(i).Groups("col").Success OrElse _
                    .vMc(i).Groups("row").Success OrElse _
                    .vMc(i).Groups("integral").Success Then
                        If Not .vMc(i).Groups("col").Success AndAlso _
                        Not .vMc(i).Groups("integral").Success AndAlso _
                        Not .vMc(i).Groups("mtxFn").Success AndAlso _
                        Not .vMc(i).Groups("row").Success Then
                            iAt += 1
                        End If
                        sbMtx.Append(.vMc(i))
                        .bIsMtxExpr = True
                        bLastWasMtx = False
                        prevMtxOp = False
                    ElseIf vars IsNot Nothing AndAlso _
                   (.vMc(i).Groups("var2").Success OrElse _
                    .vMc(i).Groups("var").Success) Then
                        Dim eM As ExprMatrix = _
                            vars.getValueByName(.vMc(i).ToString, False)
                        If eM IsNot Nothing AndAlso _
                        eM.Rows + eM.Cols > 2 Then
                            .bIsMtxExpr = True
                            ' 'expression' contains a variable name whose
                            ' value is a matrix --> copy the value to sbMtx and,
                            ' after, the expression will be parsed again
                            ' including the matrix value instead of the name
                            'If (i = 1 AndAlso .mcOrig(i - 1).ToString = "-") _
                            '    OrElse _
                            '(i > 1 AndAlso .mcOrig(i - 1).ToString = "-" AndAlso _
                            '(.mcOrig(i - 2).Groups("lp").Success OrElse _
                            ' .mcOrig(i - 2).Groups("op").Success)) Then
                            '    ' -A*... or B(-A... or B/-A... etc.
                            '    ' imply changing the matrix sign
                            '    For irow As Int32 = 0 To eM.Rows - 1
                            '        For icol As Int32 = 0 To eM.Cols - 1
                            '            eM.getExpr(irow, icol) = -eM.getExpr(irow, icol)
                            '        Next
                            '    Next
                            '    sbMtx.Chars(sbMtx.Length - 1) = " "
                            'End If

                            'Dim bRnd As Boolean = cfg.bRounding
                            'cfg.bRounding = False
                            'sbMtx.Append("(" + Replace(eM.ToStringExprMtx(cfg), vbCrLf, "|") + ")|")
                            'cfg.bRounding = bRnd

                            'bDoParseAgain = True
                            'bLastWasMtx = True
                            'prevMtxOp = False
                            prevMtxOp = False
                            sbMtx.Append(.vMc(i).ToString)

                        Else
                            If .fstVarName = "" AndAlso _
                            Not curMatch.vMc(i).Groups("Dx").Success AndAlso _
                            Not curMatch.vMc(i).Groups("Idx").Success Then
                                .fstVarName = .vMc(i).ToString
                            End If
                            sbMtx.Append(.vMc(i))
                            prevMtxOp = False
                        End If
                    Else
                        ' Convert operator into mtxop inserting
                        ' rows (vbcrlf). For ex. if
                        ' expression= "A^-1*A" being A=(1;2|3;4)
                        ' will become into expression="(1;2|3;4)|^|-1|*|(1;2|3;4)"
                        ' (here | represents a carriage return, vbCrLf)
                        'If bLastWasMtx AndAlso _
                        '((.mcOrig(i).Groups("op").Success AndAlso _
                        ' .mcOrig(i).ToString <> "-") AndAlso _
                        ' prevMtxOp = False) Then
                        '    prevMtxOp = True
                        '    sbMtx.Append("|" + .mcOrig(i).ToString + "|")
                        'Else
                        '    prevMtxOp = False
                        '    sbMtx.Append(.mcOrig(i).ToString)
                        'End If

                        prevMtxOp = False
                        sbMtx.Append(.vMc(i).ToString)
                    End If
                Next
                If bDoParseAgain Then
                    expression = sbMtx.ToString.Replace(" ", "")
                    expression = Replace(expression, "||", "|")
                    sbMtx.Remove(0, sbMtx.Length)
                    GoTo parseAgain
                End If
                .imc = -1
                .oldTipo = exprType.start  ' start match
                'If .dcm Is Nothing Then
                '.dcm = New Detall_curMatch(curMatch)
                Dim errMsg As String = ""
                'If Not .dcm.populate_sContent(errMsg) Then
                '    Throw New Exception(errMsg)
                'End If
                'End If
                .iCur1 = -1
            End With
            iAt = 0
        Catch ex As Exception
            If curMatch.msg = "" Then
                curMatch.msg = ex.Message
            End If
            'Throw New Exception(ex.Message)
            Throw New Exception(ex.Message)
        End Try
        Return curMatch
    End Function
    Public Sub reStartCurMatch(Optional ByVal setICur As Int32 = -1)
        Try
            'm = mcOrig(0)
            'str = m.ToString

            LP = 0 : RP = 0
            oldTipo = 0 : oldT1 = 0 : oldT2 = 0
            msg = ""
            oldTipo = 20 : _tipo = 90
            iCur1 = setICur
            If setICur = -1 Then
                Me.sb = New StringBuilder(sb.Capacity)
            End If
            'getTipo(m, tipo, _subT1, _subT2)
            'imc = setICur
            imc = -1
            doNext()
            'oldTipo = tipo
            'oldT1 = _subT1
            'oldT2 = _subT2
            'iCur1 = -1
            'imc = setICur
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Property mOld As Match
        Get
            If imc Then
                Dim i As Int32 = imc
                Do While i AndAlso _
                Trim(vMc(i - 1).ToString) = ""
                    i -= 1
                Loop
                Return vMc(i - 1)
            End If
            Return Nothing
        End Get
        Set(value As Match)
            If imc Then
                vMc(imc - 1) = value
            End If
        End Set
    End Property
    Public Property m As Match
        Get
            If imc < vMc.Length Then
                Return vMc(imc)
            End If
            Return vMc(vMc.Length - 1)
        End Get
        Set(value As Match)
            vMc(imc) = value
        End Set
    End Property
    Public ReadOnly Property iCur As Int32
        Get
            If iCur1 < 0 Then
                Return 0
            End If
            Return iCur1
        End Get
    End Property
    Public ReadOnly Property bEnd As Boolean
        Get
            Return imc >= vMc.Length
        End Get
    End Property
    Public ReadOnly Property tipo As exprType
        Get
            Return Me._tipo
        End Get
    End Property
    Public ReadOnly Property subT1 As currentMatch.exprSubType1
        Get
            Return Me._subT1
        End Get
    End Property
    Public ReadOnly Property subT2 As currentMatch.exprSubType2
        Get
            Return Me._subT2
        End Get
    End Property
    Sub insert_replace_mcOrig(ByVal strToInsOrReplace As String, _
                         Optional incr As Int32 = 0)
        Try
            Dim sb As New StringBuilder(Me.sb.ToString)
            sb.Append(strToInsOrReplace)
            imc += incr
            For i As Int32 = imc To vMc.Length - 1
                sb.Append(vMc(i))
            Next
            Dim mc As MatchCollection = re.Matches(sb.ToString)
            ReDim vMc(mc.Count - 1)
            mc.CopyTo(vMc, 0)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Sub doNext() ' get next token

        imc += 1

sig:
        If cfg.ID = 0 Then Throw New Exception(msg8.num(13))

        If imc >= vMc.Length Then
            If m.Groups("fn").Success Then
                err = New msg8B(Me, 3, New String() {str})
                Throw err
            End If
            _tipo = -1
            _subT1 = -1
            _subT2 = -1
            Exit Sub
        End If
        str = vMc(imc).ToString

        If Trim(str) = "" Then
            sb.Append(str)
            imc += 1
            GoTo sig
        End If

        getTipo(vMc(imc), _tipo, _subT1, _subT2)
        If bGoToNext Then
            imc += 1
            bGoToNext = False
            GoTo sig
        End If

        'Trace.WriteLine(str + " " + tipo.ToString + " " + imc.ToString + " " + sb.ToString)
        If Not bVerify OrElse Validate() Then
            iCur1 += 1
            sOld = str
            oldTipo = _tipo
            oldT1bis = oldT1
            oldT1 = _subT1
            oldT2 = _subT2
            oldType = currType
            sb.Append(str)
        ElseIf bGoToNext Then
            ' inserted operators * , ^
            ' or found &rad, &deg, ...
            bGoToNext = False
            GoTo sig
        Else
            Throw err
        End If


    End Sub
    Function testNextMatch(ByVal incr As Int32, _
                     ByRef tipo As exprType, _
                     ByRef subT1 As exprSubType1, _
                     ByRef subT2 As exprSubType2, _
                     Optional oldTipo As exprType = -1) As Match
        Dim m As Match = Nothing
        Try
            If imc + incr < vMc.Length Then
                m = vMc(imc + incr)
                Do While imc + incr < vMc.Length AndAlso _
                Len(Trim(m.ToString)) = 0
                    incr += 1
                Loop
                If imc + incr < vMc.Length Then
                    getTipo(m, tipo, subT1, subT2)
                End If
            Else
                tipo = 0 : subT1 = 0 : subT2 = 0
                m = Regex.Match("", " ")
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Return m
    End Function
    Function getCurBase() As exprSubType1
        Return curBase
    End Function
    Function getCurAngle() As exprSubType1
        Return curAngle
    End Function

    Private Sub getTipo(ByVal m As Match, _
                     ByRef tipo As exprType, _
                     ByRef subT1 As exprSubType1, _
                     ByRef subT2 As exprSubType2, _
                     Optional ByVal bIncrRPLP As Boolean = True)
        tipo = 0
        subT1 = 0
        subT2 = 0
        Dim str As String = m.ToString
        If m.Groups("rp").Success Then
            tipo = exprType.RP  ' 0 ' right parenth.
            currType = tknGnralType.RP
        ElseIf m.Groups("lp").Success Then
            tipo = exprType.LP ' 1 ' left parenth.
            currType = tknGnralType.lp
        ElseIf m.Groups("num").Success OrElse _
        (curBase = exprSubType1.hexBase AndAlso _
         m.Groups("var2").Success AndAlso _
        Regex.IsMatch(m.ToString, "[.0-9a-fA-F]")) Then
            If bOldFnHasLP AndAlso oldTipo = exprType.fn AndAlso _
            oldT2 <> exprSubType2.integral Then
                If Len(str) <> 1 OrElse _
                str < "2" OrElse str > "9" Then
                    ' si más de D9x --> error
                    Dim str1 As String = String.Empty
                    If (cfg.outputFormat = outputMsgFormat.HTML) Then
                        str1 = "<span style=""color:red"">" + str + "</span>"
                    Else
                        str1 = "[ " + str + "]"
                    End If
                    Dim ce As New curMatchErr
                    Throw ce.err(Nothing, Me, String.Format( _
                    msg8.num(33), str, mOld.ToString + str1))
                End If
                tipo = exprType.fnExponent
            Else 'If curBase <> exprSubType1.defaultDecBase Then
                tipo = exprType.num ' 2 ' numeric
                subT1 = Me.getCurBase
                Dim retDec As Decimal
                If str = "." OrElse InStr(str, "..") Then
                    Dim str1 As String = String.Empty
                    If (cfg.outputFormat = outputMsgFormat.HTML) Then
                        str1 = "<span style=""color:red"">" + str + "</span>"
                    Else
                        str1 = "[ " + str + "]"
                    End If
                    Me.iCur1 += 1
                    If cfg.outputFormat = outputMsgFormat.HTML Then
                        Me.msg = msg8.num(57) + "<br />" + Me.ToString
                    Else
                        Me.msg = msg8.num(57) + vbCrLf + Me.ToString
                    End If
                    Throw New Exception(Me.msg)
                End If
                If curBase = exprSubType1.decBase AndAlso _
                MathGlobal8.TryParseDbl(str, curValue) Then
                Else
                    Me.tryParseHexDecOctBinBaseNum(retDec)
                End If
            End If
            currType = tknGnralType.num
        ElseIf m.Groups("cnt").Success OrElse _
            m.Groups("img").Success Then
            tipo = exprType.cnt ' 3 ' constant
            If str = "pi" Then
                Me.curValue = Math.PI
            ElseIf str = "e" Then
                Me.curValue = Math.E
            End If
            currType = tknGnralType.Cnt
        ElseIf m.Groups("custFn").Success Then
            tipo = exprType.custFn ' 8 ' custom function
            LP += 1
            currType = tknGnralType.fn
        ElseIf m.Groups("Dx").Success Then
            Dim custFnID As Int32
            If Me.vars.tryGetVarIDByName(str + "(", custFnID) Then
                ' It is not the derivative operator.
                ' There is function D(params)=... defined 
                ' (for example: D(x)=x+1 or d(x)=x+1)
                str += "("
                Me.str = str
                tipo = exprType.custFn ' 8 ' custom function
                LP += 1
                currType = tknGnralType.fn
            Else
                tipo = exprType.Dx '  7 ' derivative (must preceed .Groups("var/var2")
                currType = tknGnralType.lp ' includes Dx
                Dim mOrder As Match = Regex.Match(str, "\d+")
                If mOrder.Success Then
                    If Not Int32.TryParse(mOrder.ToString, Me.DxOrder) Then
                        Me.DxOrder = 1
                    End If
                Else
                    Me.DxOrder = 1
                End If
            End If
        ElseIf m.Groups("Idx").Success AndAlso Len(str) > 1 Then
            If bIntegral AndAlso m.Length > 1 Then
                tipo = exprType.integralRespVar
                If m.Groups("IResp").Success Then
                    subT2 = exprSubType2.integralResp
                End If
                bIntegral = False
            Else
                tipo = exprType.var ' 4 ' variable
                subT1 = exprSubType1.var2
            End If
            currType = tknGnralType.integrRespTo
        ElseIf m.Groups("var2").Success OrElse _
        m.Groups("Idx").Success Then
            tipo = exprType.var ' 4 ' variable
            subT1 = exprSubType1.var2
            currType = tknGnralType.variable
        ElseIf m.Groups("var").Success Then
            tipo = exprType.var ' 4 ' variable
            subT1 = exprSubType1.var
            currType = tknGnralType.variable
        ElseIf m.Groups("fn").Success Then
            tipo = exprType.fn ' 5 ' function
            subT1 = exprSubType1.oneElemFn
            If str = "mod" Then
                m = Regex.Match("%", MathGlobal8.sOp)
                str = "%"
                tipo = exprType.op
                subT1 = exprSubType1.op
                subT2 = exprSubType2.modulo
            ElseIf m.Groups("mtxFn").Success Then
                If m.Groups("mtxFn").Success Then
                    subT1 = exprSubType1.mtxFn
                Else
                    subT1 = exprSubType1.oneElemFn
                    If m.Groups("integral").Success Then
                        subT1 = exprSubType1.mtxFn
                        subT2 = exprSubType2.integral
                        bIntegral = True
                    End If
                End If
            ElseIf m.Groups("integral").Success Then
                subT1 = exprSubType1.oneElemFn
                subT2 = exprSubType2.integral
                bIntegral = True
            ElseIf m.Groups("sqr").Success AndAlso str = "√" Then
            Else
                tipo = exprType.fn ' 5 ' function
                If m.Groups("mtxFn").Success Then
                    subT1 = exprSubType1.mtxFn
                Else
                    subT1 = exprSubType1.oneElemFn
                    If m.Groups("integral").Success Then
                        subT2 = exprSubType2.integral
                        bIntegral = True
                    End If
                End If
            End If
            currType = tknGnralType.fn
        ElseIf m.Groups("op").Success OrElse _
            m.Groups("mtxOp").Success Then
            tipo = exprType.op  ' 6 ' optor
            currType = tknGnralType.optor
            If m.Groups("mtxOp").Success Then
                tipo = 9
                currType = tknGnralType.mtxOptor
            End If

            'Dim str As String = Me.str '  m.ToString
            If Regex.Match(str, MathGlobal8.sRow).Success Then
                str = _
                   Regex.Replace(m.ToString, _
                        MathGlobal8.sRow, "")
                subT1 = exprSubType1.mtxOp
                subT2 = exprSubType2.mtxsubs
            Else
                subT1 = exprSubType1.op
                subT2 = exprSubType2.subs
            End If
            Dim pos As Int32 = InStr("-+*/^!%", str)
            If pos = -1 Then
                Throw New Exception(String.Format( _
                    msg8.num(28), str)) ' unknown operator
            End If
            subT2 += pos - 1
            cfg.posLastOptor = iCur1

        ElseIf m.Groups("lgOp").Success Then
            tipo = exprType.op ' operator
            subT1 = exprSubType1.logicalOp
            '{"and", "or", "xor", "not", "nand", "nor"
            Dim pos As Int32 = Array.IndexOf(MathGlobal8.vLgOp, LCase(str))
            subT2 = exprSubType2.AND + pos
            currType = tknGnralType.andOrXorNandNor
        ElseIf m.Length AndAlso _
        m.ToString.Chars(0) = "&" Then
            If m.Groups("hex").Success Then
                subT1 = exprSubType1.hexBase
                If Len(str) = 2 Then
                    currType = tknGnralType.numericBase
                Else
                    tipo = exprType.num ' hexadecimal
                    currType = tknGnralType.num
                End If
            ElseIf m.Groups("dec").Success Then
                subT1 = exprSubType1.decBase
                If Len(str) = 2 Then
                    currType = tknGnralType.numericBase
                Else
                    tipo = exprType.num  ' decimal
                    currType = tknGnralType.num
                End If
            ElseIf m.Groups("oct").Success Then
                subT1 = exprSubType1.octBase
                If Len(str) = 2 Then
                    currType = tknGnralType.numericBase
                Else
                    tipo = exprType.num ' octal
                    currType = tknGnralType.num
                End If
            ElseIf m.Groups("bin").Success Then
                subT1 = exprSubType1.binBase
                If Len(str) = 2 Then
                    currType = tknGnralType.numericBase
                Else
                    tipo = exprType.num ' binary
                    currType = tknGnralType.num
                End If
            ElseIf m.Groups("rad").Success Then
                Me.curAngle = exprSubType1.radian
                bGoToNext = True
            ElseIf m.Groups("deg").Success Then
                Me.curAngle = exprSubType1.degree
                bGoToNext = True
            ElseIf m.Groups("grad").Success Then
                Me.curAngle = exprSubType1.gradian
                bGoToNext = True
            Else
                Dim ce As New curMatchErr
                Dim ex As Exception = ce.err(Nothing, Me, String.Format( _
                msg8.num(5), str))
                Throw ex
            End If
            If Not bGoToNext Then
                Me.curBase = subT1
                If Len(str) > 2 Then
                    'currType = tknGnralType.numericBase
                    'Dim retDec As Decimal
                    str = Mid(str, 3)
                    If Me.tryParseHexDecOctBinBaseNum(curValue) Then
                        'str = retDec.ToString(MathGlobal8.us)
                        subT1 = exprSubType1.decBase
                    End If
                Else
                    mOld = vMc(iCur)
                    bGoToNext = True
                End If
            End If
        ElseIf m.Groups("comment").Success Then
            bGoToNext = True
        ElseIf cfg.bUseUnits AndAlso _
        m.Groups("varucs").Success Then
            ' treat units as if were variables:
            tipo = exprType.var ' 4 ' variable
            subT1 = exprSubType1.var
            subT2 = exprSubType2.derviedUnitCS
            currType = tknGnralType.variable
            If m.Groups("preucs").Success Then
                Dim pos As Int32 = _
                    Array.IndexOf( _
                    Units.preCS, _
                    m.Groups("preucs").ToString)
                If pos > -1 Then
                    Dim sVar As String = Mid(str, Len(m.Groups("preucs").ToString) + 1)
                    insert_replace_mcOrig( _
                    sVar + "*" + Units.preValue(pos).ToString(MathGlobal8.us), 1)
                    imc -= 2
                    bGoToNext = True
                End If
            End If
            'If m.Groups("varfnducs").Success Then
            '    subT2 = exprSubType2.fundamentalUnitCS
            'ElseIf m.Groups("varfnduci").Success Then
            '    subT2 = exprSubType2.fundamentalUnitCI
            'ElseIf m.Groups("varucs").Success Then
            'ElseIf m.Groups("varuci").Success Then
            '    subT2 = exprSubType2.derivedUnitCI
            'End If
        Else
            tipo = 9
            If m.Groups("col").Success Then
                subT1 = exprSubType1.delimiter
                subT2 = exprSubType2.col
                currType = tknGnralType.col
            ElseIf m.Groups("row").Success Then
                subT1 = exprSubType1.delimiter
                subT2 = exprSubType2.row
                iAt += 1
                currType = tknGnralType.row
            ElseIf str = "=" Then
                subT1 = exprSubType1.equal
                currType = tknGnralType.equal
                Me.bIsEquation = True
            ElseIf Not m.Groups("substitute").Success Then
                For i = 0 To m.Groups.Count - 1
                    If m.Groups(i).Success Then
                        Dim nom As String = m.Groups(i).ToString
                    End If
                Next
                Dim ce As New curMatchErr
                Dim ex As Exception = ce.err(Nothing, Me, String.Format( _
                msg8.num(5), str))
                If Not ex Is Nothing Then
                    Throw ex
                Else
                    Throw New Exception(String.Format( _
                    msg8.num(5), str))
                End If
            Else
                Dim pos As Int32 = Array.IndexOf(MathGlobal8.vSubstitute, str)
                ' set substituting char(s) as source match collection
                ' into cur.mcSubstBy:
                Dim sSubstBy As String = String.Empty
                sSubstBy = MathGlobal8.vSubstituteBy(pos)
                Dim bTratado As Boolean = False
                If Len(sSubstBy) > 4 AndAlso InStr(sSubstBy, "/") Then
                    Dim e2() As String = Split(Mid(sSubstBy, 2, Len(sSubstBy) - 2), "/")
                    Dim num, den As Int32
                    If e2.Length = 2 AndAlso _
                    Int32.TryParse(e2(0), num) AndAlso _
                    Int32.TryParse(e2(1), den) Then
                        If oldTipo = exprType.num Then
                            ' for example, 2⅞ = 2+7/8
                            Dim bNeg As Boolean
                            For i As Int32 = iCur - 1 To 0 Step -1
                                If vMc(i).Groups("op").Success Then
                                    If vMc(i).ToString = "-" Then
                                        bNeg = True
                                    End If
                                    Exit For
                                End If
                            Next
                            Dim abs As Double = Math.Abs(curValue)
                            curValue = Math.Sign(curValue) * (abs + num / den)
                            sb.Remove(sb.Length - 1, str.Length)
                            'If bNeg Then
                            '    curValue *= -1
                            '    sb.Remove(sb.Length - 1, 1)
                            'Else
                            'End If
                            insert_replace_mcOrig(curValue.ToString(MathGlobal8.us), 1)
                            imc -= 3
                            Me.oldType = exprType.op
                            bGoToNext = True
                            bTratado = True
                        End If
                    End If
                    If Not bTratado Then
                        If oldTipo = exprType.var Then
                            sSubstBy = "^" + sSubstBy
                        Else
                            sSubstBy = sSubstBy
                        End If
                        insert_replace_mcOrig(sSubstBy, 1) ' skip 1?
                        imc -= 2
                        bGoToNext = True
                    End If
                Else
                    insert_replace_mcOrig(sSubstBy, 1)
                    imc -= 2
                    bGoToNext = True
                End If
                'currType = tknGnralType.substitute
            End If
        End If
    End Sub
    Public ReadOnly Property getParsedString
        Get
            Return sb.ToString
        End Get
    End Property
    Private Function tryParseHexDecOctBinBaseNum(ByRef result As Decimal) As Boolean
        Dim Ent As Long = 0
        Dim Fra As Double = 0.0
        Dim sPattern As String = ""
        Dim base As Int64 = 10
        Dim subT1 As exprSubType1 = curBase ' vCurBase(iBase)
        Dim bRet As Boolean = False
        Dim ns As Globalization.NumberStyles
        Try
            Select Case subT1
                Case exprSubType1.hexBase
                    sPattern = "[^.0-9abcdef]"
                    base = 16
                    ns = Globalization.NumberStyles.HexNumber
                Case exprSubType1.decBase
                    sPattern = "[^.0-9]"
                    base = 10
                    ns = Globalization.NumberStyles.Integer
                Case exprSubType1.octBase
                    sPattern = "[^.0-7]"
                    base = 8
                Case exprSubType1.binBase
                    sPattern = "[^.01]"
                    base = 2
            End Select
            Dim str As String = IIf(Me.str.Chars(0) = "&", Mid(Me.str, 3), Me.str)
            If Regex.IsMatch(str, "(?i)" + sPattern + "(-i)") Then
                Exit Try
            End If
            Dim i As Int32 = IIf(imc <= 0, 0, imc)
            Dim posDot As Int32 = InStr(str, ".")
            If posDot = 0 Then
                posDot = Len(str)
            Else
                If posDot < Len(str) AndAlso _
                InStr(posDot + 1, str, ".") Then
                    Exit Try
                End If
                posDot -= 1
            End If
            Dim curEnt As Long = 0L
            For j As Int32 = 0 To Len(str) - 1
                If j <> posDot Then
                    If Not Long.TryParse(str.Chars(j), curEnt) Then
                        ' si llega aqui es porque str.chars(j) = {a,b,..,f,A,B,... ,F}
                        ' asc("A")=65 ==> asc("A")-55=10, asc("B")-55=11,... asc("F")-55=15
                        curEnt = Asc(UCase(str.Chars(j))) - 55
                    End If
                End If
                If j < posDot Then
                    Ent = Ent * base + curEnt
                ElseIf j > posDot Then
                    Fra = Fra + curEnt / base ^ (j - posDot)
                End If
            Next
            bRet = True
            i += 1
            If bRet Then
                'imc = i - 1
                result = CDec(Ent) + CDec(Fra)
                Me.curValue = result
                curBase = getCurBase()
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Try
            If Not bRet Then
                Dim str1 As String = String.Empty
                If cfg.outputFormat = outputMsgFormat.HTML Then
                    str1 += "<span style=""color:red"">" + mOld.ToString + str
                    str1 += "</span><br />" + vbCrLf
                Else
                    str1 += " [ " + mOld.ToString + str + " ] "
                    str1 += vbCrLf
                End If
                Throw New Exception(str1 + msg8.num(57))
            End If
        Catch ex As Exception

        End Try
        Return bRet
    End Function
    'Public Sub verifyLR(Optional ByVal bGetLast As Boolean = False)
    '    Static bDoVerify As Boolean = True
    '    Try
    '        If Not bDoVerify Then Exit Sub
    '        If bGetLast OrElse imc >= mcOrig.Length Then
    '            If LP <> RP Then
    '                bDoVerify = False
    '                Dim e1 As String = toStrCurMatch("", False)
    '                bDoVerify = True
    '                Dim msg As String = String.Empty
    '                Dim pos As Int32
    '                If Not checkParentheses(cfg, e1, False, msg, pos) Then
    '                    iLevel = -1 : imc = mcOrig.Length
    '                    Throw New Exception(msg)
    '                End If
    '            End If
    '        Else
    '            If LP > RP Then
    '                Dim ce As New curMatchErr
    '                Throw ce.err(Nothing, Me, String.Format( _
    '                 msg8.num(1), "')'"))
    '            ElseIf LP < RP Then
    '                Dim ce As New curMatchErr
    '                Throw ce.err(Nothing, Me, String.Format( _
    '                 msg8.num(1), "'('"))
    '            ElseIf LP <> RP AndAlso tipo > 4 AndAlso tipo <> 9 AndAlso str <> "!" _
    '                AndAlso str <> "=" Then
    '                Dim ce As New curMatchErr
    '                Throw ce.err(Nothing, Me, msg8.num(4))
    '            End If
    '        End If
    '    Catch ex As Exception
    '        Throw ex
    '    End Try
    'End Sub
    Public Sub equalSign()
        Try
            Me.bIsEquation = True
            Dim e1 As String = ""
            imc += 1
            ' obtener en e1 el lado derecho
            ' de la igualdad y soslayar ese
            ' "tramo" de mcOrig() al incrementar
            ' imc:
            Dim imcOld As Int32 = imc
            Do While Not bEnd AndAlso _
            Not vMc(imc).Groups("row").Success
                e1 += vMc(imc).ToString
                imc += 1
            Loop
            If imcOld = imc Then
                Throw New Exception( _
                msg8.num(41)) ' missing left or right member
            End If
            Dim sErr As String = ""
            If Not Functions.checkParentheses(e1, False, sErr) OrElse _
            Not Functions.checkParentheses(ToString, False, sErr) Then
                Throw New Exception(msg8.num(42)) ' parentheses not matching
            End If
            If Not bEnd AndAlso _
            vMc(imc).Groups("row").Success Then
                imc -= 1
            End If
            ' ahora incluir lo obtenido
            ' (el signo = inicial es para retroceder
            ' el hilo de la ejecución a matrixParser.mtxExpr()
            ' y, allí, restar):
            imc -= 1
            insert_replace_mcOrig("-(" + e1 + ")")
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Function toStrCurMatch(ByVal bHTML As Boolean) As String
        Dim eb As StringBuilder = Nothing
        Try
            If bEnd Then
                Return ""
            End If
            eb = New StringBuilder(vMc.Length * 12)
            For i As Int32 = 0 To vMc.Length - 1
                If i <> imc OrElse Not bHTML Then
                    eb.Append(vMc(i))
                Else
                    eb.Append("<span style='color:red'>")
                    eb.Append(vMc(i))
                    eb.Append("</span>")
                End If
            Next
        Catch ex As Exception
            Return ""
        End Try
        Return eb.ToString
    End Function
    Public Function toStrCurMatch( _
                    Optional ByVal sDelimiter As String = "", _
                    Optional ByVal bShowCurPos As Boolean = True, _
                    Optional outFormat As outputMsgFormat = -1, _
                    Optional desde As Int32 = -1, _
                    Optional hasta As Int32 = -1) As String
        Dim e1 As String = ""
        'Dim cm As currentMatch
        Try
            If outFormat = -1 Then
                outFormat = cfg.outputFormat
            End If
            'cm = Me.Clone() ' MathGlobal8.CloneObject(Me)
            'cm.reStartCurMatch()
            Dim i As Int32 = 0
            Dim nRows As Int32 = 0
            If desde > -1 Then
                Do
                    If i < desde OrElse i > hasta OrElse Not bShowCurPos Then
                        e1 += vMc(i).ToString
                    Else
                        If i = desde Then
                            If outFormat = outputMsgFormat.HTML Then
                                e1 += "<span style=""color:red"">"
                            ElseIf outFormat = outputMsgFormat.RichTextFormat Then
                                e1 += "\cf2 "
                            Else
                                e1 += "["
                            End If
                        End If
                        e1 += vMc(i).ToString
                        If i = hasta Then
                            If outFormat = outputMsgFormat.HTML Then
                                e1 += "</span>"
                            ElseIf outFormat = outputMsgFormat.RichTextFormat Then
                                e1 += " \cf1 "
                            Else
                                e1 += "]"
                            End If
                        End If
                    End If
                    If vMc(i).Groups("row").Success Then
                        nRows += 1
                    End If
                    If Len(sDelimiter) AndAlso _
                    i < vMc.Length - 1 Then
                        e1 += sDelimiter
                    End If
                    i += 1
                Loop While i < vMc.Length
                If bShowCurPos Then
                    If cfg.outputFormat = outputMsgFormat.HTML Then
                        e1 += "<br />" + vbCrLf
                    Else
                        e1 += vbCrLf
                    End If
                End If
            Else
                Do
                    If i = iCur1 + nRows AndAlso bShowCurPos Then
                        If outFormat = outputMsgFormat.HTML Then
                            e1 += "<span style=""color:red"">" + _
                                vMc(i).ToString + "</span>"
                        ElseIf outFormat = outputMsgFormat.RichTextFormat Then
                            e1 += "\cf2 "
                            e1 += vMc(i).ToString + " \cf1 "
                        Else
                            e1 += "[" + vMc(i).ToString + "]"
                        End If
                    Else
                        e1 += vMc(i).ToString
                    End If
                    If vMc(i).Groups("row").Success Then
                        nRows += 1
                    End If
                    If Len(sDelimiter) AndAlso _
                    i < vMc.Length - 1 Then
                        e1 += sDelimiter
                    End If
                    i += 1
                Loop While i < vMc.Length
                If bShowCurPos Then
                    If cfg.outputFormat = outputMsgFormat.HTML Then
                        e1 += "<br />" + vbCrLf
                    Else
                        e1 += vbCrLf
                    End If
                End If
            End If

        Catch ex As Exception
            Throw New Exception(msg8.num(13) + vbCrLf + e1)
        End Try
        Return e1
    End Function
    Public Function toStringNextMatches(numNext As Int32) As String
        Dim e1 As String = String.Empty
        For i = Me.iCur To Me.iCur + numNext
            If i < vMc.Length Then
                e1 += vMc(i).ToString
                If vMc(i).Groups("row").Success Then
                    numNext += 1
                End If
            Else
                Exit For
            End If
        Next
        Return e1
    End Function
    Public Function toStrAndInsertMsg( _
                    ByVal opA As Expression, ByVal opB As Expression, _
                    ByVal subT2 As currentMatch.exprSubType2, _
                    ByVal bUseClr1 As Boolean) As String
        Static iStart0 As Int32
        Static iEnd0 As Int32
        Static sLn0 As String = ""
        Static iCurOrig As Int32
        Static eb As New StringBuilder(200)
        Static vSumA(), vSumB() As Expression
        Static subT2cpy As currentMatch.exprSubType2
        Static opAcpy, opBcpy As Expression
        Try

            If Not cfg.bDetail Then
                Return Nothing
            End If
            If dcm Is Nothing Then
                Return Nothing
            End If

            Dim msg As String = ""
            Dim bEncerrarA As Boolean = False
            Dim bEncerrarB As Boolean = False
            If bUseClr1 Then
                Dim sOpA As String = ""
                sOpA = opA.ToStringExpr(cfg)
                subT2cpy = subT2
                opAcpy = opA
                opBcpy = opB
                sOpA = Regex.Replace(sOpA, MathGlobal8.sLP, "(")
                sOpA = Regex.Replace(sOpA, MathGlobal8.sRP, ")")
                Dim e1 As String = sOpA
                If sOpA.Chars(0) = "-" Then
                    sOpA = Mid(sOpA, 2)
                End If
                Select Case subT2
                    Case exprSubType2.subs
                    Case exprSubType2.add
                    Case exprSubType2.mult : bEncerrarA = Regex.Match(sOpA, "[-+]").Success
                    Case exprSubType2.mult : bEncerrarA = Regex.Match(sOpA, "[^]").Success
                    Case exprSubType2.div : bEncerrarA = Regex.Match(sOpA, "[-+/]").Success
                    Case exprSubType2.pow : bEncerrarA = Regex.Match(sOpA, "[-+*/]").Success
                        'If opB.IsReal AndAlso bEncerrarA Then
                        '    Dim db As Double = opB.toDouble
                        '    If db = Math.Floor(db) AndAlso db = 2 Then
                        '        opB = New Expression(opA)
                        '        subT2 = exprSubType2.mult
                        '        bEncerrarB = True
                        '    End If
                        'End If
                    Case exprSubType2.modulo : bEncerrarA = Regex.Match(sOpA, "[-+*/^]").Success
                End Select
                sOpA = e1
                If bEncerrarA OrElse _
                (sOpA.Chars(0) = "-" AndAlso _
                subT2 = currentMatch.exprSubType2.pow) Then
                    msg = "(" + sOpA + ")"
                Else
                    msg = sOpA
                End If
            Else
                msg += opA.ToStringExpr(cfg)
            End If
            If bUseClr1 AndAlso opB IsNot Nothing Then
                vSumA = Nothing
                vSumB = Nothing
                Dim sOpB As String = opB.ToStringExpr(cfg)
                sOpB = Regex.Replace(sOpB, MathGlobal8.sLP, "(")
                sOpB = Regex.Replace(sOpB, MathGlobal8.sRP, ")")
                Dim e1 As String = sOpB
                If e1.Chars(0) = "-" Then
                    sOpB = Mid(sOpB, 2)
                End If
                If Not bEncerrarB Then
                    Select Case subT2
                        Case exprSubType2.add : msg += " + "
                        Case exprSubType2.subs
                            msg += " - "
                            bEncerrarB = Regex.Match(sOpB, "[-+]").Success

                        Case exprSubType2.mult : msg += " * "
                            bEncerrarB = Regex.Match(sOpB, "[-+]").Success
                            Dim vMnA() As Boolean = Nothing
                            Dim vMnB() As Boolean = Nothing
                            vSumA = opA.exprToSummands(vMnA)
                            vSumB = opB.exprToSummands(vMnB)

                        Case exprSubType2.div : msg += " / "
                            bEncerrarB = Regex.Match(sOpB, "[-+*]").Success

                        Case exprSubType2.pow : msg += " ^ "
                            bEncerrarB = Regex.Match(sOpB, "[-+*/]").Success

                        Case exprSubType2.modulo : msg += " % "
                            bEncerrarB = Regex.Match(sOpB, "[-+*/^]").Success
                        Case Else
                            msg += " " + subT2.ToString + " "
                    End Select
                End If
                sOpB = e1
                If bEncerrarB Then
                    msg += "(" + sOpB + ")"
                Else
                    msg += sOpB
                End If
                sLn0 = msg
            End If


            Dim eb2 As New StringBuilder(200)
            Dim eb4 As New StringBuilder(100)
            Dim i As Int32 = 0
            Dim tipo As currentMatch.exprType
            Dim lp As Int32 = 0 ' # of "("
            Dim rp As Int32 = 0 ' # of ")"
            If bUseClr1 Then
                iEnd0 = Me.iCur - 1
                'iEnd0 += dcm.incr_iCur(Me.iCur)
                cfg.oDetail.pop_iCur(Me)
                If bEnd Then iEnd0 = dcm.sContentLen - 1
                iCurOrig = cfg.oDetail.read_iCur_prev(tipo)
                iStart0 = iCurOrig
                eb.Remove(0, eb.Length)

                ' count LP and RP:
                Dim iSubsPerIntegrationSign As Int32 = 0
                For i = iStart0 To iEnd0
                    If i < dcm.sContentLen AndAlso _
                    Len(dcm.sContent(i)) = 1 Then
                        If Regex.IsMatch(dcm.sContent(i), MathGlobal8.sLP) Then
                            lp += 1
                        ElseIf Regex.IsMatch(dcm.sContent(i), MathGlobal8.sRP) Then
                            rp += 1
                        ElseIf AscW(Mid(dcm.sContent(i), 1, 1)) = 8747 Then
                            ' is an integration sign:
                            iSubsPerIntegrationSign += 1
                            Dim j As Int32 = i
                            Do While j > 0 AndAlso _
                            Regex.IsMatch( _
                            dcm.sContent(j - 1), MathGlobal8.sOp)
                                j -= 1
                                iSubsPerIntegrationSign += 1
                            Loop
                        End If
                    End If
                Next
                If lp > rp Then
                    i = iEnd0
                    Do While rp <> lp AndAlso _
                    i + 1 < dcm.sContentLen
                        i += 1
                        If Regex.IsMatch(dcm.sContent(i), MathGlobal8.sLP) Then
                            lp += 1
                        ElseIf Regex.IsMatch(dcm.sContent(i), MathGlobal8.sRP) Then
                            rp += 1
                        End If
                    Loop
                    iEnd0 = i
                ElseIf lp < rp Then
                    i = iStart0
                    Do While rp <> lp AndAlso _
                    i > 0
                        i -= 1
                        If Regex.IsMatch(dcm.sContent(i), MathGlobal8.sLP) Then
                            lp += 1
                        ElseIf Regex.IsMatch(dcm.sContent(i), MathGlobal8.sRP) Then
                            rp += 1
                        End If
                    Loop
                    iStart0 = i
                End If
                iStart0 -= iSubsPerIntegrationSign
                For i = 0 To dcm.sContentLen - 1
                    If i = iStart0 Then
                        eb.Append(sClr1 + sLn0 + sEndTag)
                        i = iEnd0
                    Else
                        eb.Append(dcm.sContent(i))
                    End If
                Next
                If eb.Chars(eb.Length - 1) <> "=" Then ' Not Regex.IsMatch(eb.ToString, "(?<!\"")\=")  Then
                    eb.Append(" =")
                Else
                    eb.Append(" =>")
                End If
                Return ""
            Else

                Dim sln As String = Replace(sLn0, " ", "")
                Dim mg As String = Replace(msg, " ", "")
                If sln = mg Then
                    vSumA = Nothing
                    Return ""
                End If

                eb = New StringBuilder(Replace(eb.ToString, "+ -", " -"))
                eb = New StringBuilder(Replace(eb.ToString, "- -", " +"))
                cfg.oDetail.Add(eb.ToString)

                ' detail multiplication if more than
                ' one summands (brown colored):
                If vSumA IsNot Nothing AndAlso _
                    vSumA.Length > 1 AndAlso vSumB.Length > 1 Then

                    ' multiplication detail:

                    Dim eb3 As New StringBuilder(100)
                    eb3.Append("= ")
                    Dim vProd(vSumA.Length * vSumB.Length - 1) As Expression
                    Dim sLnI = ""
                    Dim bFst As Boolean = True
                    Dim vRsum(-1) As Expression, iR As Int32
                    Dim bHasCommFactors As Boolean = False
                    Dim bHasComm(-1) As Boolean
                    Dim vCommon(-1), vExpr1(-1) As Expression
                    Dim vsComm(-1) As String, vsNotC(-1) As String
                    For i = vSumA.Length - 1 To 0 Step -1
                        For j As Int32 = vSumB.Length - 1 To 0 Step -1
                            ReDim Preserve vRsum(iR), vCommon(iR), vsComm(iR), vExpr1(iR), vsNotC(iR)
                            vRsum(iR) = vSumA(i) * vSumB(j)
                            Dim sCur As String = _
                                vRsum(iR).ToStringExpr(cfg)
                            If Not bFst Then
                                If sCur.Chars(0) <> "-" Then
                                    sLnI += "+"
                                End If
                            Else
                                bFst = False
                            End If
                            Dim e2 As String = sCur
                            If e2.Chars(0) = "-" Then
                                e2 = Mid(e2, 2)
                            End If
                            If Regex.IsMatch(e2, "[-+]") Then
                                sLnI += "(" + sCur + ")"
                                vsNotC(iR) = "(" + sCur + ")"
                            Else
                                sLnI += sCur
                                vsNotC(iR) = sCur
                            End If
                        Next
                    Next
                    Dim sLnI2 As String = ""
                    bFst = False
                    If vRsum(iR).getCommonFactor(cfg, vCommon(iR), vExpr1(iR), vsComm(iR)) Then
                        bHasComm(iR) = True
                        bHasCommFactors = True
                    End If
                    iR += 1
                    If bHasCommFactors Then
                        For i = 0 To vsComm.Length - 1
                            Dim sCur As String = ""
                            If bHasComm(i) Then
                                sCur = vsComm(i)
                            Else
                                sCur = vsNotC(i)
                            End If
                            If Not bFst Then
                                If sCur.Chars(0) <> "-" Then
                                    sLnI2 += "+"
                                End If
                            Else
                                bFst = False
                            End If
                            Dim e2 As String = sCur
                            If e2.Chars(0) = "-" Then
                                e2 = Mid(e2, 2)
                            End If
                            If Regex.IsMatch(e2, "[-+]") Then
                                sLnI2 += "(" + sCur + ")"
                                vsNotC(iR) = "(" + sCur + ")"
                            Else
                                sLnI2 += sCur
                                vsNotC(iR) = sCur
                            End If
                        Next
                    End If
                    sLnI = "(" + sLnI + ")"
                    For i = 0 To dcm.sContentLen - 1
                        If i = iStart0 Then
                            eb3.Append(sClr3 + sLnI + sEndTag)
                            i = iEnd0
                        Else
                            eb3.Append(dcm.sContent(i))
                        End If
                    Next
                    cfg.oDetail.Add(eb3.ToString)
                    If sLnI2.Length Then
                        For i = 0 To dcm.sContentLen - 1
                            If i = iStart0 Then
                                eb4.Append(sClr3 + sLnI2 + sEndTag)
                                i = iEnd0
                                'If i AndAlso _
                                'InStr(mcOrig(i).ToString, "&") Then
                                '    i += 1
                                'End If
                            Else
                                eb4.Append(dcm.sContent(i))
                            End If
                        Next
                    End If
                    'cfg.oDetail.Add(eb4.ToString)
                    'If bHasCommFactors Then
                    '    cfg.oDetail.Add(eb4.ToString)
                    'End If
                    'ElseIf subT2cpy = exprSubType2.mult Then
                    '    Dim baseA As Expression = opAcpy
                    '    Dim expA As New Expression(1.0)
                    '    If baseA.getMatch IsNot Nothing AndAlso _
                    '    baseA.getMatch.ToString = "^" Then
                    '        baseA = opAcpy.getArgs(0)
                    '        expA = opAcpy.getArgs(1)
                    '    End If
                    '    Dim baseB As Expression = opBcpy
                    '    Dim expB As New Expression(1.0)
                    '    If baseB.getMatch IsNot Nothing AndAlso _
                    '    baseB.getMatch.ToString = "^" Then
                    '        baseB = opBcpy.getArgs(0)
                    '        expB = opBcpy.getArgs(1)
                    '    End If
                    '    If baseA.isEqualTo(baseB) Then
                    '        eb4.Append("= " + sClr3 + "(" + New Expression(baseA).ToStringExpr(cfg) _
                    '          + ")^(" + New Expression(expA).ToStringExpr(cfg) + "+" + _
                    '          New Expression(expB).ToStringExpr(cfg) + ")" + sEndTag)
                    '        eb4.Append(vbCrLf +  "= " + sClr3 + "(" + New Expression(baseA).ToStringExpr(cfg) _
                    '          + ")^" + New Expression(expA + expB).ToStringExpr(cfg) + sEndTag)
                    '    End If
                End If
            End If
            sLn0 = msg

            ' Finally, detail "red" expression
            ' containing the operation's result:
            eb2 = New StringBuilder(Replace(eb2.ToString, "+ -", " -"))
            eb2 = New StringBuilder(Replace(eb2.ToString, "- -", " +"))
            eb2.Append("= ")
            Dim sLastOp As String = ""
            If iStart0 < 0 Then
                iStart0 = 0
            End If

            For i = 0 To dcm.sContentLen - 1
                If i = iStart0 Then

                    ' Should "(" and ")" be pre/postfix?
                    bEncerrarA = False
                    msg = Regex.Replace(msg, MathGlobal8.sLP, "(")
                    msg = Regex.Replace(msg, MathGlobal8.sRP, ")")
                    Select Case subT2cpy  '  sLastOp
                        Case exprSubType2.subs
                            If Regex.Match(msg, "[-+]").Success Then
                                bEncerrarA = True
                            End If
                        Case exprSubType2.mult
                            If Regex.Match(msg, "[-+/]").Success Then
                                bEncerrarA = True
                            End If
                        Case exprSubType2.div
                            If Regex.Match(msg, "[-+*/]").Success Then
                                bEncerrarA = True
                            End If
                        Case exprSubType2.pow
                            If Regex.Match(msg, "[-+*/]").Success Then
                                bEncerrarA = True
                            End If
                        Case exprSubType2.modulo
                            If Regex.Match(msg, "[-+*/^]").Success Then
                                bEncerrarA = True
                            End If
                    End Select
                    sLastOp = ""

                    ' enclose if bEncerrarA=true andalso
                    ' not already enclosed by parentheses:
                    If i = 0 OrElse iEnd0 + 1 >= dcm.sContentLen Then
                        If bEncerrarA AndAlso _
                        (i > 0 OrElse iEnd0 + 1 < dcm.sContentLen) AndAlso _
                        Regex.IsMatch(eb.ToString, MathGlobal8.sLP) Then
                            ' 2013/08/14 añadida la condición 'regex' en el 'if'
                            msg = "(" + msg + ")"
                        End If
                    ElseIf bEncerrarA AndAlso _
                  ((Not Regex.IsMatch(dcm.sContent(i - 1), MathGlobal8.sLP) AndAlso _
                   Not Regex.IsMatch(dcm.sContent(iEnd0 + 1), MathGlobal8.sRP)) OrElse _
                   (Not Regex.IsMatch(msg.Chars(0), MathGlobal8.sLP) AndAlso _
                   bEncerrarA = True)) AndAlso _
                   (eb2.Length = 0 OrElse Not _
                    Regex.IsMatch(eb2.Chars(eb2.Length - 1), _
                    MathGlobal8.sLP)) Then ' 2013/09/04 added begining at first 'orelse' condition
                        msg = "(" + msg + ")"
                    End If
                    msg = Replace(msg, "+-", "-")
                    msg = Replace(msg, "+ -", "-")
                    msg = Replace(msg, "- -", "+")
                    eb2.Append(sClr2 + msg + sEndTag)
                    iEnd0 = Math.Min(iEnd0, dcm.sContentLen - 1)
                    For j As Int32 = i To iEnd0
                        If j = iCurOrig Then
                            dcm.setsContent(j, msg)
                        Else
                            dcm.setsContent(j, "")
                        End If
                    Next
                    i = iEnd0
                Else
                    eb2.Append(dcm.sContent(i))
                    sLastOp = dcm.sContent(i)
                End If
            Next
            If eb4.Length AndAlso eb4.ToString <> eb2.ToString Then
                eb4 = New StringBuilder(Replace(eb4.ToString, "+ -", " -"))
                eb4 = New StringBuilder(Replace(eb4.ToString, "- -", " +"))
                cfg.oDetail.Add(Replace(eb4.ToString, "+-", "-"))
            End If
            eb2 = New StringBuilder(Replace(eb2.ToString, "+-", "+"))
            eb2 = New StringBuilder(Replace(eb2.ToString, "+ -", "-"))
            eb2 = New StringBuilder(Replace(eb2.ToString, "- -", "+"))
            cfg.oDetail.Add(eb2.ToString)
            cfg.oDetail.AddAlways(vbCrLf)
            Return eb.ToString + vbCrLf + eb2.ToString
        Catch ex As Exception
            Throw ex
        End Try
        Return Nothing
    End Function
    Public ReadOnly Property toStringCurMatch As String
        Get
            Return toStrCurMatch()
        End Get
    End Property
    Public Overrides Function ToString() As String
        Return toStrCurMatch()
    End Function

    Friend Class curMatchErr
        Inherits Exception
        Shared bcurIsAnErr As Boolean = False
        Function err(ex As Exception, _
                     ByRef cur As currentMatch, ByVal msg As String, _
                     Optional curiCur As Int32 = -1) As Exception
            Dim ret As Exception = Nothing
            If bcurIsAnErr Then
                Return Nothing
            End If
            msg = ""
            Try
                bcurIsAnErr = True
                Dim i As Int32
                Dim e1 As String = ""
                Dim iCur As Int32 = cur.iCur
                If curiCur <> -1 Then
                    iCur = curiCur
                End If
                If cur.bEnd Then
                    iCur = cur.vMc.Length - 1
                End If

                Dim cur2 As New currentMatch()
                cur2 = cur.Clone ' MathGlobal8.CloneObject(cur)
                cur2.reStartCurMatch(-1)
                cur2.imc = -1
                Dim e2 As String = String.Empty
                With cur2
                    For i = 0 To cur2.vMc.Length - 1
                        Try
sig:
                            Do
                                .imc += 1
                                If .imc >= .vMc.Length Then
                                    'verifyExhaustingMC()
                                    Exit For
                                End If
                                .m = .vMc(.imc) ' next mcOrig
                            Loop While .m.Length = 0
tratSalida:
                            .str = .m.ToString
                            If Trim(.str) = "" Then
                                'iCur1 += 1
                                GoTo sig ' 2013/08/07, ignore white spaces
                            End If
                            .getTipo(.m, .tipo, .subT1, .subT2)
                            If .bGoToNext AndAlso Not .bEnd Then
                                ' found &rad, &deg, ...
                                .bGoToNext = False
                                GoTo sig
                            End If
                            'cur2.doNext()
                        Catch ex2 As Exception
                            Return Nothing
                        End Try
                        e2 += cur2.str
                        If i <> iCur Then
                            e1 += cur2.str
                        ElseIf .cfg.outputFormat = outputMsgFormat.HTML Then
                            e1 += "<span style=""color:red"">" + cur2.str + "</span>"
                        Else
                            e1 += " [ " + cur2.str + " ] "
                        End If
                    Next
                End With
                Dim pos As Int32
                If Not currentMatch.checkParentheses(cur2.cfg, e2, False, msg, pos) Then
                    ret = New Exception(msg)
                    Exit Try
                End If
                cur.msg = e1

                If ex IsNot Nothing Then
                    msg += vbCrLf + ex.ToString
                End If
                ret = New Exception(msg)
            Catch ex3 As Exception
                Throw ex3
            Finally
                bcurIsAnErr = False
            End Try
            Return ret
        End Function
    End Class
    Public Shared Function checkParentheses(cfg As Config, _
                                            ByVal e0 As String, _
                                            ByVal bThrowErr As Boolean, _
                                            ByRef sErr As String, _
                                            ByRef pos As Int32) As Boolean
        Dim depth As Int32 = 0
        Dim ret As Boolean = False
        Dim i As Int32
        Static re As New Regex("\(\s*\)")
        Try
            Dim e1 As New StringBuilder(e0.Length)
            Dim e10 As String = Regex.Replace(e0, "\[|\{", "(")
            e10 = Regex.Replace(e10, "\]|\}", ")")
            Dim patron As String = "[^\(\)]"
            e10 = Regex.Replace(e10, patron, " ")
            e1.Append(e10)
            Do
                Dim m As MatchCollection = re.Matches(e1.ToString)
                If m.Count = 0 Then Exit Do
                For i = 0 To m.Count - 1
                    e1.Chars(m.Item(i).Index) = " " ' left parenth. "(" -->" "
                    e1.Chars(m.Item(i).Index + m.Item(i).Length - 1) = " " ' ")" --> " "
                Next
            Loop
            Dim e5 As String = e1.ToString()
            pos = InStr(e5, "(")
            Dim pos2 As Int32 = 0
            pos2 = -InStr(e5, ")")
            If pos = 0 OrElse (-pos2 > 0 AndAlso -pos2 < pos) Then
                pos = Math.Abs(pos2)
            End If
            If pos Then
                sErr = ""
                'If pos > 1 Then
                '    sErr = Mid(e0, 1, pos - 1)
                'End If
                'sErr = Mid(e0, pos, 1)
                'If pos < e0.Length Then
                '    sErr += Mid(e0, pos)
                'End If
                'If pos = -pos2 Then pos = pos2
                Dim sL As String = String.Empty
                Dim sR As String = String.Empty
                If pos > 1 Then
                    sL = Mid(e0, 1, pos - 1)
                End If
                If pos + 1 <= Len(e0) Then
                    sR = Mid(e0, pos + 1)
                End If
                If pos2 = 0 Then
                    sErr = String.Format(msg8.num(1), "')'")
                Else
                    sErr = String.Format(msg8.num(1), "'('")
                End If
                If cfg.outputFormat = outputMsgFormat.plainText Then
                    sErr += vbCrLf + sL + "[ " + e0.Chars(pos - 1) + "]" + sR + vbCrLf
                ElseIf cfg.outputFormat = outputMsgFormat.HTML Then
                    sErr += "<br />" + vbCrLf + sL + "<span style='color:red'>" + e0.Chars(pos - 1) + "</span>" + sR + vbCrLf
                ElseIf cfg.outputFormat = outputMsgFormat.RichTextFormat Then
                    sErr += vbCrLf + sL + "[ " + e0.Chars(pos - 1) + "]" + sR + vbCrLf
                End If
                If bThrowErr Then
                    Throw New Exception(sErr)
                End If
            Else
                ret = True ' Parentheses Ok
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
        Return ret
    End Function
    Friend Function vsErr(Optional dimension As Int32 = -1) As String()
        If dimension = 0 Then
            vsErr = New String() {str}
        ElseIf mOld Is Nothing Then
            vsErr = New String() {"", str}
        Else
            vsErr = New String() {mOld.ToString, str}
        End If
    End Function
    Private Function Validate() As Boolean
        If bEnd Then
            If imc = 0 Then Return True
        End If
        'Dim vsErr() As String
        If imc = 0 Then
            Return validateFirstToken(currType, str)
        ElseIf _
        tipo <> exprType.LP AndAlso
        oldTipo = exprType.LP Then
            '(oldT1bis = exprSubType1.mtxOp OrElse _
            'oldT1bis = exprSubType1.mtxFn OrElse _
            'oldT1 = exprSubType1.delimiter OrElse _
            'oldT1 = exprSubType1.mtxOp OrElse _
            'oldT1 = exprSubType1.mtxFn) Then
            If validateFirstToken(currType, str, False) Then
                Return True
            End If
            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
            Return False
        End If
        If bEnd Then
            Return True
        End If
        Try


            '    1           2        3   21       4         5         6         7         8     
            'LP, √, Dx       RP     num, cnt     fn       col       row        =       variable 

            '    9           10        11        12      13 mtxOp    14         15        16     
            '-,+,*,/,%,^,!  modulo  integralRe integral  -,+,*,/,^  and,or,xor  not     binary    

            '   16           16        16         17        17        17        20        25        50
            ' octal       decimal  hexadecimal  radians   degrees   gradians  EOTokens  subtitute  unknown

            If oldType = tknGnralType.Unknown Then
                'ReDim Preserve vsErr(0)
                err = New msg8B(Me, 6, vsErr(0)) ' unknown token
                GoTo notValid
            End If
            Select Case currType
                Case exprType.LP, _
                    exprType.Dx  ' (, √, Dx
                    LP += 1
                    If oldTipo = exprType.custFn Then
                        Return True
                    End If
                    Select Case oldType
                        Case 2, 3, 8, 11, 21 ' ), num, cnt, var, dx
                            ' *  ^
                            ' 42 94
                            sInsChar = "*"
                            'insert_replace_mcOrig("*")
                        Case Else
                            Exit Try
                    End Select
                Case exprType.Dx
                Case tknGnralType.RP  ' )
                    RP += 1
                    If RP > LP Then
                        err = New msg8B(Me, 9) ' missing (
                    End If
                    Select Case oldType
                        Case 2, 3, 6, 8, 11, 21
                            Exit Try
                        Case Else
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                    End Select
                Case 3, 21 ' num, cnt
                    If oldTipo = exprType.custFn Then
                        Return True
                    End If
                    Select Case oldType
                        Case 2 ' old= {")","var"}  cur={num,constant}
                            sInsChar = "^" 'insert_replace_mcOrig("^")
                        Case 3, 21 ' old= {num,constant}  cur={num,const}
                            sInsChar = "*" 'insert_replace_mcOrig("*")
                        Case 8
                            If currType = 21 Then
                                sInsChar = "*"
                            Else
                                sInsChar = "^"
                            End If
                        Case 9
                            If sOld = "!" Then
                                sInsChar = "*" 'insert_replace_mcOrig("*")
                            Else
                                Exit Try
                            End If
                        Case Else
                            Exit Try
                    End Select
                Case 4 ' fn
                    If str = "mod" OrElse str = "%" Then Exit Try
                    Select Case oldType
                        Case 2, 3, 8, 21
                            ' *  ^
                            ' 42 94
                            sInsChar = "*" '  insert_replace_mcOrig("*")
                        Case 4
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                        Case Else
                            Exit Try
                    End Select
                Case 5 ' col
                    Select Case oldType
                        Case 2, 3, 8, 11, 13, 21 : Exit Try
                        Case Else
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                    End Select
                Case 6 ' row
                    Select Case oldType
                        Case 1, 2, 3, 8, 11, 13, 21 : Exit Try
                        Case Else
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                    End Select
                Case 7 ' =
                    Select Case oldType
                        Case 2, 3, 8, 11, 21 : Exit Try
                        Case Else
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                    End Select
                Case 8 ' var
                    If oldTipo = exprType.custFn Then
                        Return True
                    End If
                    Select Case oldType
                        Case 9 ' optor
                            If sOld = "!" Then
                                sInsChar = "*" '   insert_replace_mcOrig("*")
                            End If
                        Case tknGnralType.RP, 21
                            sInsChar = "*" ' insert_replace_mcOrig("*")
                        Case 4
                            ' Commented: allow √x, cos x, ...
                            'err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            'GoTo notValid
                        Case 3, 8
                            ' *  ^
                            ' 42 94
                            sInsChar = "*" ' insert_replace_mcOrig("*")
                        Case 11
                            ' *  ^
                            ' 42 94
                            sInsChar = "*" 'insert_replace_mcOrig("*")
                        Case Else : Exit Try
                    End Select
                Case 9 ' -,+,*,/,^,!
                    Select Case oldType
                        Case 1, 2, 3, 4, 8, 11, 21 : Exit Try
                        Case 5, 6
                            ' tknGnralType.col , tknGnralType.row 
                            Exit Try
                        Case 10
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                        Case 9, 13
                            If str = "-" AndAlso _
                           Regex.IsMatch(sOld, "[+*/^]") Then
                                Exit Try
                            ElseIf sOld <> "!" Then
                                err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                                GoTo notValid
                            End If
                        Case Else
                            If sOld <> "-" AndAlso sOld <> "+" Then
                                err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                                GoTo notValid
                            End If
                            Exit Try
                    End Select
                Case 10 ' mod
                    Select Case oldType
                        Case 2, 3, 8, 11, 21 : Exit Try
                        Case Else
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                    End Select
                Case 11 ' dx
                    Select Case oldType
                        Case 2, 3, 8, 11, 12, 21 : Exit Try
                        Case Else
                            If oldT2 = exprSubType2.integral Then
                                Exit Try
                            End If
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                    End Select
                Case 12 ' ∫ integral
                    Select Case oldType
                        Case 4, 10
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                        Case 2, 8, 11
                            ' *  ^
                            ' 42 94
                            sInsChar = "*" 'insert_replace_mcOrig("*")
                        Case Else : Exit Try
                    End Select
                Case 13 ' matrix operator (-,+,*,/,^)
                    Select Case oldType
                        Case 1, 2, 3, 6, 8, 11, 21 : Exit Try
                        Case 9
                            If sOld <> "!" Then
                                err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                                GoTo notValid
                            End If
                        Case 13
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                        Case Else
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                    End Select
                Case 14 ' tknGnralType.andOrXorNandNor 
                    If str = "not" Then
                        Select Case oldType
                            Case 4
                                err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                                GoTo notValid
                            Case 3, 21, 8
                                sInsChar = "*" 'insert_replace_mcOrig("*")
                                Return True

                            Case Else : Exit Try

                        End Select
                    Else
                        Select Case oldType
                            Case 2, 3, 8, 11 : Exit Try
                            Case Else
                                err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                                GoTo notValid
                        End Select
                    End If

                Case 15 ' NOT
                    Select Case oldType
                        Case 4
                            err = New msg8B(Me, 2, vsErr) ' token sequence is not valid
                            GoTo notValid
                        Case 3, 8, 21
                            ' *  ^
                            ' 42 94
                            sInsChar = "*" 'insert_replace_mcOrig("*")
                            Return True
                        Case Else : Exit Try
                    End Select
                Case 16 ' tknGnralType.numericBase
                    ' no hay error pero retorna False
                    ' para ir a buscar el siguiente
                    ' fragmento (token):
                    imc += 1
                    iCur1 += 1
                    bGoToNext = True
                    Return False
                Case 20 ' EOTokens
                    Select Case oldType
                        Case 2, 3, 6, 8, 11, 13, 21 : Exit Try
                        Case 9, 13
                            If str <> "!" Then
                                'ReDim Preserve vsErr(0)
                                err = New msg8B(Me, 3, vsErr(0)) ' ending token is not valid
                                GoTo notValid
                            Else
                                Exit Try
                            End If
                        Case Else
                            'ReDim Preserve vsErr(0)
                            err = New msg8B(Me, 3, vsErr(0)) ' ending token is not valid
                            GoTo notValid
                    End Select
                Case 50 ' unknown token
                    'ReDim Preserve vsErr(0)
                    err = New msg8B(Me, 6, vsErr(0)) ' unknown token
                    GoTo notValid
            End Select
            If err() Is Nothing Then
                If Len(sInsChar) Then
                    insert_replace_mcOrig(sInsChar)
                    sInsChar = ""
                    bGoToNext = True
                    Return False
                End If
                Return True
            End If
        Catch ex As Exception
            err = ex
        End Try
        'sOld = str
        'oldType = currType
        Return True
notValid:
        'icur = sbExpr.Length
        Return False
    End Function
    Private Function validateFirstToken(curGType As tknGnralType, sCur As String, _
                            Optional bSetErr As Boolean = True) As Boolean
        Try

            '    1           2       3    21     4         5         6         7         8     
            'LP, √, Dx       RP     num, cnt     fn       col       row        =       variable 

            '    9           10        11        12      13 mtxOp    14         15        16     
            '-,+,*,/,%,^,!  modulo  integralRe integral  -,+,*,/,^  and,or,xor  not     binary    

            '   16           16        16         17        17        17        20        25        50
            ' octal       decimal  hexadecimal  radians   degrees   gradians  EOTokens  subtitute  unknown

            Dim vsErr() As String = {sCur}
            If imc + 1 >= vMc.Length Then
                ' Is first and last token
                Select Case curGType
                    Case 3, 4, 8, 16, 21 ' num, fn, cnt, var.
                        Return True
                    Case Else
                        If bSetErr Then
                            err = New msg8B(Me, 4, vsErr) ' err in start token
                        End If
                        Return False
                End Select
            Else
                Select Case curGType
                    Case 1, 3, 4, 8, 12, 15, 17, 21, 25
                        If tipo = exprType.LP Then LP += 1
                        Return True
                    Case 9, 13
                        If sCur = "-" OrElse sCur = "+" Then
                            Return True
                        Else
                            If bSetErr Then
                                err = New msg8B(Me, 4, vsErr) ' err in start token
                            End If
                            Return False
                        End If
                    Case 16 '  tknGnralType.numericBase 
                        ' no hay error pero retorna False
                        ' para ir a buscar el siguiente
                        ' fragmento (token):
                        imc += 1
                        iCur1 += 1
                        bGoToNext = True
                        Return False
                    Case Else
                        If bSetErr Then
                            err = New msg8B(Me, 4, vsErr) ' err in start token
                        End If
                        Return False
                End Select
            End If
        Catch ex As Exception
            err = ex
        End Try
        Return False
    End Function
    Friend Property err As Exception
        Get
            Return err1
        End Get
        Set(value As Exception)
            If err1 Is Nothing AndAlso _
            err1 IsNot value Then
                err1 = New msg8B(Me, value.Message)
                'curOptor = -4
            End If
        End Set
    End Property
    Public Enum exprType
        RP = 0
        LP = 1
        num = 2
        cnt = 3
        custFn = 8
        Dx = 7
        var = 4
        fn = 5
        op = 6
        any = 9
        integralRespVar = 10
        fnExponent = 11
        start = 20
    End Enum
    Public Enum exprSubType1
        oneElemFn = 1
        mtxFn = 2
        var = 3
        var2 = 4
        op = 6
        mtxOp = 7
        delimiter = 8
        equal = 9
        decBase = 10
        hexBase = 11
        octBase = 12
        binBase = 13

        radian = 16
        degree = 17
        gradian = 18
        logicalOp = 20
    End Enum
    Public Enum exprSubType2
        col = 8
        row = 9
        subs = 10
        add = 11
        mult = 12
        div = 13
        pow = 14
        factorial = 15
        modulo = 16
        integralResp = 17
        integral = 18
        mtxsubs = 20
        mtxadd = 21
        mtxmult = 22
        mtxdiv = 23
        mtxpow = 24
        mtxfact = 25 ' ??
        [AND] = 31
        [OR] = 32
        [XOR] = 33
        [NOT] = 34
        [NAND] = 35
        [NOR] = 36
        fundamentalUnitCI = 40
        fundamentalUnitCS = 41
        derivedUnitCI = 42
        derviedUnitCS = 43
    End Enum

    Friend Enum tknGnralType
        '    1           2         3         4         5         6         7         8     
        'LP, √, Dx       RP     num, cnt     fn       col       row        =       variable 

        '    9           10        11        12      13 mtxOp    14        15        16     
        '-,+,*,/,%,^,!  modulo  integralRe integral  -,+,*,/,^  and,or,xor  not     binary    

        '   16           16        16         17        17        17        20        25        50
        ' octal       decimal  hexadecimal  radians   degrees   gradians  EOTokens  subtitute  unknown
        lp = 1
        RP = 2
        num = 3
        fn = 4
        col = 5
        row = 6
        equal = 7
        variable = 8
        optor = 9
        modulo = 10
        integrRespTo = 11
        integral = 12
        mtxOptor = 13
        andOrXorNandNor = 14
        [not] = 15
        numericBase = 16
        angleBase = 17
        EOTokens = 20
        Cnt = 21
        substitute = 25
        Unknown = 50
    End Enum

End Class
