Imports PdfSharp
Imports PdfSharp.Drawing
Imports PdfSharp.Pdf
Imports System.IO



Public Class DiarioPdf
    Dim us As New Globalization.CultureInfo("en-US")
    Dim document As PdfDocument
    Dim pageH, pageW As Single
    Dim fontNameHead As String = "Arial Narrow"
    Dim fontSizeHead As Single = 12.0
    Dim fontNameBody As String = "Arial Narrow"
    Dim fontSizeBody As Single = 11
    Dim curPage As Int32 = 0
    Dim totalPages As Int32 = 0
    Dim curLine As Int32 = 0
    Dim linesPerPage As Int32 = 32
    Dim curRow As Int32 = 0
    Dim curVertPixel As Int32 = 0
    Dim ancho As Single = cmToPixels(19.03)
    Dim alto As Single = cmToPixels(1.85)
    Dim anchoLnInterior As Single = cmToPixels(18.21)
    Dim altoTxt As Single = 15.0
    Dim vMargin As Single = (alto - 2 * altoTxt) / 2
    Dim txtIndent As String = 5
    Dim margin As Single
    Dim margenPie As Single = 60.0#
    Dim oParam As informesParam
    Dim totalHaber As Double = 0.0, totalDebe As Double = 0.0
    Dim totalHaberGnral As Double = 0.0, totalDebeGnral As Double = 0.0
    Dim posTitulos() As Single
    Dim posCampos() As Single
    Dim oMissing As Object = System.Reflection.Missing.Value
    'Dim colImpte As Int32 = 3
    Dim page As PdfPage
    Dim gfx As XGraphics
    Dim pen As XPen
    Dim encabezadosCol() As String = {"Subcta.", _
                                      "Nombre", _
                                      "Dcto.", _
                                      "Contrap.", _
                                      "Factura", _
                                      "Concepto", _
                                      "Debe", _
                                      "Haber"}
    Dim nomCampos() As String = {"subcuenta", _
                                 "titulo", _
                                 "documento", _
                                 "contrapartida", _
                                 "factura", _
                                 "concepto", _
                                 "debe", _
                                 "haber"}
    Dim nomTempFileXLS As String
    Public nomTempFileXLS2 As String
    Dim isLocal As Boolean
    Dim MyMapPath As String
    Dim curAsiento As Int32
    Dim curFecha As String
    Dim Asientoold As Int32 = -1
    Dim fontArialNarrow As XFont
    'Dim fontArialNarrowBold As XFont
    Dim fontCalibriBold As XFont
    Dim pfc As New System.Drawing.Text.PrivateFontCollection
    Dim options As New XPdfFontOptions(PdfFontEncoding.Unicode, PdfFontEmbedding.Default)
    Public origMappath As String

    Public Sub New( _
            ByVal oParam As informesParam, ByVal isLocal As Boolean, _
                Optional ByVal mappath As String = "")
        Try

            'font = New XFont(Me.fontNameBody, _
            '                              Me.fontSizeBody, _
            '                              XFontStyle.Regular, options)
            Me.isLocal = isLocal
            Me.origMappath = mappath
            Me.MyMapPath = mappath
            Me.oParam = oParam
            Me.oParam.sTitulo = "Libro Diario"
            totalPages = 1 + _
                Math.Floor(oParam.dt.Rows.Count / 30)
            nuevo(mappath)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Sub nuevo(ByVal mappath As String)
        Try
            document = New PdfDocument
            document.Info.Title = oParam.sTitulo
            pen = New XPen(XColor.FromArgb(0, 0, 0))
            Dim i As Int32
            If isLocal Then
                Dim pos2 As Int32 = Len(mappath) ' InStrRev(mappath, "\")

                'Dim sFileArialNarrowBold = Mid(mappath, 1, pos2) + "\ARIALNB.ttf"
                'pfc.AddFontFile(sFileArialNarrowBold)
                'fontArialNarrowBold = New XFont(pfc.Families(0), 11.0, XFontStyle.Bold, options)

                Dim fntName As String = Mid(mappath, 1, pos2) + "\ARIALN.TTF"
                pfc.AddFontFile(fntName)
                fontArialNarrow = New XFont(pfc.Families(0), 11.0, XFontStyle.Regular, options)

                Dim sFileCalibriBold = Mid(mappath, 1, pos2) + "\calibrib.ttf"
                pfc.AddFontFile(sFileCalibriBold)
                fontCalibriBold = New XFont(pfc.Families(1), 11.0, XFontStyle.Bold, options)

                nomTempFileXLS = System.IO.Path.GetTempFileName
                nomTempFileXLS2 = Replace(nomTempFileXLS, ".", "2.")
            Else

                Dim pos As Int32 = InStr(mappath, "xrjunque\")
                Dim pos2 As Int32 = Len(mappath) ' InStrRev(mappath, "\")
                If pos = 0 Then
                    pos = InStrRev(mappath, "\")
                Else
                    pos = InStr(pos, mappath, "\")
                End If
                'Dim fntStream As System.IO.Stream = _
                'Me.GetType.Assembly.GetManifestResourceStream( _
                '    "calibri.ttf")
                'Dim b(fntStream.Length - 1) As Byte
                'fntStream.Read(b, 0, b.Length)
                'fntStream.Close()

                'Dim sFileArialNarrowBold = Mid(mappath, 1, pos2) + "\ARIALNB.ttf"
                'sFileArialNarrowBold = Replace(sFileArialNarrowBold , "\\", "\")
                'pfc.AddFontFile(sFileArialNarrowBold)
                'fontArialNarrowBold = New XFont(pfc.Families(0), 11.0, XFontStyle.Bold, options)

                Dim fntName As String = Mid(mappath, 1, pos2) + "\ARIALN.TTF"
                fntName = Replace(fntName, "\\", "\")
                pfc.AddFontFile(fntName)
                fontArialNarrow = New XFont(pfc.Families(0), 11.0, XFontStyle.Regular, options)

                Dim sFileCalibriBold = Mid(mappath, 1, pos2) + "\calibrib.ttf"
                sFileCalibriBold = Replace(sFileCalibriBold, "\\", "\")
                pfc.AddFontFile(sFileCalibriBold)
                fontCalibriBold = New XFont(pfc.Families(1), 11.0, XFontStyle.Bold, options)

                Dim rnd As New Random
                Dim nomTemp As String = Math.Floor(rnd.NextDouble * 10 ^ 6).ToString + ".pdf"
                Dim sDir As String = Mid(mappath, 1, pos) + "database\agentia\temp\"
                Try
                    Dim files() As String = Directory.GetFiles(sDir)
                    For i = 0 To files.Length - 1
                        Try
                            If InStr(files(i), ".mdb") = 0 Then
                                Directory.Delete(files(i))
                            End If
                        Catch ex3 As Exception

                        End Try
                    Next
                Catch ex2 As Exception

                End Try
                Me.MyMapPath = sDir + nomTemp
                nomTempFileXLS = Me.MyMapPath
                nomTempFileXLS2 = Replace(nomTempFileXLS, ".", "2.")
            End If
        Catch ex As Exception
            Throw New Exception(mappath + " " + ex.ToString)
        End Try
    End Sub

    Private Sub Header()
        Try

            ' Create an empty page
            page = document.AddPage


            pageW = page.Width.Point
            pageH = page.Height.Point
            curVertPixel = 0 ' curPage * pg.Height  ' cmToPixels(29.7)
            margin = (pageW - ancho) / 2.0 + cmToPixels(0.3)

            posTitulos = New Single() { _
                0, _
                cmToPixels(1.4), _
                cmToPixels(6.7), _
                cmToPixels(8.2), _
                cmToPixels(9.6), _
                cmToPixels(10.0), _
                cmToPixels(16), _
                cmToPixels(18.3), _
                ancho + cmToPixels(0.5)}
            ReDim posCampos(posTitulos.Length - 1)
            For i As Int32 = 0 To posTitulos.Length - 1
                posTitulos(i) += margin
                If True Then
                    posCampos(i) = posTitulos(i)
                Else
                    posCampos(i) = posTitulos(i) - 40
                End If
            Next


            ' Get an XGraphics object for drawing
            gfx = XGraphics.FromPdfPage(page)

            ' Create a font
            'Dim font As New XFont(pfc.Families(0), 12.0, XFontStyle.Regular, options)
            '                              12, _
            '                              XFontStyle.Bold)

            ' Empresa:
            Dim e1 As String = _
                oParam.sEmp
            Dim xsz1 As XSize = gfx.MeasureString(e1, fontCalibriBold)
            Dim xRct As New XRect(cmToPixels(2.0), _
                                   curVertPixel + margin + vMargin / 2.0 + 5, _
                                   xsz1.Width, xsz1.Height)
            gfx.DrawString(e1, fontCalibriBold, XBrushes.Black, _
                xRct, XStringFormats.Center)

            ' Fecha / p�gina
            e1 = _
            "Fecha: " + String.Format("{0:dd/MM/yyyy}", Now) + _
                        "      P�gina: " + (1 + curPage).ToString + _
                        " / " + totalPages.ToString
            xsz1 = gfx.MeasureString(e1, fontArialNarrow)
            xRct = New XRect( _
                 cmToPixels(13), curVertPixel + 8 + margin + vMargin / 2.0, xsz1.Width, xsz1.Height)
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)


            ' T�tulo:
            e1 = _
            oParam.sTitulo
            xsz1 = gfx.MeasureString(e1, fontArialNarrow)
            xRct = New XRect( _
               cmToPixels(2.0), curVertPixel + 8 + margin + alto / 2.0 + 2, xsz1.Width, xsz1.Height)
            gfx.DrawString(oParam.sTitulo, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            ' Moneda
            e1 = "Moneda: " + oParam.moneda
            xsz1 = gfx.MeasureString(e1, fontArialNarrow)
            xRct = New XRect( _
                 cmToPixels(9), curVertPixel + 8 + margin + alto / 2.0 + 2, xsz1.Width, xsz1.Height)
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)
            ' Desde Fecha, hasta fecha
            e1 = "Desde: " + oParam.desdeFch + _
                                 "  Hasta: " + oParam.hastaFch
            xsz1 = gfx.MeasureString(e1, fontArialNarrow)
            xRct = New XRect( _
                 cmToPixels(13), curVertPixel + 8 + margin + alto / 2.0 + 2, xsz1.Width, xsz1.Height)
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)


            'linea superior:
            Dim pen2 = New XPen(XColor.FromArgb(0, 0, 0), 1)
            Dim xPt() As XPoint = New XPoint() { _
                            New XPoint(margin, curVertPixel + margin), _
                            New XPoint(ancho, curVertPixel + margin)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))
            'linea inferior:
            xPt = New XPoint() {New XPoint(margin, curVertPixel + margin + alto), _
                                New XPoint(ancho, margin + alto)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))
            ' linea izquierda:
            xPt = New XPoint() {New XPoint(margin, curVertPixel + margin), _
                                New XPoint(margin, curVertPixel + margin + alto)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))
            ' l�nea derecha:
            xPt = New XPoint() {New XPoint(ancho, curVertPixel + margin), _
                                New XPoint(ancho, curVertPixel + margin + alto)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))
            ' linea de separaci�n:
            xPt = New XPoint() {New XPoint(margin + (ancho - anchoLnInterior) / 2.0, _
                                curVertPixel + margin + alto / 2.0), _
                                New XPoint(anchoLnInterior, _
                                           curVertPixel + margin + alto / 2.0)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))


        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub LinesHeader()
        Try
            Header()
            curVertPixel += margin + alto + 1
            ' Get an XGraphics object for drawing

            'Dim font As XFont = New XFont(Me.fontNameBody, _
            '                              Me.fontSizeBody, _
            '                              XFontStyle.Regular)

            curVertPixel += 5
            For i As Int32 = 0 To encabezadosCol.Length - 1
                ' encabezado columna "i":
                Dim e1() As String = Split(encabezadosCol(i), vbCrLf)
                Dim posY As Int32 = curVertPixel
                For j As Int32 = 0 To e1.Length - 1
                    If Len(e1(j)) Then
                        Dim xsz As XSize = _
                            gfx.MeasureString(e1(j), fontArialNarrow, XStringFormats.Default)
                        Dim xRct As New XRect(Me.posTitulos(i), _
                                              posY, _
                                               xsz.Width, _
                                               xsz.Height)
                        If (i - 2) * (i - 3) * (i - 4) * (i - 6) * (i - 7) = 0 Then
                            xRct = New XRect( _
                                 Me.posTitulos(i) - xsz.Width, posY, xsz.Width, xsz.Height)
                        End If
                        gfx.DrawString(e1(j), fontArialNarrow, XBrushes.Black, _
                            xRct, XStringFormats.Center)
                    End If
                    posY += altoTxt
                Next
            Next
            ' linea de separaci�n:
            curVertPixel += 12
            Dim xPt() As XPoint = New XPoint() { _
                        New XPoint(margin, _
                                    curVertPixel), _
                        New XPoint(ancho + cmToPixels(0.5), curVertPixel)}
            gfx.DrawLine(pen, xPt(0), xPt(1))
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub Line()
        Try
            curAsiento = _
                Me.oParam.dt.Rows(curRow).Item("asiento")
            'If curLine >= linesPerPage OrElse _
            '((curAsiento <> Asientoold AndAlso Asientoold > -1) AndAlso _
            ' curLine + 2 >= linesPerPage) Then
            '    curPage += 1
            '    curLine = 0
            'End If
            If curLine = 0 Then
                LinesHeader()
                curVertPixel += 5
            End If

            Dim e1 As String = _
                Me.oParam.dt.Rows(curRow).Item("fecha")
            e1 = Mid(e1, 7, 2) + "/" + Mid(e1, 5, 2) + "/" + Mid(e1, 1, 4)
            If curAsiento <> Asientoold Then
                If Asientoold > -1 Then
                    Me.dspTotalAsiento()
                End If
                e1 += "  Asiento n� " + _
                    Me.oParam.dt.Rows(curRow).Item("asiento").ToString
                Dim xPt() As XPoint = New XPoint() { _
                    New XPoint(margin, _
                                curVertPixel), _
                    New XPoint(cmToPixels(4), curVertPixel)}
                Dim xsz As XSize = _
                    gfx.MeasureString(e1, fontArialNarrow, XStringFormats.Default)
                Dim xRct As New XRect( _
                     cmToPixels(7), curVertPixel, xsz.Width, xsz.Height)
                gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                    xRct, XStringFormats.Center)
                curVertPixel += 20
            End If
            curFecha = e1
            'If curAsiento <> asientoOld AndAlso asientoOld > -1 Then
            '    e1 = _
            '        Me.cliParam.dt.Rows(curRow).Item("fecha")
            '    e1 = Mid(e1, 7, 2) + "/" + Mid(e1, 5, 2) + "/" + Mid(e1, 1, 4)
            '    curFecha = e1
            '    e1 = " Fecha: " + curFecha
            '    ' linea de separaci�n:
            '    Dim xPt() As XPoint = New XPoint() { _
            '        New XPoint(margin, _
            '                    curVertPixel), _
            '        New XPoint(cmToPixels(4), curVertPixel)}
            '    gfx.DrawLine(pen, xPt(0), xPt(1))
            '    Dim e2 As String = String.Format( _
            '        us, "{0:#,###,###.00}", _
            '         Math.Round(Me.totalDebe, 2))
            '    Dim e3 As String = String.Format( _
            '        us, "{0:#,###,###.00}", _
            '        Math.Round(Me.totalHaber, 2))
            '    Dim xsz As XSize = _
            '        gfx.MeasureString(e1, font, XStringFormats.Default)
            '    Dim xRct As New XRect( _
            '         cmToPixels(7), curVertPixel, xsz.Width, xsz.Height)
            '    curVertPixel += 20
            '    curLine += 1 ' linea en curso de la p�gina actual
            'End If
            Dim i As Int32
            Dim iv As Int32 = 0


            Dim maxAncho As Single = cmToPixels(3.5)
            For i = 0 To nomCampos.Length - 1
                ' dato columna "i":
                Dim bRightAlign As Boolean = False
                Dim nom As String = nomCampos(i)
                nom = Replace(nom, "d.subcuenta", "subcuenta")
                nom = Replace(nom, "d.", "")
                nom = Replace(nom, "s.", "")
                nom = Replace(LCase(nom), "contrap.", "contrapartida")
                'Dim tipo As Type = Me.cliParam.dt.Rows(curRow).Item( _
                '   nom).GetType

                If (i - 6) * (i - 7) = 0 Then
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, True)
                Else
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, False)
                End If
                If (i - 6) * (i - 7) = 0 Then
                    bRightAlign = True
                ElseIf (i - 2) * (i - 3) * (i - 4) = 0 Then
                    bRightAlign = True
                    If e1 = "0" Then
                        e1 = ""
                    End If
                ElseIf Len(e1) > 25 Then
                    e1 = Mid(e1, 1, 25)
                End If
                Dim xsz As XSize = _
                    gfx.MeasureString(e1, fontArialNarrow, XStringFormats.Default)
                Dim xRct As New XRect(Me.posTitulos(i), curVertPixel, xsz.Width, xsz.Height)
                If bRightAlign Then
                    xRct = New XRect( _
                         Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
                End If
                gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                    xRct, XStringFormats.Center)
            Next
            If oParam.moneda = "�" Then
                Me.totalDebe += Math.Round(Me.oParam.dt.Rows(curRow).Item("debe"), 2)
                Me.totalHaber += Math.Round(Me.oParam.dt.Rows(curRow).Item("haber"), 2)
            Else
                Me.totalDebe += Math.Round(Me.oParam.dt.Rows(curRow).Item("debe"), 0)
                Me.totalHaber += Math.Round(Me.oParam.dt.Rows(curRow).Item("haber"), 0)
            End If
            curVertPixel += 20
            '' linea de separaci�n:
            'Dim xPt() As XPoint = New XPoint() { _
            '    New XPoint((margin + (ancho - anchoLnInterior) / 2.0), _
            '                curVertPixel), _
            '    New XPoint(anchoLnInterior, curVertPixel)}
            'gfx.DrawLine(pen, xPt(0), xPt(1))
            'curVertPixel += 2

            Asientoold = curAsiento
            curLine += 1 ' linea en curso de la p�gina actual

            curRow += 1 ' # de registro en curso
            If curVertPixel + Me.margenPie >= Me.pageH Then
                curPage += 1
                curLine = 0
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Function supressCrLfAndTab(ByVal o As Object, _
                                       ByVal bDecimalesYAcumular As Boolean) As String
        Dim e1 As String = ""
        Try
            If o Is Nothing OrElse o Is DBNull.Value Then
                e1 = ""
            ElseIf IsNumeric(o) Then
                Dim db As Double
                If Not Double.TryParse(o, db) Then
                    e1 = o.ToString
                ElseIf bDecimalesYAcumular Then
                    db = Math.Round(db, 2)
                    'totalHaber += db
                    If oParam.moneda = "�" Then
                        e1 = String.Format(us, "{0:###,##0.00}", db)
                    Else
                        e1 = String.Format(us, "{0:###,##0}", db)
                    End If
                Else
                    e1 = db.ToString
                End If
            Else
                e1 = o.ToString
                If Len(e1) Then
                    e1 = Replace(e1, vbCr, "")
                    e1 = Replace(e1, vbLf, "")
                    e1 = Replace(e1, "@", "")
                    e1 = Replace(e1, vbTab, " ")
                End If
                o = e1
            End If
            If e1 = ".00" Then
                e1 = "0.00"
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Return e1
    End Function
    Private Sub dspTotalAsiento()
        Try
            Dim i As Int32 = 5
            'Dim font As XFont = New XFont(Me.fontNameBody, _
            '                              Me.fontSizeBody, _
            '                              XFontStyle.Regular)
            Dim e1 As String = curFecha + " Total asiento " + Asientoold.ToString + ":"
            ' linea de separaci�n:
            'curVertPixel += 4
            Dim e2, e3 As String
            If oParam.moneda = "�" Then
                e2 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                     Math.Round(Me.totalDebe, 2))
                e3 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalHaber, 2))
            Else
                e2 = String.Format( _
                    us, "{0:#,###,##0}", _
                     Math.Round(Me.totalDebe, 0))
                e3 = String.Format( _
                    us, "{0:#,###,##0}", _
                    Math.Round(Me.totalHaber, 0))
            End If
            Dim xsz As XSize = _
                gfx.MeasureString(e1, fontArialNarrow, XStringFormats.Default)
            Dim xRct As New XRect( _
                 cmToPixels(9), curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)
            i += 1
            xsz = _
                gfx.MeasureString(e2, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e2, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)
            i += 1
            xsz = _
                gfx.MeasureString(e3, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e3, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)
            curVertPixel += 20
            Dim xPt() As XPoint = New XPoint() { _
                New XPoint(margin, _
                            curVertPixel), _
                New XPoint(cmToPixels(15), curVertPixel)}
            gfx.DrawLine(pen, xPt(0), xPt(1))

            Me.totalDebeGnral += Me.totalDebe
            Me.totalHaberGnral += Me.totalHaber
            Me.totalDebe = 0.0
            Me.totalHaber = 0.0
            curVertPixel += 20
            curLine += 2 ' # de l�nea en curso
            If curVertPixel + Me.margenPie >= Me.pageH Then
                curPage += 1
                curLine = 0
                LinesHeader()
                curVertPixel += 5
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub dspTotalDiario()
        Try
            Dim i As Int32 = 5
            'Dim font As XFont = New XFont(Me.fontNameBody, _
            '                              Me.fontSizeBody, _
            '                              XFontStyle.Regular)
            Dim e1 As String = curFecha + " Total diario: "
            ' linea de separaci�n:
            'curVertPixel += 4
            Dim e2, e3 As String
            If oParam.moneda = "�" Then
                e2 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                     Math.Round(Me.totalDebeGnral, 2))
                e3 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalHaberGnral, 2))
            Else
                e2 = String.Format( _
                    us, "{0:#,###,##0}", _
                     Math.Round(Me.totalDebeGnral, 0))
                e3 = String.Format( _
                    us, "{0:#,###,##0}", _
                    Math.Round(Me.totalHaberGnral, 0))
            End If
            Dim xsz As XSize = _
                gfx.MeasureString(e1, fontArialNarrow, XStringFormats.Default)
            Dim xRct As New XRect( _
                 cmToPixels(9), curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)
            i += 1
            xsz = _
                gfx.MeasureString(e2, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e2, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)
            i += 1
            xsz = _
                gfx.MeasureString(e3, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e3, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            Me.totalDebe = 0.0
            Me.totalHaber = 0.0
            curVertPixel += 20
            curLine += 2 ' # de l�nea en curso
            'If curLine >= linesPerPage Then
            '    Me.gfx.Dispose()
            '    curPage += 1
            '    curLine = 0
            'End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    'Public ReadOnly Property path()
    '    Get
    '        If isLocal Then
    '            Return _
    '             "E:\new\Agentia Junfor\ContaJunfor\ContaJunfor2\ContaJunforWebService\InformesAgentia\"
    '        End If
    '        Return MyMapPath
    '    End Get
    'End Property
    Public Sub save(ByVal nom As String)
        Me.document.Save(nom)
    End Sub
    Public Function Show() As PdfDocument
        Try
            Show2()
            Me.totalPages = Me.curPage + 1
            document.Close()
            'nuevo(origMappath)
            document = New PdfDocument
            document.Info.Title = oParam.sTitulo
        Catch ex As Exception

        End Try
        Return Show2()
    End Function
    Public Function Show2() As PdfDocument
        Try
            Me.totalPages = Me.curPage + 1
            Me.curPage = -1
            Me.Asientoold = -1
            Me.curRow = 0
            Me.curLine = 0
            Me.curVertPixel = 0.0#
            totalHaber = 0.0
            totalDebe = 0.0
            totalHaberGnral = 0.0
            totalDebeGnral = 0.0
            Do While curRow < oParam.dt.Rows.Count
                Line()
            Loop
            dspTotalAsiento()
            If curVertPixel + Me.margenPie >= Me.pageH Then
                curPage += 1
                curLine = 0
                LinesHeader()
                curVertPixel += 5
            End If
            dspTotalDiario()
            '' Save the document...
            'Dim e2 As String = ""
            'If IsNetworkDeployed Then
            '    e2 = System.Deployment.Application.ApplicationDeployment.CurrentDeployment.DataDirectory
            'Else
            '    e2 = System.IO.Directory.GetCurrentDirectory
            'End If
            'e2 += "\temp.pdf"
            'document.Save(e2)
            '' ...and start a viewer.
            'Dim proc As New Process
            'proc.StartInfo.FileName = e2
            'proc.StartInfo.UseShellExecute = True
            'proc.Start()
        Catch ex As Exception
            Throw ex
        End Try
        Return document
    End Function
    Private Function cmToPixels(ByVal cm As Single) As Single
        Return cm * 29.14
    End Function

End Class
