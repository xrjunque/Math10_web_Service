﻿Public Partial Class menuInformesAgentia
    Inherits System.Web.UI.UserControl

    'Dim usuario
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            populateMenu()
        End If
    End Sub

    Sub populateMenu()
        Try
            Dim i, j As Int32
            Dim sMn() As String = { _
                "Informes;Diario;Mayor;Proveedores de+de;Clientes de+de;" + _
                "Prov(trimestral) de+de;Clientes(trimestral) de+de;" + _
                "Facturas recibidas;Facturas emitidas;IVA trim. (Mod.303)", _
                "Balances;Sumas y Saldos;Situación;Pérdidas y Ganancias" _
                }
            With Menu1
                .MaximumDynamicDisplayLevels = 1
                .Items.Clear()
                .ItemWrap = True
                With .StaticMenuItemStyle
                    .BorderWidth = New Unit(1)
                    .BorderColor = Drawing.Color.Navy
                    .BorderStyle = BorderStyle.Solid
                    .BackColor = Drawing.Color.LightBlue
                    .HorizontalPadding = New Unit(2)
                    .ItemSpacing = New Unit(2)
                    .Font.Name = "Arial Narrow"
                    .Font.Size = New FontUnit(FontSize.Large)
                End With
                With .StaticHoverStyle
                    .BackColor = Drawing.Color.LightSteelBlue
                    .Font.Name = "Arial Narrow"
                    .Font.Size = New FontUnit(FontSize.Large)
                End With
                With .StaticSelectedStyle
                    .BackColor = Drawing.Color.WhiteSmoke
                    .Font.Name = "Arial Narrow"
                    .Font.Size = New FontUnit(FontSize.Large)
                End With
                With .DynamicMenuItemStyle
                    .BorderWidth = New Unit(1)
                    .BorderColor = Drawing.Color.Navy
                    .BorderStyle = BorderStyle.Solid
                    .BackColor = Drawing.Color.LightBlue
                    .HorizontalPadding = New Unit(2)
                    .ItemSpacing = New Unit(2)
                    .Font.Name = "Arial Narrow"
                    .Font.Size = New FontUnit(FontSize.Large)
                End With
                With .DynamicHoverStyle
                    .BackColor = Drawing.Color.LightSteelBlue
                    .Font.Name = "Arial Narrow"
                    .Font.Size = New FontUnit(FontSize.Large)
                End With
                With .DynamicSelectedStyle
                    .BackColor = Drawing.Color.WhiteSmoke
                    .Font.Name = "Arial Narrow"
                    .Font.Size = New FontUnit(FontSize.Large)
                End With
                For i = 0 To sMn.Length - 1
                    Dim e1 As String = ""
                    Dim e2() As String = Split(LCase(sMn(i)), ";")
                    Dim mi As New MenuItem(e2(0))
                    For j = 1 To e2.Length - 1
                        Dim subMi As New MenuItem(e2(j))
                        mi.ChildItems.Add(subMi)
                        e1 = Split(Request.Url.AbsoluteUri, "?")(0)
                        e1 += "?informe=" + HttpUtility.UrlEncode(Trim(e2(j)))
                        subMi.NavigateUrl = e1
                    Next
                    .Items.Add(mi)
                Next
            End With
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Sub
End Class