﻿Imports Microsoft.Office.Interop
Imports System.IO


Public Class FrasRecibidasXls
    Dim us As New Globalization.CultureInfo("en-US")
    Dim fontNameHead As String = "Arial Narrow"
    Dim fontSizeHead As Single = 11.0
    Dim fontNameBody As String = "Arial Narrow"
    Dim fontSizeBody As Single = 11
    Dim curPage As Int32 = 0
    Dim totalPages As Int32 = 0
    Dim curLine As Int32 = 0
    Dim linesPerPage As Int32 = 6
    Dim curRow As Int32 = 0
    Dim curExcelRow As Int32 = 0
    Dim ancho As Single = cmToPixels(19.03)
    Dim alto As Single = cmToPixels(1.85)
    Dim anchoLnInterior As Single = cmToPixels(18.21)
    Dim altoTxt As Single = 20.0
    Dim vMargin As Single = (alto - 2 * altoTxt) / 2
    Dim txtIndent As String = 5
    Dim margin As Single
    Dim oParam As informesParam
    Dim vBases(5), vCuotas(5) As Double, iIvas, vTipos(5) As Int32
    Dim totalBase As Double = 0.0
    Dim totalCuota As Double = 0.0
    Dim totalImporte As Double = 0.0
    Dim totalBaseGnral As Double = 0.0
    Dim totalCuotaGnral As Double = 0.0
    Dim totalImporteGnral As Double = 0.0
    Dim posTitulos() As Single
    Dim posCampos() As Single
    Dim oMissing As Object = System.Reflection.Missing.Value
    Dim colImpte As Int32 = 3
    Dim LineaEncabezados1() As String = {"Concepto", _
                                         "Fecha", _
                                         "Subcta.", _
                                         "Fra.", _
                                         "Base IVA", _
                                         "%", _
                                         "Cuota", _
                                         "Total fra." _
                                         }
    Dim LineaEncabezados2() As String = {"Título", _
                                      "Asiento", _
                                       "Dcto.", _
                                       "Contrap." _
                                       }
    Dim LineaCampos1() As String = {"concepto", _
                                    "fecha", _
                                    "subcuenta", _
                                    "factura", _
                                    "baseiva", _
                                    "tipoiva", _
                                    "cuota", _
                                    "total"}
    Dim LineaCampos2() As String = { _
                                    "titulo", _
                                    "asiento", _
                                    "documento", _
                                    "contrapartida" _
                                    }
    Dim tipoEsString1() As Boolean = {True, _
                                     True, _
                                     True, _
                                     True, _
                                     True, _
                                     True, _
                                     False, _
                                     False, _
                                     False, _
                                     False}
    Dim tipoEsString2() As Boolean = { _
                                    True, _
                                    True, _
                                    True, _
                                    True _
                                      }
    Dim nomFileInput As String = "xmlInformes.txt"
    Dim nomFileInput2 As String = "xmlInformes2.txt"
    Dim inFs As FileStream
    Dim inSr As StreamReader
    Dim isLocal As Boolean
    Dim MyMappath As String = ""
    Public sOut2 As String
    Dim posInExcelOfRowCount As Int32
    Dim oldAsiento As Int32 = -1
    Dim nomTempFileXLS As String
    Public nomTempFileXLS2 As String
    Dim fsXLS As FileStream
    Dim wrXLS As StreamWriter

    Public Sub New( _
            ByVal oParam As informesParam, ByVal isLocal As Boolean, _
                Optional ByVal mappath As String = "")
        Try
            Me.isLocal = isLocal
            Me.oParam = oParam
            Dim inNomFile As String = ""
            Dim i As Int32
            If isLocal Then
                inNomFile = _
                 "E:\new\Agentia Junfor\ContaJunfor\ContaJunfor2\ContaJunforWebService\InformesAgentia\" + _
                 nomFileInput
                nomTempFileXLS = IO.Path.GetTempFileName
                fsXLS = New FileStream(nomTempFileXLS, FileMode.OpenOrCreate, FileAccess.ReadWrite)
                wrXLS = New StreamWriter(fsXLS)
            Else
                Dim pos As Int32 = InStr(mappath, "xrjunque\")
                pos = InStr(pos, mappath, "\")
                Me.MyMappath = Mid(mappath, 1, pos) + "database\agentia\" ' "C:\sites\premium2\xrjunque\database\agentia\"
                Dim rnd As New Random
                inNomFile = Me.MyMappath + nomFileInput
                inNomFile = Replace(inNomFile, "\\", "\")
                nomTempFileXLS = Me.MyMappath
                nomTempFileXLS = Replace(nomTempFileXLS, "\\", "\")
                nomTempFileXLS += (Math.Floor(rnd.NextDouble * 10 ^ 6)).ToString + ".xml"
                fsXLS = New FileStream(nomTempFileXLS, FileMode.OpenOrCreate, FileAccess.Write)
                wrXLS = New StreamWriter(fsXLS)
            End If
            inFs = New FileStream(inNomFile, FileMode.Open, FileAccess.Read)
            inSr = New StreamReader(inFs)
            Dim e1 As String = inSr.ReadToEnd
            inSr.Close()
            inFs.Close()
            e1 = Replace(e1, vbCrLf, vbLf)
            e1 = Replace(e1, vbLf, vbCrLf)
            Dim e2() As String = Split(e1, vbLf)
            For i = 0 To e2.Length - 1
                sOut(i, e2(i))
            Next
            curExcelRow = e2.Length - 1
            AddLine()
            sOut(curExcelRow, " <Worksheet ss:Name=""" + oParam.sTitulo + """>")
            AddLine()
            Dim colsWidth() As Int32 = {125, 50, 50, 50, 42, 17, 47, 50}
            sOut(curExcelRow, "  <Table ss:ExpandedColumnCount=""" + _
                colsWidth.Length.ToString + """ ss:ExpandedRowCount=""" + _
                "@rowscount@" + """ x:FullColumns=""1""")
            posInExcelOfRowCount = curExcelRow
            sOut(curExcelRow, " x:FullRows=""1"" ss:DefaultColumnWidth=""60"" ss:DefaultRowHeight=""15"">")
            For i = 0 To colsWidth.Length - 1
                AddLine()
                sOut(curExcelRow, Replace( _
                    "   <Column ss:Width=""42""/>", _
                    "42", _
                    colsWidth(i).ToString))
            Next
            AddLine()
            sOut(curExcelRow, "   <Row>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:Index=""1""><Data ss:Type=""String"">")
            sOut(curExcelRow, oParam.sEmp + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">Fecha:</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62"">")
            sOut(curExcelRow, "    <Data ss:Type=""DateTime"">" + _
            String.Format("{0:yyyy-MM-dd}T00:00:00.000", Now) + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "   </Row>")
            AddLine()
            sOut(curExcelRow, "   <Row>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:Index=""1""><Data ss:Type=""String"">" + _
                 oParam.sTitulo + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "   </Row>")
            AddLine()
            sOut(curExcelRow, "   <Row>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:Index=""1""><Data ss:Type=""String"">Moneda: " _
                 + oParam.moneda + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "   </Row>")

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub sOut(ByVal i As Int32, ByVal txt As String)
        'If i >= sOut2.Length Then
        'ReDim Preserve sOut2(i)
        'End If
        'If sOut2(i) Is Nothing Then
        'sOut2(i) = New StringBuilder(txt)
        'Else
        sOut2 += txt
        'End If
    End Sub
    Private Sub AddLine()
        If InStr(sOut2, vbCrLf) = 0 Then
            sOut2 += vbCrLf
        End If
        wrXLS.Write(sOut2)
        sOut2 = ""
        curExcelRow += 1
        'ReDim Preserve sOut(curExcelRow)
    End Sub
    Sub AddBlankCell()
        AddLine()
        sOut(curExcelRow, "    <Cell><Data ss:Type=""String"">" + _
                        " </Data></Cell>")
    End Sub
    Private Sub Header()
        Try

            AddLine()
            sOut(curExcelRow, "   <Row>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">Desde:</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62"">")
            sOut(curExcelRow, "    <Data ss:Type=""String"">" + _
                 oParam.desdeFch + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">Hasta:</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62"">")
            sOut(curExcelRow, "    <Data ss:Type=""String"">" + _
                 oParam.hastaFch + "</Data></Cell>")
            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">Moneda:</Data></Cell>")
            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">€</Data></Cell>")
            'AddLine()
            sOut(curExcelRow, "   </Row>")
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub LineaDoColumnsHeader()
        Try
            Dim e1 As String = ""

            AddLine()
            sOut(curExcelRow, "   <Row>")

            For i = 0 To Me.LineaEncabezados1.Length - 1
                AddLine()
                sOut(curExcelRow, "    <Cell ss:StyleID=""s64"">" + _
                        "<Data ss:Type=""String"">" + _
                        Me.LineaEncabezados1(i) + "</Data></Cell>")
            Next
            AddLine()
            sOut(curExcelRow, "   </Row>")

            AddLine()
            sOut(curExcelRow, "   <Row>")

            For i = 0 To Me.LineaEncabezados2.Length - 1
                AddLine()
                sOut(curExcelRow, "    <Cell ss:StyleID=""s64"">" + _
                        "<Data ss:Type=""String"">" + _
                        Me.LineaEncabezados2(i) + "</Data></Cell>")
            Next
            AddLine()
            sOut(curExcelRow, "   </Row>")

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub LineNext()
        Try
            Dim nextAsiento As Int32 = _
                Me.oParam.dt.Rows(curRow).Item("asiento")

            If nextAsiento <> oldAsiento AndAlso oldAsiento > 0 Then
                Me.totalParcial()
            End If

            Dim col As Int32
            Dim iv As Int32 = 0
            Dim campos1aLinea() As String = LineaCampos1 ' {"Fecha", "Asiento", "@sumaDebe", "@sumaHaber"}

            AddLine()
            sOut(curExcelRow, "   <Row>")

            Dim e1 As String = ""

            Dim baseIVA As Double
            Dim cuota As Double
            Dim totalFra As Double
            For col = 0 To LineaCampos1.Length - 1
                ' dato columna "i":
                Dim nom As String = LCase(LineaCampos1(col))

                'If Array.IndexOf(noCeros, LCase(nom)) > -1 AndAlso e1 = "0" Then
                'e1 = ""
                'If LCase(nom) = "fecha" Then
                '    e1 = Mid(e1, 7, 2) + "/" + Mid(e1, 5, 2) + "/" + Mid(e1, 1, 4)
                'ElseIf (col - 2) * (col - 3) * (col - 4) = 0 AndAlso e1 = "0" Then
                '    e1 = ""
                'End If
                AddLine()
                If nom = "cuota" Then
                    baseIVA = Me.oParam.dt.Rows(curRow).Item("baseIva")
                    baseIVA = Math.Round(baseIVA, 2)
                    If Me.oParam.moneda <> "€" Then
                        baseIVA = Math.Round(baseIVA, 0)
                    End If
                    'cuota = Me.oParam.dt.Rows(curRow).Item("tipoIva") * baseIVA / 100.0
                    'cuota = Math.Floor(cuota * 100) / 100
                    'cuota = Math.Round(cuota, 2)
                    cuota = Me.oParam.dt.Rows(curRow).Item("debe")
                    totalFra = baseIVA + cuota
                    'totalFra = Me.oParam.dt.Rows(curRow).Item("debe") ' baseIVA + cuota
                    If Me.oParam.moneda <> "€" Then
                        cuota = Math.Round(cuota, 0)
                        totalFra = Math.Round(totalFra, 0)
                    End If

                    Dim tipo As Int32 = Me.oParam.dt.Rows(curRow).Item("tipoIva")
                    Dim pos1 As Int32 = Array.IndexOf(vTipos, tipo, 0, iIvas)
                    If pos1 = -1 Then
                        ReDim Preserve vTipos(iIvas), vBases(iIvas), vCuotas(iIvas)
                        vTipos(iIvas) = tipo
                        pos1 = iIvas
                        iIvas += 1
                    End If
                    vBases(pos1) += baseIVA
                    vCuotas(pos1) += cuota

                    e1 = Me.supressCrLfAndTab(cuota, True)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + e1 + "</Data></Cell>")
                ElseIf nom = "total" Then
                    e1 = Me.supressCrLfAndTab(totalFra, True)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + e1 + "</Data></Cell>")
                ElseIf nom = "baseiva" OrElse tipoEsString1(col) = False Then
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, True)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + e1 + "</Data></Cell>")
                Else
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, False)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""String"">" + e1 + "</Data></Cell>")
                End If
            Next
            AddLine()
            sOut(curExcelRow, "   </Row>")


            AddLine()
            sOut(curExcelRow, "   <Row>")

            For col = 0 To LineaCampos2.Length - 1
                ' dato columna "i":
                Dim nom As String = LineaCampos2(col)

                'If Array.IndexOf(noCeros, LCase(nom)) > -1 AndAlso e1 = "0" Then
                'e1 = ""
                'If LCase(nom) = "fecha" Then
                '    e1 = Mid(e1, 7, 2) + "/" + Mid(e1, 5, 2) + "/" + Mid(e1, 1, 4)
                'ElseIf (col - 2) * (col - 3) * (col - 4) = 0 AndAlso e1 = "0" Then
                '    e1 = ""
                'End If
                AddLine()
                If tipoEsString2(col) = False Then
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, True)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + e1 + "</Data></Cell>")
                Else
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, False)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""String"">" + e1 + "</Data></Cell>")
                End If
            Next
            AddLine()
            sOut(curExcelRow, "   </Row>")

            Me.oldAsiento = nextAsiento

            Me.totalBase += baseIVA
            Me.totalCuota += cuota
            Me.totalImporte += Math.Round(totalFra, 2)

            curRow += 1
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub totalParcial()
        Try
            'Dim colDebe As Int32 = Array.IndexOf(Me.LineaCampos1, "d.Debe")
            'Dim iv As Int32 = 0

            'AddLine()
            'sOut(curExcelRow, "   <Row>")

            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:Index=""" + (colDebe).ToString _
            '        + """><Data ss:Type=""String"">" + _
            '            "Total asiento:</Data></Cell>")

            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
            '           Me.supressCrLfAndTab(totalBaseGnral, True) + "</Data></Cell>")
            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
            '           Me.supressCrLfAndTab(totalCuotaGnral, True) + "</Data></Cell>")

            'AddLine()
            'sOut(curExcelRow, "   </Row>")

            'AddBlankRow()

            Me.totalBaseGnral += totalBase
            Me.totalCuotaGnral += totalCuota
            Me.totalImporteGnral += totalImporte

            totalBase = 0.0
            totalCuota = 0.0
            totalImporte = 0.0
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub totalGnral()
        Try
            Dim colDebe As Int32 = Array.IndexOf(Me.LineaCampos1, "baseiva")
            Dim iv As Int32 = 0

            AddLine()
            sOut(curExcelRow, "   <Row>")

            AddLine()
            sOut(curExcelRow, "    <Cell  ss:Index=""" + (colDebe).ToString _
                    + """><Data ss:Type=""String""></Data></Cell>")

            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(totalBaseGnral, True) + "</Data></Cell>")

            AddBlankCell()

            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(totalCuotaGnral, True) + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(totalImporteGnral, True) + "</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "   </Row>")

            AddBlankRow()

            ' DESGLOSE DE IVAS SEGÚN TIPOS (DEL 4%, 10%, ETC.):

            ReDim Preserve vTipos(iIvas), vBases(iIvas), vCuotas(iIvas)
            Dim i As Int32
            For i = 0 To iIvas - 1
                AddLine()
                sOut(curExcelRow, "   <Row>")

                AddLine()
                sOut(curExcelRow, "    <Cell  ss:Index=""" + (colDebe).ToString _
                        + """><Data ss:Type=""String""></Data></Cell>")

                AddLine()
                sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + _
                           Me.supressCrLfAndTab(vBases(i), True) + "</Data></Cell>")
                vBases(iIvas) += vBases(i)

                AddLine()
                sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
                           Me.supressCrLfAndTab(vTipos(i), True) + "</Data></Cell>")

                AddLine()
                sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + _
                           Me.supressCrLfAndTab(vCuotas(i), True) + "</Data></Cell>")
                vCuotas(iIvas) += vCuotas(i)

                AddLine()
                sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + _
                           Me.supressCrLfAndTab(vBases(i) + vCuotas(i), True) + "</Data></Cell>")

                AddLine()
                sOut(curExcelRow, "   </Row>")
                AddLine()

            Next

            AddLine()
            sOut(curExcelRow, "   <Row>")

            AddLine()
            sOut(curExcelRow, "    <Cell  ss:Index=""" + (colDebe).ToString _
                    + """><Data ss:Type=""String""></Data></Cell>")

            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(vBases(iIvas), True) + "</Data></Cell>")
            AddLine()


            AddBlankCell()

            sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(vCuotas(iIvas), True) + "</Data></Cell>")
            AddLine()

            sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(vBases(iIvas) + vCuotas(iIvas), True) + "</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "   </Row>")
            AddLine()

            AddBlankRow()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Function supressCrLfAndTab(ByVal o As Object, _
                                       ByVal bDecimales As Boolean) As String
        Dim e1 As String = ""
        Try
            If o Is Nothing OrElse o Is DBNull.Value Then
                e1 = ""
            ElseIf IsNumeric(o) Then
                Dim db As Double
                If Not Double.TryParse(o, db) Then
                    e1 = o.ToString
                ElseIf bDecimales Then
                    db = Math.Round(db, 2)
                    e1 = db.ToString(us)
                Else
                    e1 = db.ToString(us)
                End If
            Else
                e1 = o.ToString
                If Len(e1) Then
                    e1 = Replace(e1, vbCr, "")
                    e1 = Replace(e1, vbLf, "")
                    e1 = Replace(e1, "@", "")
                    e1 = Replace(e1, vbTab, " ")
                End If
                o = e1
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Return e1
    End Function
    Sub AddBlankRow()
        AddLine()
        sOut(curExcelRow, "   <Row>")
        AddLine()
        sOut(curExcelRow, "    <Cell ss:Index=""1""><Data ss:Type=""String"">" + _
                        " </Data></Cell>")
        AddLine()
        sOut(curExcelRow, "   </Row>")
    End Sub

    Public Sub Show()
        Try
            Header()
            LineaDoColumnsHeader()
            Dim nRows As Int32 = oParam.dt.Rows.Count
            Do While curRow < nRows
                LineNext()
            Loop
            totalParcial()
            totalGnral()
            'Me.wrXLS.Close()
            'fsXLS.Close()
            'fsXLS=New FileStream(Me.nomTempFileXLS ,FileMode.Open ,FileAccess.ReadWrite 
            'Dim filasExcel As Int32 = 0
            'For i As Int32 = 0 To sOut2.Length - 1
            '    If InStr(LCase(sOut2(i).ToString), "<row") Then
            '        filasExcel += 1
            '    End If
            'Next
            'sOut2(Me.posInExcelOfRowCount).Replace( _
            '            "rowsCount", _
            '            filasExcel)
            '4 + cliParam.dt.Rows.Count + _
            '0 + 1)
            AddLine()
            sOut(curExcelRow, "  </Table>")
            Dim bFin As Boolean = True
            AddLine()
            sOut(curExcelRow, " </Worksheet>")
            AddLine()
            sOut(curExcelRow, "</Workbook>")
            AddLine()
            wrXLS.Close()
            fsXLS.Close()
            System.Threading.Thread.Sleep(200)
            inFs = New FileStream(Me.nomTempFileXLS, FileMode.Open, FileAccess.Read)
            inSr = New StreamReader(inFs)
            Dim rnd As New Random
            nomTempFileXLS2 = Replace(nomTempFileXLS, ".", "2.")
            fsXLS = New FileStream(Me.nomTempFileXLS2, FileMode.OpenOrCreate, FileAccess.ReadWrite)
            Me.wrXLS = New StreamWriter(fsXLS)
            Dim e1 As String = ""
            nRows = 0
            Dim maxNCols As Int32 = 0
            Dim curNCols As Int32 = 0
            Do While Not inSr.EndOfStream
                e1 = inSr.ReadLine
                If InStr(e1, "<Row") Then
                    If curNCols > maxNCols Then
                        maxNCols = curNCols
                    End If
                    curNCols = 0
                    nRows += 1
                End If
                If InStr(e1, "<Cell") Then
                    curNCols += 1
                End If
            Loop
            inSr.Close()
            inFs.Close()
            inFs = New FileStream(Me.nomTempFileXLS, FileMode.Open, FileAccess.Read)
            inSr = New StreamReader(inFs)
            fsXLS.Seek(0, SeekOrigin.Begin)
            Do While Not inSr.EndOfStream
                e1 = inSr.ReadLine
                If InStr(e1, "@colscount@") Then
                    e1 = Replace(e1, "@colscount@", maxNCols.ToString)
                End If
                If InStr(e1, "@rowscount@") Then
                    e1 = Replace(e1, "@rowscount@", nRows.ToString)
                    wrXLS.WriteLine(e1)
                    Exit Do
                End If
                wrXLS.WriteLine(e1)
            Loop
            Do While Not inSr.EndOfStream
                e1 = inSr.ReadLine
                wrXLS.WriteLine(e1)
            Loop
            wrXLS.Close()
            fsXLS.Close()
            inSr.Close()
            inFs.Close()
            inSr.Close()
            inFs.Close()
            Try
                IO.File.Delete(nomTempFileXLS)
            Catch ex As Exception

            End Try
        Catch ex As Exception
            Throw ex
        Finally
            Me.wrXLS.Close()
            fsXLS.Close()
        End Try
    End Sub
    Private Function cmToPixels(ByVal cm As Single) As Single
        Return cm * 29.14
    End Function

End Class

