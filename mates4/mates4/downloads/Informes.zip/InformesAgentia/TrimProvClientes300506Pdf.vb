Imports PdfSharp
Imports PdfSharp.Drawing
Imports PdfSharp.Pdf
Imports System.IO
Imports System.Windows
Imports System.ComponentModel



Public Class TrimProvClientes300506Pdf
    Dim us As New Globalization.CultureInfo("en-US")
    Dim document As PdfDocument
    Dim pageH, pageW As Single
    Dim sfontCalibriBold As String = "Calibri"
    Dim fontNameHead As String = "Arial"
    Dim fontSizeHead As Single = 11.0
    Dim fontNameBody As String = "Arial Narrow"
    Dim fontSizeBody As Single = 11
    Dim curPage As Int32 = 0
    Dim totalPages As Int32 = 0
    Dim curLine As Int32 = 0
    'Dim linesPerPage As Int32 = 31
    Dim curRow As Int32 = 0
    Dim curVertPixel As Int32 = 0
    Dim ancho As Single = cmToPixels(19.03)
    Dim alto As Single = cmToPixels(1.85)
    Dim anchoLnInterior As Single = cmToPixels(18.21)
    Dim altoTxt As Single = 15.0
    Dim vMargin As Single = (alto - 2 * altoTxt) / 2
    Dim txtIndent As String = 5
    Dim margin As Single
    Dim margenPie As Single = 60.0#
    Dim oParam As informesParam
    Dim totalHaber As Double = 0.0
    Dim totalDebe As Double = 0.0
    Dim totalHtrim As Double = 0.0
    Dim totalDtrim As Double = 0.0
    Dim trimEnCurso As Int32 = 0
    Dim trimOld As Int32 = 0
    Dim totalSaldo As Double = 0.0
    Dim totalHaberGnral As Double = 0.0
    Dim totalDebeGnral As Double = 0.0
    Dim posCampos() As Single
    Dim oMissing As Object = System.Reflection.Missing.Value
    'Dim colImpte As Int32 = 3
    Dim page As PdfPage
    Dim gfx As XGraphics
    Dim pen As XPen
    Dim LineaEncabezados() As String = {"Fecha", _
                                      "Asiento", _
                                       "Dcto.", _
                                       "Contrap.", _
                                       "Factura", _
                                       "Concepto", _
                                       "Debe", _
                                       "Haber", _
                                       "Saldo"}
    Dim LineaCampos() As String = {"fecha", _
                                      "asiento", _
                                       "documento", _
                                       "contrapartida", _
                                       "factura", _
                                       "concepto", _
                                       "debe", _
                                       "haber"}
    Dim inc1 As Single = Me.cmToPixels(0.3)
    Dim inc2 As Single = Me.cmToPixels(0.5) + inc1
    Dim inc3 As Single = Me.cmToPixels(0.2)
    Dim dec1 As Single = -Me.cmToPixels(1.0)
    Dim posTitulos = New Single() { _
        36.0, _
        93.0, _
        162, _
        209.0, _
        245.3, _
        253.0, _
        421.0, _
        486.2, _
        550.4 _
    }
    Dim camposAlinea() As String = New String() { _
        "I", _
        "D", _
        "D", _
        "D", _
        "D", _
        "I", _
        "D", _
        "D" _
           }

    Dim camposNumSinDec() As String = {"asiento", "documento", "contrapartida", "factura"}
    Dim camposNumDec() As String = {"debe", "haber"}


    Dim nomTempFileXLS As String
    Public nomTempFileXLS2 As String
    Dim isLocal As Boolean
    Dim MyMapPath As String
    Dim subcuentaCur As Int32
    Dim curFecha As String
    Dim subcuentaOld As Int32 = -1
    Dim fontArialNarrow As XFont
    'Dim fontArialNarrowBold As XFont
    Dim fontCalibriBold As XFont
    Dim pfc As New System.Drawing.Text.PrivateFontCollection
    Dim options As New XPdfFontOptions(PdfFontEncoding.Unicode, PdfFontEmbedding.Default)
    Public origMappath As String
    'Dim bFirstInit As Boolean = True


    Public Sub New( _
            ByVal oParam As informesParam, ByVal isLocal As Boolean, _
                Optional ByVal mappath As String = "")
        Try

            'font = New XFont(Me.fontNameBody, _
            '                              Me.fontSizeBody, _
            '                              XFontStyle.Regular, options)
            'fontBold = New XFont(Me.fontNameBody, _
            '                              Me.fontSizeBody, _
            '                              XFontStyle.Bold, options)
            Me.isLocal = isLocal
            Me.origMappath = mappath
            Me.MyMapPath = mappath
            Me.oParam = oParam
            Me.oParam.sTitulo = oParam.sTitulo ' proveedores trimestral
            totalPages = 1 + _
                Math.Floor(oParam.dt.Rows.Count / 30)
            nuevo(mappath)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Sub nuevo(ByVal mappath As String)
        Try
            document = New PdfDocument
            document.Info.Title = oParam.sTitulo
            pen = New XPen(XColor.FromArgb(0, 0, 0))
            Dim i As Int32
            If isLocal Then
                Dim pos2 As Int32 = Len(mappath) ' InStrRev(mappath, "\")

                'Dim sFileArialNarrowBold = Mid(mappath, 1, pos2) + "\ARIALNB.ttf"
                'pfc.AddFontFile(sFileArialNarrowBold)
                'fontArialNarrowBold = New XFont(pfc.Families(0), 11.0, XFontStyle.Bold, options)

                Dim fntName As String = Mid(mappath, 1, pos2) + "\ARIALN.TTF"
                pfc.AddFontFile(fntName)
                fontArialNarrow = New XFont(pfc.Families(0), 11.0, XFontStyle.Regular, options)

                Dim sFileCalibriBold = Mid(mappath, 1, pos2) + "\calibrib.ttf"
                pfc.AddFontFile(sFileCalibriBold)
                fontCalibriBold = New XFont(pfc.Families(1), 11.0, XFontStyle.Bold, options)

                nomTempFileXLS = System.IO.Path.GetTempFileName
                nomTempFileXLS2 = Replace(nomTempFileXLS, ".", "2.")
            Else

                Dim pos As Int32 = InStr(mappath, "xrjunque\")
                Dim pos2 As Int32 = Len(mappath) ' InStrRev(mappath, "\")
                If pos = 0 Then
                    pos = InStrRev(mappath, "\")
                Else
                    pos = InStr(pos, mappath, "\")
                End If
                'Dim fntStream As System.IO.Stream = _
                'Me.GetType.Assembly.GetManifestResourceStream( _
                '    "calibri.ttf")
                'Dim b(fntStream.Length - 1) As Byte
                'fntStream.Read(b, 0, b.Length)
                'fntStream.Close()

                'Dim sFileArialNarrowBold = Mid(mappath, 1, pos2) + "\ARIALNB.ttf"
                'sFileArialNarrowBold = Replace(sFileArialNarrowBold , "\\", "\")
                'pfc.AddFontFile(sFileArialNarrowBold)
                'fontArialNarrowBold = New XFont(pfc.Families(0), 11.0, XFontStyle.Bold, options)

                Dim fntName As String = Mid(mappath, 1, pos2) + "\ARIALN.TTF"
                fntName = Replace(fntName, "\\", "\")
                pfc.AddFontFile(fntName)
                fontArialNarrow = New XFont(pfc.Families(0), 11.0, XFontStyle.Regular, options)

                Dim sFileCalibriBold = Mid(mappath, 1, pos2) + "\calibrib.ttf"
                sFileCalibriBold = Replace(sFileCalibriBold, "\\", "\")
                pfc.AddFontFile(sFileCalibriBold)
                fontCalibriBold = New XFont(pfc.Families(1), 11.0, XFontStyle.Bold, options)

                Dim rnd As New Random
                Dim nomTemp As String = Math.Floor(rnd.NextDouble * 10 ^ 6).ToString + ".pdf"
                Dim sDir As String = Mid(mappath, 1, pos) + "database\agentia\temp\"
                Try
                    Dim files() As String = Directory.GetFiles(sDir)
                    For i = 0 To files.Length - 1
                        Try
                            If InStr(files(i), ".mdb") = 0 Then
                                Directory.Delete(files(i))
                            End If
                        Catch ex3 As Exception

                        End Try
                    Next
                Catch ex2 As Exception

                End Try
                Me.MyMapPath = sDir + nomTemp
                nomTempFileXLS = Me.MyMapPath
                nomTempFileXLS2 = Replace(nomTempFileXLS, ".", "2.")
            End If
        Catch ex As Exception
            Throw New Exception(mappath + " " + ex.ToString)
        End Try
    End Sub

    Private Sub Header()
        Try

            ' Create an empty page
            page = document.AddPage


            ' Get an XGraphics object for drawing
            gfx = XGraphics.FromPdfPage(page)



            curVertPixel = 0 ' curPage * pg.Height  ' cmToPixels(29.7)
            If curPage = 0 Then
                pageW = page.Width.Point
                pageH = page.Height.Point
                margin = (pageW - ancho) / 2.0 + cmToPixels(0.3)
                ReDim posCampos(posTitulos.Length - 1)
                'Me.font = New XFont(Me.fontNameHead, _
                '                 Me.fontSizeBody, _
                '                 XFontStyle.Regular)
                For i As Int32 = 0 To posTitulos.Length - 1
                    If i < LineaCampos.Length Then
                        Dim nom As String = LCase(Me.LineaCampos(i)) ' nombre del campo
                        If Array.IndexOf(Me.camposNumDec, nom) = -1 AndAlso _
                        Array.IndexOf(Me.camposNumSinDec, nom) = -1 Then
                            posCampos(i) = posTitulos(i)
                        Else
                            Dim xsz As XSize = _
                                gfx.MeasureString(nom, Me.fontArialNarrow, XStringFormats.Default)
                            posCampos(i) = posTitulos(i) + xsz.Width
                        End If
                    Else
                        ' columna "Saldo":
                        Dim xsz As XSize = _
                            gfx.MeasureString("Saldo", Me.fontArialNarrow, XStringFormats.Default)
                        posCampos(i) = posTitulos(i) + xsz.Width
                    End If
                Next
            End If
            ' Create a font
            'Dim font As New XFont(pfc.Families(0), 12.0, XFontStyle.Regular, options)
            '                              12, _
            '                              XFontStyle.Bold)

            ' Empresa:
            Dim e1 As String = _
                oParam.sEmp
            Dim xsz1 As XSize = gfx.MeasureString(e1, fontCalibriBold)
            Dim xRct As New XRect(cmToPixels(2.0), _
                                   curVertPixel + margin + vMargin / 2.0 + 5, _
                                   xsz1.Width, xsz1.Height)
            gfx.DrawString(e1, fontCalibriBold, XBrushes.Black, _
                xRct, XStringFormats.Center)

            ' Fecha / p�gina
            e1 = _
            "Fecha: " + String.Format("{0:dd/MM/yyyy}", Now) + _
                        "      P�gina: " + (1 + curPage).ToString + _
                        " / " + totalPages.ToString
            xsz1 = gfx.MeasureString(e1, fontArialNarrow)
            xRct = New XRect( _
                 cmToPixels(13), curVertPixel + 8 + margin + vMargin / 2.0, xsz1.Width, xsz1.Height)
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)


            ' T�tulo:
            e1 = _
            oParam.sTitulo
            xsz1 = gfx.MeasureString(e1, fontArialNarrow)
            xRct = New XRect( _
               cmToPixels(2.0), curVertPixel + 8 + margin + alto / 2.0 + 2, xsz1.Width, xsz1.Height)
            gfx.DrawString(oParam.sTitulo, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            ' Moneda
            e1 = "Moneda: " + oParam.moneda
            xsz1 = gfx.MeasureString(e1, fontArialNarrow)
            xRct = New XRect( _
                 cmToPixels(9), curVertPixel + 8 + margin + alto / 2.0 + 2, xsz1.Width, xsz1.Height)
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)
            ' Desde Fecha, hasta fecha
            e1 = "Desde: " + oParam.desdeFch + _
                                 "  Hasta: " + oParam.hastaFch
            xsz1 = gfx.MeasureString(e1, fontArialNarrow)
            xRct = New XRect( _
                 cmToPixels(13), curVertPixel + 8 + margin + alto / 2.0 + 2, xsz1.Width, xsz1.Height)
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)


            'linea superior:
            Dim pen2 = New XPen(XColor.FromArgb(0, 0, 0), 1)
            Dim xPt() As XPoint = New XPoint() { _
                            New XPoint(margin, curVertPixel + margin), _
                            New XPoint(ancho, curVertPixel + margin)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))
            'linea inferior:
            xPt = New XPoint() {New XPoint(margin, curVertPixel + margin + alto), _
                                New XPoint(ancho, margin + alto)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))
            ' linea izquierda:
            xPt = New XPoint() {New XPoint(margin, curVertPixel + margin), _
                                New XPoint(margin, curVertPixel + margin + alto)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))
            ' l�nea derecha:
            xPt = New XPoint() {New XPoint(ancho, curVertPixel + margin), _
                                New XPoint(ancho, curVertPixel + margin + alto)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))
            ' linea de separaci�n:
            xPt = New XPoint() {New XPoint(margin + (ancho - anchoLnInterior) / 2.0, _
                                curVertPixel + margin + alto / 2.0), _
                                New XPoint(anchoLnInterior, _
                                           curVertPixel + margin + alto / 2.0)}
            gfx.DrawLine(pen2, xPt(0), xPt(1))

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub LinesHeader()
        Try
            Header()
            curVertPixel += margin + alto + 1
            ' Get an XGraphics object for drawing

            'Dim font As XFont = New XFont(Me.fontNameBody, _
            '                              Me.fontSizeBody, _
            '                              XFontStyle.Regular)

            curVertPixel += 5
            For i As Int32 = 0 To LineaEncabezados.Length - 1
                ' encabezado columna "i":
                Dim e1() As String = Split(LineaEncabezados(i), vbCrLf)
                Dim posY As Int32 = curVertPixel
                For j As Int32 = 0 To e1.Length - 1
                    If Len(e1(j)) Then
                        Dim xsz As XSize = _
                            gfx.MeasureString(e1(j), fontArialNarrow, XStringFormats.Default)
                        Dim xRct As New XRect(Me.posTitulos(i), _
                                              posY, _
                                               xsz.Width, _
                                               xsz.Height)
                        If (i - 2) * (i - 3) * (i - 4) * (i - 6) * (i - 7) * (i - 8) = 0 Then
                            xRct = New XRect( _
                                 Me.posTitulos(i) - xsz.Width, posY, xsz.Width, xsz.Height)
                        End If
                        gfx.DrawString(e1(j), fontArialNarrow, XBrushes.Black, _
                            xRct, XStringFormats.Center)
                    End If
                    posY += altoTxt
                Next
            Next
            ' linea de separaci�n:
            curVertPixel += 12
            Dim xPt() As XPoint = New XPoint() { _
                        New XPoint(margin, _
                                    curVertPixel), _
                        New XPoint(ancho, curVertPixel)}
            gfx.DrawLine(pen, xPt(0), xPt(1))
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Sub LineaDoEncabezadoSubcta()
        Try
            Dim i As Int32 = 1
            Dim e1 As String = Me.subcuentaCur.ToString + _
                " " + oParam.dt.Rows(Me.curRow).Item("titulo")
            e1 = Mid(e1, 1, 3) + "." + Mid(e1, 4)
            Dim xsz As XSize = _
                gfx.MeasureString(e1, fontCalibriBold, XStringFormats.Default)
            Dim xRct As New XRect( _
                 cmToPixels(2), curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e1, fontCalibriBold, XBrushes.Black, _
                xRct, XStringFormats.Center)
            curVertPixel += 20

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub LineNext()
        Try
            subcuentaCur = _
                Me.oParam.dt.Rows(curRow).Item("subcuenta")
            Dim e1 As String = _
                Me.oParam.dt.Rows(curRow).Item("fecha")
            Dim fch As New DateTime(Int32.Parse(Mid(e1, 1, 4)), _
                                Int32.Parse(Mid(e1, 5, 2)), _
                                Int32.Parse(Mid(e1, 7, 2)))
            trimEnCurso = 1 + Math.Floor((fch.Month - 1) / 3)
            e1 = Mid(e1, 7, 2) + "/" + Mid(e1, 5, 2) + "/" + Mid(e1, 1, 4)
            curFecha = e1


            If curLine = 0 Then
                LinesHeader()
                curVertPixel += 5
            End If

            If subcuentaCur <> subcuentaOld AndAlso subcuentaOld > -1 Then
                Me.totalTrimestre()
                Me.totalSubcuenta()
            Else
                If trimEnCurso <> trimOld AndAlso trimOld > 0 Then
                    Me.totalTrimestre()
                End If
            End If
            If subcuentaCur <> subcuentaOld Then
                LineaDoEncabezadoSubcta()
            End If

            Dim i As Int32
            Dim iv As Int32 = 0
            Dim col As Int32

            Dim maxAncho As Single = cmToPixels(3.5)
            Dim pos As Int32 = margin
            For col = 0 To LineaCampos.Length - 1
                ' dato columna "i":
                If True Then

                End If
                i = col
                Dim nom As String = LCase(LineaCampos(col))
                Dim bRightAlign As Boolean = False
                If LCase(nom) = "fecha" Then
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom), False)
                    e1 = Mid(e1, 7, 2) + "/" + Mid(e1, 5, 2) + "/" + Mid(e1, 1, 4)
                ElseIf Array.IndexOf(camposNumDec, nom) > -1 Then
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom), True)
                    bRightAlign = True
                ElseIf Array.IndexOf(camposNumSinDec, nom) > -1 Then
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom), False)
                    bRightAlign = True
                    If e1 = "0" Then
                        GoTo sig
                    End If
                    If nom = "factura" Then
                        nom = nom
                    End If
                Else
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom), False)
                End If
                Dim xsz As XSize = _
                    gfx.MeasureString(e1, fontArialNarrow, XStringFormats.Default)
                Dim xRct As XRect = Nothing
                If bRightAlign Then
                    xRct = New XRect( _
                         Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
                Else
                    xRct = New XRect( _
                         Me.posTitulos(i), curVertPixel, xsz.Width, xsz.Height)
                End If
                If nom = "asiento" Then
                    xRct = New XRect(xRct.Left + 23, xRct.Y, xRct.Width, xRct.Height)
                End If
                gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                    xRct, XStringFormats.Center)
sig:
            Next
            Dim D, H As Double
            ' Saldo:
            If oParam.moneda = "�" Then
                D = Math.Round(Me.oParam.dt.Rows(curRow).Item("debe"), 2)
                H = Math.Round(Me.oParam.dt.Rows(curRow).Item("haber"), 2)
                e1 = Me.supressCrLfAndTab(D - H, False)
            Else
                D = Math.Round(Me.oParam.dt.Rows(curRow).Item("debe"), 0)
                H = Math.Round(Me.oParam.dt.Rows(curRow).Item("haber"), 0)
                e1 = Me.supressCrLfAndTab(D - H, False)
            End If
            Me.totalDebe += D
            Me.totalHaber += H
            Me.totalSaldo += D - H
            Me.totalDtrim += D
            Me.totalHtrim += H
            If True Then
                Dim db As Double = Me.totalSaldo
                e1 = supressCrLfAndTab(db, True)
                'If oParam.moneda = "�" Then
                '    e1 = String.Format(us, "{0:###,##0.00}", db)
                'Else
                '    e1 = String.Format(us, "{0:###,##0}", db)
                'End If
                Dim xsz As XSize = _
                gfx.MeasureString(e1, fontArialNarrow, XStringFormats.Default)
                i = Array.IndexOf(Me.LineaCampos, "haber") + 1
                Dim xRct As New XRect( _
                     Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
                gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                    xRct, XStringFormats.Center)

            End If



            curVertPixel += 20

            subcuentaOld = subcuentaCur
            trimOld = trimEnCurso

            curLine += 1 ' linea en curso de la p�gina actual

            curRow += 1 ' # de registro en curso
            ''If curLine >= linesPerPage Then
            ''    curPage += 1
            ''    curLine = 0
            ''End If
            If curVertPixel + Me.margenPie >= Me.pageH Then
                curPage += 1
                curLine = 0
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Function supressCrLfAndTab(ByVal o As Object, _
                                       ByVal bDecimales As Boolean) As String
        Dim e1 As String = ""
        Try
            If o Is Nothing OrElse o Is DBNull.Value Then
                e1 = ""
            ElseIf bDecimales Then
                Dim db As Double
                Try
                    db = o
                Catch ex As Exception
                    e1 = o.ToString
                    Exit Try
                End Try
                Threading.Thread.CurrentThread.CurrentUICulture = us
                db = Math.Round(db, 2)
                'totalHaber += db
                If oParam.moneda = "�" Then
                    e1 = String.Format(us, "{0:###,##0.00}", db)
                Else
                    e1 = String.Format(us, "{0:###,##0}", db)
                End If
            Else
                e1 = o.ToString
                If Len(e1) Then
                    e1 = Replace(e1, vbCr, "")
                    e1 = Replace(e1, vbLf, "")
                    e1 = Replace(e1, "@", "")
                    e1 = Replace(e1, vbTab, " ")
                End If
                o = e1
            End If
            If e1 = ".00" Then
                e1 = "0.00"
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Return e1
    End Function
    Private Sub totalTrimestre()
        Try
            Dim i As Int32
            Dim e1 As String = subcuentaOld.ToString + ":"
            e1 = "Total trimestre " + trimOld.ToString

            Dim e2, e3, e4 As String
            If oParam.moneda = "�" Then
                e2 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                     Math.Round(Me.totalDtrim, 2))
                e3 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalHtrim, 2))
                e4 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalDtrim - Me.totalHtrim, 2))
            Else
                e2 = String.Format( _
                    us, "{0:#,###,##0}", _
                     Math.Round(Me.totalDtrim, 0))
                e3 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalHtrim, 0))
                e4 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalDtrim - Me.totalHtrim, 0))
            End If
            Dim xRct As XRect
            Dim xsz As XSize = _
                gfx.MeasureString(e1, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 cmToPixels(8), curVertPixel, xsz.Width, xsz.Height)
            ' Texto "Total Subcuenta"
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            i = Array.IndexOf(Me.LineaCampos, "debe")
            xsz = _
                gfx.MeasureString(e2, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            ' totalDebe
            gfx.DrawString(e2, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            i += 1
            xsz = _
                gfx.MeasureString(e3, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            ' totalHaber
            gfx.DrawString(e3, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            i += 1
            xsz = _
                gfx.MeasureString(e4, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            ' totalSaldo
            gfx.DrawString(e4, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            curVertPixel += 20
            Dim xPt() As XPoint = New XPoint() { _
                New XPoint(margin, _
                            curVertPixel), _
                New XPoint(cmToPixels(15), curVertPixel)}
            gfx.DrawLine(pen, xPt(0), xPt(1))


            Me.totalDtrim = 0.0
            Me.totalHtrim = 0.0
            curVertPixel += 20
            curLine += 2 ' # de l�nea en curso
            'If curLine + 1 >= linesPerPage Then
            '    curPage += 1
            '    curLine = 0
            'End If
            If curVertPixel + Me.margenPie >= Me.pageH Then
                curPage += 1
                curLine = 0
                LinesHeader()
                curVertPixel += 5
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub totalSubcuenta()
        Try
            Dim i As Int32
            Dim e1 As String = subcuentaOld.ToString + ":"
            e1 = "Total subcuenta " + Mid(e1, 1, 3) + "." + Mid(e1, 4)

            Dim e2, e3, e4 As String
            If oParam.moneda = "�" Then
                e2 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                     Math.Round(Me.totalDebe, 2))
                e3 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalHaber, 2))
                e4 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalSaldo, 2))
            Else
                e2 = String.Format( _
                    us, "{0:#,###,##0}", _
                     Math.Round(Me.totalDebe, 0))
                e3 = String.Format( _
                    us, "{0:#,###,##0}", _
                    Math.Round(Me.totalHaber, 0))
                e4 = String.Format( _
                    us, "{0:#,###,##0}", _
                    Math.Round(Me.totalSaldo, 0))
            End If
            Dim xRct As XRect
            Dim xsz As XSize = _
                gfx.MeasureString(e1, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 cmToPixels(8), curVertPixel, xsz.Width, xsz.Height)
            ' Texto "Total Subcuenta"
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            i = Array.IndexOf(Me.LineaCampos, "debe")
            xsz = _
                gfx.MeasureString(e2, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            ' totalDebe
            gfx.DrawString(e2, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            i += 1
            xsz = _
                gfx.MeasureString(e3, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            ' totalHaber
            gfx.DrawString(e3, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            i += 1
            xsz = _
                gfx.MeasureString(e4, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            ' totalSaldo
            gfx.DrawString(e4, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            curVertPixel += 20
            Dim xPt() As XPoint = New XPoint() { _
                New XPoint(margin, _
                            curVertPixel), _
                New XPoint(cmToPixels(15), curVertPixel)}
            gfx.DrawLine(pen, xPt(0), xPt(1))

            Me.totalDebeGnral += Me.totalDebe
            Me.totalHaberGnral += Me.totalHaber

            Me.totalDebe = 0.0
            Me.totalHaber = 0.0
            Me.totalSaldo = 0.0
            curVertPixel += 20
            curLine += 2 ' # de l�nea en curso
            'If curLine + 1 >= linesPerPage Then
            '    curPage += 1
            '    curLine = 0
            'End If
            If curVertPixel + Me.margenPie >= Me.pageH Then
                curPage += 1
                curLine = 0
                LinesHeader()
                curVertPixel += 5
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub totalMayor()
        Try
            Dim i As Int32 = 5
            'Dim font As XFont = New XFont(Me.fontNameBody, _
            '                              Me.fontSizeBody, _
            '                              XFontStyle.Regular)
            Dim e2, e3, e4 As String
            If oParam.moneda = "�" Then
                e2 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                     Math.Round(Me.totalDebeGnral, 2))
                e3 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalHaberGnral, 2))
                e4 = String.Format( _
                    us, "{0:#,###,##0.00}", _
                    Math.Round(Me.totalDebeGnral - Me.totalHaberGnral, 2))
            Else
                e2 = String.Format( _
                    us, "{0:#,###,##0}", _
                     Math.Round(Me.totalDebeGnral, 0))
                e3 = String.Format( _
                    us, "{0:#,###,##0}", _
                    Math.Round(Me.totalHaberGnral, 0))
                e4 = String.Format( _
                    us, "{0:#,###,##0}", _
                    Math.Round(Me.totalDebeGnral - Me.totalHaberGnral, 0))
            End If
            Dim e1 As String = "Total Mayor:"
            Dim xRct As XRect
            Dim xsz As XSize = _
                gfx.MeasureString(e1, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 cmToPixels(8), curVertPixel, xsz.Width, xsz.Height)
            ' Texto "Total mayor"
            gfx.DrawString(e1, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            i = Array.IndexOf(Me.LineaCampos, "debe")
            xsz = _
            gfx.MeasureString(e2, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e2, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)
            i += 1
            xsz = _
                gfx.MeasureString(e3, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e3, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)
            i += 1
            xsz = _
                gfx.MeasureString(e4, fontArialNarrow, XStringFormats.Default)
            xRct = New XRect( _
                 Me.posTitulos(i) - xsz.Width, curVertPixel, xsz.Width, xsz.Height)
            gfx.DrawString(e4, fontArialNarrow, XBrushes.Black, _
                xRct, XStringFormats.Center)

            Me.totalDebe = 0.0
            Me.totalHaber = 0.0
            curVertPixel += 20
            curLine += 2 ' # de l�nea en curso

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    'Public ReadOnly Property path()
    '    Get
    '        If isLocal Then
    '            Return _
    '             "E:\new\Agentia Junfor\ContaJunfor\ContaJunfor2\ContaJunforWebService\InformesAgentia\"
    '        End If
    '        Return MyMapPath
    '    End Get
    'End Property
    Public Sub save(ByVal nom As String)
        Me.document.Save(nom)
    End Sub
    Public Function Show() As PdfDocument
        Try
            If oParam.importeDebeMayorA <> 0.0 Then
                Dim dt1 As New DataTable
                For col = 0 To oParam.dt.Columns.Count - 1
                    dt1.Columns.Add(oParam.dt.Columns(col).ColumnName, _
                                    oParam.dt.Columns(col).DataType)
                Next
                Dim cursubcta As Int32 = -1
                Dim oldSubCta As Int32 = -1
                Dim lastI As Int32 = 0
                Dim D As Double = 0
                For i As Int32 = 0 To oParam.dt.Rows.Count
                    If i < oParam.dt.Rows.Count Then
                        cursubcta = oParam.dt.Rows(i).Item("subcuenta")
                    End If
                    If i = 0 Then
                        oldSubCta = cursubcta
                    End If
                    If i = oParam.dt.Rows.Count OrElse _
                    (oldSubCta > -1 AndAlso cursubcta <> oldSubCta) Then
                        If D > oParam.importeDebeMayorA Then
                            For j = lastI To i - 1
                                Dim o() = oParam.dt.Rows(j).ItemArray
                                dt1.Rows.Add(o)
                            Next
                        End If
                        If i = oParam.dt.Rows.Count Then
                            Exit For
                        End If
                        oldSubCta = cursubcta
                        D = 0
                        lastI = i
                    End If
                    cursubcta = oParam.dt.Rows(i).Item("subcuenta")
                    D += oParam.dt.Rows(i).Item("debe")
                Next
                oParam.dt = dt1
            End If
            If oParam.importeHaberMayorA <> 0.0 Then
                Dim dt1 As New DataTable
                For col = 0 To oParam.dt.Columns.Count - 1
                    dt1.Columns.Add(oParam.dt.Columns(col).ColumnName, _
                                    oParam.dt.Columns(col).DataType)
                Next
                Dim cursubcta As Int32 = -1
                Dim oldSubCta As Int32 = -1
                Dim lastI As Int32 = 0
                Dim H As Double = 0
                For i As Int32 = 0 To oParam.dt.Rows.Count
                    If i < oParam.dt.Rows.Count Then
                        cursubcta = oParam.dt.Rows(i).Item("subcuenta")
                        If oParam.dt.Rows(i).Item("asiento") = 369 orelse i=331 then
                            Dim asiento As Int32 = oParam.dt.Rows(i).Item("asiento")
                        End If
                    End If
                    If i = 0 Then
                        oldSubCta = cursubcta
                    End If
                    If i = oParam.dt.Rows.Count OrElse _
                    (oldSubCta > -1 AndAlso cursubcta <> oldSubCta) Then
                        If H > oParam.importeHaberMayorA Then
                            For j = lastI To i - 1
                                Dim o() = oParam.dt.Rows(j).ItemArray
                                dt1.Rows.Add(o)
                            Next
                        End If
                        If i = oParam.dt.Rows.Count Then
                            Exit For
                        End If
                        oldSubCta = cursubcta
                        H = 0
                        lastI = i
                    End If
                    cursubcta = oParam.dt.Rows(i).Item("subcuenta")
                    H += oParam.dt.Rows(i).Item("haber")
                Next
                oParam.dt = dt1
            End If

            Show2()
            Me.totalPages = Me.curPage + 1
            document.Close()
            'nuevo(origMappath)
            document = New PdfDocument
            document.Info.Title = oParam.sTitulo
        Catch ex As Exception

        End Try
        Return Show2()
    End Function
    Public Function Show2() As PdfDocument
        Try
            Me.curPage = 0
            Me.subcuentaOld = -1
            Me.subcuentaCur = 0
            Me.curRow = 0
            Me.curVertPixel = 0
            Me.curLine = 0
            totalHaber = 0.0
            totalDebe = 0.0
            totalSaldo = 0.0
            totalHaberGnral = 0.0
            totalDebeGnral = 0.0
            Do While curRow < oParam.dt.Rows.Count
                LineNext()
            Loop
            totalTrimestre()
            totalSubcuenta()
            'If curLine > linesPerPage Then
            '    curPage += 1
            '    curLine = 0
            '    LinesHeader()
            '    curVertPixel += 5
            'End If
            If curVertPixel + Me.margenPie >= Me.pageH Then
                curPage += 1
                curLine = 0
                LinesHeader()
                curVertPixel += 5
            End If
            totalMayor()
            '' Save the document...
            'Dim e2 As String = ""
            'If IsNetworkDeployed Then
            '    e2 = System.Deployment.Application.ApplicationDeployment.CurrentDeployment.DataDirectory
            'Else
            '    e2 = System.IO.Directory.GetCurrentDirectory
            'End If
            'e2 += "\temp.pdf"
            'document.Save(e2)
            '' ...and start a viewer.
            'Dim proc As New Process
            'proc.StartInfo.FileName = e2
            'proc.StartInfo.UseShellExecute = True
            'proc.Start()
        Catch ex As Exception
            Throw ex
        End Try
        Return document
    End Function
    Private Function cmToPixels(ByVal cm As Single) As Single
        Return cm * 29.14
    End Function
    Public Shared Function o(ByVal value As Object) As String
        Try
            If value Is DBNull.Value Then
                Return ""
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
        Return value
    End Function

End Class
