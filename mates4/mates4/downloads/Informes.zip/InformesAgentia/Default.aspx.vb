﻿Imports System.Data.OleDb
'Imports ContaJunforWebService
Imports System.Text.RegularExpressions

Partial Public Class _Default
    Inherits System.Web.UI.Page

    Dim us As New Globalization.CultureInfo("en-US")
    Dim es As New Globalization.CultureInfo("es-ES")
    Dim yyyy As Int32
    Dim MM As Int32
    Dim dd As Int32
    Dim vEmp() As es.nom.xrjunque.CEmp
    Dim curEmp As es.nom.xrjunque.CEmp
    Dim usuario As New es.nom.xrjunque.CUsuario
    Dim u As New ContaJunforWebService.CUsuario
    Dim sr As New es.nom.xrjunque.Service1
    Dim sTrimestre As String = ""
    Dim sMes As String = ""
    Dim sInforme As String = ""
    Dim fchDesde1, fchHasta1 As DateTime
    Dim anyo As Int32 = Now.Year
    Dim sFchDesde, sFchHasta As String
    Dim sHaving As String
    Dim sMasDe300506 As String
    Dim vdt(-1) As DataTable
    Dim importeDebeMayorA As Double = 0.0
    Dim importeHaberMayorA As Double = 0.0
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            ContaJunforWebService.CUsuario.IsLocal = False ' Request.IsLocal
            If Not IsPostBack Then
                populateForm()
            End If
            Dim tempUser As New es.nom.xrjunque.CUsuario
            tempUser.usuario = "ag1234"
            tempUser.contrasenya = "ag4321"
            If sr.getDatosUsuario(tempUser, "") Then
                vEmp = sr.getEmpr(tempUser)
                'cbEmpresa.Items.Clear()
                'For i = 0 To vEmp.Length - 1
                '    cbEmpresa.Items.Add(vEmp(i).AnyEjercicio.ToString + " " + _
                '                        vEmp(i).Nombre)
                'Next
                'If vEmp.Length Then
                '    cbEmpresa.SelectedIndex = vEmp.Length - 1
                'End If
            End If
            'If Len(tbUsuario.Text) AndAlso Len(tbUsuario.Text) Then
            '    If Session.Item("user") Is Nothing Then
            '        usuario.usuario = tbUsuario.Text
            '        usuario.contrasenya = tbContrasenya.Text
            '        If Not sr.getDatosUsuario(usuario) Then
            '            tbMsg.Text = "error en nombre o contraseña"
            '            Exit Sub
            '        End If
            '        Session.Add("user", tbUsuario.Text)
            '        Session.Add("psw", tbContrasenya.Text)
            '    Else
            '        Session.Item("user") = tbUsuario.Text
            '        Session.Item("psw") = tbContrasenya.Text
            '    End If
            '    tbUsuario.Text = ""
            '    tbContrasenya.Text = ""
            'Else
            '    If Session.Item("user") Is Nothing Then
            '        'tbMsg.Text = "error en nombre o contraseña"
            '        'Exit Sub
            '    Else
            '        usuario.usuario = Session.Item("user") '  tbUsuario.Text
            '        usuario.contrasenya = Session.Item("psw") ' tbContrasenya.Text
            '    End If
            'End If
            If tbUsuario.Text.Length * tbContrasenya.Text.Length = 0 Then
                If Session("user") IsNot Nothing Then
                    tbUsuario.Text = Session("user")
                    tbContrasenya.Text = Session("psw")
                End If
            Else
                If Session("user") Is Nothing Then
                    Session.Add("user", tbUsuario.Text)
                    Session.Add("psw", tbContrasenya.Text)
                Else
                    Session("user") = tbUsuario.Text
                    Session("psw") = tbContrasenya.Text
                End If
            End If
            usuario.usuario = tbUsuario.Text
            usuario.contrasenya = tbContrasenya.Text
            u.usuario = usuario.usuario
            u.contrasenya = usuario.contrasenya
            sInforme = Request.Params("informe")
            sHaving = ""
            If Not IsPostBack Then
                Dim sInf As String = LCase(sInforme)
                If InStr(sInf, "prov") AndAlso InStr(sInf, "trim") Then
                    'TRIMESTRAL proveed. de más de 3005,06 
                    tbCondiciones.Text = "  subcuenta>=4100000 AND subcuenta<=4109999"
                    tbCondiciones.Text += " totalhaber>3005.06"
                ElseIf InStr(sInf, "cli") AndAlso InStr(sInf, "trim") Then
                    'TRIMESTRAL clientes de más de 3005,06 
                    tbCondiciones.Text = " subcuenta>=4300000 AND subcuenta<=4309999"
                    tbCondiciones.Text += " totaldebe>3005.06"
                ElseIf InStr(sInf, "proveedores") Then ' proveed. de más de 
                    tbCondiciones.Text = "  subcuenta>=4100000 AND subcuenta<=4109999"
                    tbCondiciones.Text += " HAVING sum(haber)>3005.06"
                ElseIf InStr(sInf, "clientes") Then ' clientes de más de 
                    tbCondiciones.Text = " subcuenta>=4300000 AND subcuenta<=4309999"
                    tbCondiciones.Text += " HAVING sum(debe)>3005.06"
                ElseIf InStr(sInf, "recibidas") Then ' fras. recibidas
                    tbCondiciones.Text = "  subcuenta>=4720000 AND subcuenta<=4729999 AND factura>0"
                ElseIf InStr(sInf, "emitidas") Then ' fras. emitidas
                    tbCondiciones.Text = "  subcuenta>=4770000 AND subcuenta<=4779999 AND factura>0"
                ElseIf InStr(sInf, "303") Then ' modelo 303
                    tbCondiciones.Text = "  ((subcuenta>=4720000 AND subcuenta<=4729999)"
                    tbCondiciones.Text += " OR (subcuenta>=4770000 AND subcuenta<=4779999))"
                ElseIf InStr(sInf, "sumas") Then ' balance de sumas y saldos
                    tbCondiciones.Text = ""
                ElseIf InStr(sInf, "situac") Then ' balance de situación
                ElseIf InStr(sInf, "ganancias") Then ' balance de pérdidas y ganancias
                End If
            End If
            If cbMes.SelectedIndex > 0 Then
                sMes = cbMes.SelectedValue
            ElseIf cbTrimestre.SelectedIndex > 0 Then
                sTrimestre = cbTrimestre.SelectedValue
            End If
            Dim e1() As String = Split(tbfchDesde.Text, "/")
            fchDesde1 = New DateTime(Int32.Parse(e1(2)), _
                                  Int32.Parse(e1(1)), _
                                  Int32.Parse(e1(0)))
            sFchDesde = String.Format("{0:dd/MM/yyyy}", fchDesde1)
            e1 = Split(tbfchHasta.Text, "/")
            fchHasta1 = New DateTime(Int32.Parse(e1(2)), _
                                  Int32.Parse(e1(1)), _
                                  Int32.Parse(e1(0)))
            sFchHasta = String.Format("{0:dd/MM/yyyy}", fchHasta1)
            'Int32.TryParse(tbEjercicio.Text, anyo)
            'anyo=vemp
            If Len(sInforme) Then
                litTitulo.Text = "<h3>Informe: " + sInforme + "</h3>"
                'btnAceptar_Click(Nothing, Nothing)
            End If
        Catch ex As Exception
            tbMsg.Text = ex.ToString
        End Try
    End Sub
    Private Sub btnAceptar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAceptar.Click
        Try
            Dim semp As String = ""
            Dim i As Int32
            Dim moneda As String = ""
            Try
                'If tbUsuario.Text.Length = 0 OrElse tbContrasenya.Text.Length = 0 Then
                '    tbMsg.Text = "error en nombre o contraseña"
                '    Exit Sub
                'End If
                If Not sr.getDatosUsuario(usuario, "") Then
                    If Session.Item("user") Is Nothing Then
                        Exit Sub
                    End If
                    tbMsg.Text = "error en nombre o contraseña"
                    Exit Sub
                End If
                If Not ContaJunforWebService.CUsuario.GetUserData(u, "") Then
                    If Session.Item("user") Is Nothing Then
                        Exit Sub
                    End If
                    tbMsg.Text = "error en nombre o contraseña"
                    Exit Sub
                End If

                vEmp = sr.getEmpr(usuario)
                'i = cbEmpresa.SelectedIndex
                'For i = 0 To vEmp.Length - 1
                '   If vEmp(i).AnyEjercicio.ToString = tbEjercicio.Text Then
                If Len(tbfchDesde.Text) >= 8 Then
                    Int32.TryParse(Right(tbfchDesde.Text, 4), yyyy)
                End If
                For j As Int32 = 0 To vEmp.Length - 1
                    If vEmp(j).AnyEjercicio = yyyy Then
                        curEmp = vEmp(j)
                        i = j
                        Exit For
                    End If
                Next
                curEmp = vEmp(i)
                semp = vEmp(i).Nombre
                moneda = vEmp(i).Moneda
                If i >= vEmp.Length Then
                    tbMsg.Text = vEmp.Length.ToString + " no cumplen"
                    Exit Sub
                End If
            Catch ex2 As Exception
                tbMsg.Text = "error en nombre o contraseña"
                Exit Sub
            End Try
            Dim sql As String = ""
            If Not Me.parseCondiciones(sql) Then
                Exit Sub
            End If
            Dim sOrderBy As String = ""
            Dim sGroupBy As String = ""
            Dim sSelect As String = ""
            Dim sHaving As String = ""
            Dim sWhere As String = ""
            Dim sInf As String = LCase(sInforme)
            Dim oParam As informesParam = Nothing
            If InStr(sInf, "prov") AndAlso InStr(sInf, "trim") Then
                'TRIMESTRAL proveed. de más de 3005,06 
                ' parecido a Libro Mayor
                sOrderBy = " subcuentas.subcuenta,diario.fecha,diario.asiento,diario.partida "
            ElseIf InStr(sInf, "cli") AndAlso InStr(sInf, "trim") Then
                'TRIMESTRAL clientes de más de 3005,06 
                ' parecido a Libro Mayor
                sOrderBy = " subcuentas.subcuenta,diario.fecha,diario.asiento,diario.partida "
            ElseIf InStr(sInf, "proveedores") Then

                ' Proveed. de más de 
                Dim e1 As String = "subcuentas.subcuenta," + _
                        "subcuentas.titulo, " + _
                        "subcuentas.NIF," + _
                        "subcuentas.domicilio," + _
                        "subcuentas.poblacion," + _
                        "subcuentas.provincia," + _
                        "subcuentas.codPostal," + _
                        "subcuentas.documento"
                sSelect = "SELECT " + e1 + _
                            ",sum(round(diario.haber,2)) AS total FROM Subcuentas,Diario "
                sOrderBy = " subcuentas.subcuenta "
                sGroupBy = e1
                sHaving = Me.sHaving

            ElseIf InStr(sInf, "clientes") Then

                ' clientes de más de 
                Dim e1 As String = "subcuentas.subcuenta," + _
                        "subcuentas.titulo, " + _
                        "subcuentas.NIF," + _
                        "subcuentas.domicilio," + _
                        "subcuentas.poblacion," + _
                        "subcuentas.provincia," + _
                        "subcuentas.codPostal," + _
                        "subcuentas.documento"
                sSelect = "SELECT " + e1 + _
                            ",sum(round(diario.debe,2)) AS total  FROM Subcuentas,Diario "
                sOrderBy = " subcuentas.subcuenta "
                sGroupBy = e1
                sHaving = Me.sHaving

            ElseIf InStr(sInf, "recibidas") OrElse _
            InStr(sInf, "emitidas") Then

                ' Fras. recibidas ó emitidas
                sOrderBy = " diario.fecha,diario.factura "

            ElseIf InStr(sInf, "303") Then

                ' IVA trim. Modelo 303
                sSelect = "SELECT " + _
                            " subcuentas.ReperSoportado,subcuentas.titulo,subcuentas.subcuenta" + _
                            ",diario.tipoIva,sum(round(diario.baseIva,2)) as totalBase" + _
                            ",sum(round(diario.baseIva*diario.tipoIva/100,2)) as totalCuota" + _
                            ",sum(round(diario.debe,2)) AS totalDebe" _
                            + ",sum(round(diario.haber,2)) AS totalHaber  FROM Diario,Subcuentas "
                sOrderBy = " subcuentas.ReperSoportado"
                sGroupBy = " subcuentas.ReperSoportado,subcuentas.titulo,subcuentas.subcuenta,diario.tipoIva"
                sHaving = " HAVING len(subcuentas.reperSoportado)>1 AND diario.tipoIva=int(mid(subcuentas.reperSoportado,2))"


            ElseIf InStr(sInf, "sumas") Then

                ' Balance de sumas y saldos
                ReDim vdt(2)
                sSelect = "SELECT subcuentas.subcuenta,subcuentas.titulo," + _
                "sum(round(diario.debe)) AS TotalDEBE,sum(round(diario.haber)) AS TotalHABER" + _
                ",sum(round(diario.debe)-round(diario.haber)) AS TotalSALDO " + _
                " FROM subcuentas,diario "
                sOrderBy = " subcuentas.subcuenta"
                Dim oParam0 = New informesParam( _
                    vEmp(i), _
                     semp, _
                    sInforme, _
                    sFchDesde, _
                    sFchHasta, _
                    fchDesde1, _
                    fchHasta1, _
                    moneda, _
                    sql, _
                    sSelect, _
                     sGroupBy, _
                    sOrderBy, _
                    sHaving, _
                    sWhere)
                vdt(0) = oParam0.getDataTables(usuario, Request)

                sSelect = "SELECT subcuentas.subcuenta,subcuentas.titulo" + _
                ",sum(round(diario.debe,2)-round(diario.haber,2)) AS SaldoInicial " + _
                " FROM subcuentas,diario "
                sWhere = " concepto LIKE 'Asiento de Apertura'"
                sOrderBy = " subcuentas.subcuenta"

                Dim oParam1 = New informesParam( _
                    vEmp(i), _
                     semp, _
                    sInforme, _
                    sFchDesde, _
                    sFchHasta, _
                    fchDesde1, _
                    fchHasta1, _
                    moneda, _
                    sql, _
                    sSelect, _
                     sGroupBy, _
                    sOrderBy, _
                    sHaving, _
                    sWhere)
                vdt(1) = oParam1.getDataTables(usuario, Request)

            ElseIf InStr(sInf, "situac") Then

                ' Balance de situación

            ElseIf InStr(sInf, "ganancias") Then

                ' Balance de pérdidas y ganancias

            ElseIf InStr(sInf, "diario") Then

                ' Libro Diario

                sOrderBy = " diario.fecha,diario.asiento,diario.partida "

            ElseIf InStr(sInf, "mayor") Then

                ' Libro Mayor

                sOrderBy = " subcuentas.subcuenta,diario.fecha,diario.asiento,diario.partida "

            End If
            oParam = New informesParam( _
                vEmp(i), _
                 semp, _
                sInforme, _
                sFchDesde, _
                sFchHasta, _
                fchDesde1, _
                fchHasta1, _
                moneda, _
                sql, _
                sSelect, _
                 sGroupBy, _
                sOrderBy, _
                sHaving, _
                sWhere, _
                Me.importeDebeMayorA, _
                Me.importeHaberMayorA)
            Dim dt As DataTable = oParam.getDataTables(usuario, Request)
            If dt.Rows.Count = 0 Then
                tbMsg.Text = "Sin coincidencias."
                Exit Try
            End If
            Dim xlsInforme As Object = Nothing
            Dim isLocal As Boolean = False
            If InStr(Request.Url.AbsoluteUri, "//localhost") OrElse _
                InStr(Request.Url.AbsoluteUri, "//127.0.0") Then
                isLocal = True
            End If
            Dim mappath As String = Request.MapPath(".")
            If InStr(mappath, "?") Then
                mappath = Split(mappath, "?")(0)
            End If
            If InStr(mappath, ".aspx") Then
                Dim e2() As String = Split(mappath, "\")
                ReDim Preserve e2(e2.Length - 2)
                mappath = Join(e2, "\")
            End If
            Select Case LCase(sInforme)
                Case "prov(trimestral) de+de"
                    oParam.sTitulo = "Proveed_acree_" + Me.importeHaberMayorA.ToString(us)
                    If chkPdf.Checked Then
                        xlsInforme = New TrimProvClientes300506Pdf(oParam, isLocal, mappath)
                    Else
                        xlsInforme = New TrimProvClientesXls(oParam, isLocal, mappath)
                    End If
                Case "clientes(trimestral) de+de"
                    oParam.sTitulo = "Clientes_deud_" + Me.importeDebeMayorA.ToString(us)
                    If chkPdf.Checked Then
                        xlsInforme = New TrimProvClientes300506Pdf(oParam, isLocal, mappath)
                    Else
                        xlsInforme = New TrimProvClientesXls(oParam, isLocal, mappath)
                    End If
                Case "diario"
                    If chkPdf.Checked Then
                        xlsInforme = New DiarioPdf(oParam, isLocal, mappath)
                    Else
                        xlsInforme = New DiarioXls(oParam, isLocal, mappath)
                    End If
                Case "mayor"
                    If chkPdf.Checked Then
                        xlsInforme = New MayorPdf(oParam, isLocal, mappath)
                    Else
                        xlsInforme = New MayorXls(oParam, isLocal, mappath)
                    End If
                Case "proveedores de+de"
                    oParam.sTitulo = "Proveed_acree_" + sMasDe300506
                    If chkPdf.Checked Then
                        xlsInforme = New Prov300506Pdf(oParam, isLocal, mappath)
                    Else
                        xlsInforme = New Prov300506Xls(oParam, isLocal, mappath)
                    End If
                Case "clientes de+de"
                    oParam.sTitulo = "Clientes_deud_" + sMasDe300506
                    If chkPdf.Checked Then
                        xlsInforme = New Clientes300506Pdf(oParam, isLocal, mappath)
                    Else
                        xlsInforme = New Clientes300506Xls(oParam, isLocal, mappath)
                    End If
                Case "facturas recibidas"
                    If chkPdf.Checked Then
                        xlsInforme = New frasRecibidasPdf(oParam, isLocal, mappath)
                    Else
                        xlsInforme = New FrasRecibidasXls(oParam, isLocal, mappath)
                    End If
                Case "facturas emitidas"
                    If chkPdf.Checked Then
                        xlsInforme = New frasEmitidasPdf(oParam, isLocal, mappath)
                    Else
                        xlsInforme = New FrasEmitidasXls(oParam, isLocal, mappath)
                    End If
                Case "iva trim. (mod.303)"
                    If chkPdf.Checked Then
                        oParam.sTitulo = "Resumen_de_Iva_mod303"
                        xlsInforme = New Modelo303Pdf(oParam, isLocal, mappath)
                    Else
                        xlsInforme = New Modelo303Xls(oParam, isLocal, mappath)
                    End If
                Case "sumas y saldos"
                Case "situación"
                Case "pérdidas y ganancias"
            End Select
            xlsInforme.Show()
            Response.Clear()
            Response.Buffer = True
            Response.ContentType = "application/vnd.ms-excel"
            If chkPdf.Checked Then
                Try
                    xlsInforme.save(xlsInforme.nomtempfilexls2)
                    Response.AddHeader("content-disposition", "attachment;filename=" + _
                                     Replace(oParam.sTitulo, "+", "mas") + ".pdf")
                    Response.Charset = ""
                    Dim fs As New IO.FileStream(xlsInforme.nomtempfilexls2, IO.FileMode.Open, IO.FileAccess.Read)
                    Dim br As New IO.BinaryReader(fs)
                    Dim resto As Int32 = fs.Length
                    Dim b(511) As Byte
                    Do While resto > 512
                        br.Read(b, 0, 512)
                        Response.BinaryWrite(b)
                        resto -= 512
                    Loop
                    If resto Then
                        ReDim b(resto - 1)
                        br.Read(b, 0, resto)
                        Response.BinaryWrite(b)
                        resto -= b.Length
                    End If
                    br.Close()
                    fs.Close()
                    IO.File.Delete(xlsInforme.xls2)
                Catch ex As Exception
                    Throw ex
                End Try
            Else
                Response.AddHeader("content-disposition", "attachment;filename=" + _
                                 Replace(oParam.sTitulo, "+", "mas") + ".xml")
                Response.Charset = ""
                Try
                    Dim fs As New IO.FileStream(xlsInforme.nomtempfilexls2, IO.FileMode.Open, IO.FileAccess.Read)
                    Dim sr As New IO.StreamReader(fs)
                    Do While Not sr.EndOfStream
                        Dim e4 As String = sr.ReadLine
                        Response.Write(e4 + vbCrLf)
                    Loop
                    sr.Close()
                    fs.Close()
                Catch ex As Exception
                    Throw ex
                End Try
            End If
            Try
                Response.End()
            Catch ex2 As Exception
            End Try
        Catch ex As Exception
            tbMsg.Text = ex.ToString
        End Try
    End Sub
    Sub populateForm()
        Try
            Dim dtNow As New DateTime(Now.Ticks)
            yyyy = dtNow.Year
            MM = dtNow.Month
            dd = dtNow.Day
            If tbfchDesde.Text = "" Then
                dtfchDesde.SelectedDate = New DateTime(yyyy, 1, 1)
                dtfchHasta.SelectedDate = New DateTime(yyyy, 12, 31)
                tbfchDesde.Text = String.Format("{0:dd/MM/yyyy}", dtfchDesde.SelectedDate)
                tbfchHasta.Text = String.Format("{0:dd/MM/yyyy}", dtfchHasta.SelectedDate)
            Else
                dtNow = DateTime.Parse(tbfchDesde.Text, es)
            End If
            'tbEjercicio.Text = yyyy.ToString
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub dtfchDesde_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtfchDesde.SelectionChanged
        tbfchDesde.Text = String.Format("{0:dd/MM/yyyy}", dtfchDesde.SelectedDate)
        cbMes.SelectedIndex = -1
        cbTrimestre.SelectedIndex = -1
        yyyy = dtfchDesde.SelectedDate.Year
    End Sub

    Private Sub dtfchHasta_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtfchHasta.SelectionChanged
        tbfchHasta.Text = String.Format("{0:dd/MM/yyyy}", dtfchHasta.SelectedDate)
        cbMes.SelectedIndex = -1
        cbTrimestre.SelectedIndex = -1
    End Sub

    Private Sub cbMes_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cbMes.SelectedIndexChanged
        cbTrimestre.SelectedIndex = -1
        sMes = cbMes.SelectedValue
        Try
            fchDesde1 = New DateTime(anyo, _
                               Int32.Parse(sMes), _
                               1)
            fchHasta1 = New DateTime(anyo, _
                            Int32.Parse(sMes), _
                        DateTime.DaysInMonth(fchDesde1.Year, _
                                             fchDesde1.Month))
            Me.dtfchDesde.VisibleDate = fchDesde1.Date
            Me.dtfchHasta.VisibleDate = fchHasta1.Date
            Me.dtfchDesde.SelectedDate = fchDesde1.Date
            Me.dtfchHasta.SelectedDate = fchHasta1.Date
            tbfchDesde.Text = String.Format("{0:dd/MM/yyyy}", fchDesde1.Date)
            tbfchHasta.Text = String.Format("{0:dd/MM/yyyy}", fchHasta1.Date)
            yyyy = fchDesde1.Year
        Catch ex As Exception
            tbMsg.Text = ex.ToString
        End Try
    End Sub

    Private Sub cbTrimestre_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cbTrimestre.SelectedIndexChanged
        cbMes.SelectedIndex = -1
        Try
            Dim mes As Int32
            mes = Int32.Parse(cbTrimestre.SelectedValue)
            fchDesde1 = New DateTime(anyo, _
                               mes, _
                               1)
            mes += 2
            fchHasta1 = New DateTime(anyo, _
                            mes, _
                        DateTime.DaysInMonth(fchDesde1.Year, _
                                             mes))
            Me.dtfchDesde.VisibleDate = fchDesde1.Date
            Me.dtfchHasta.VisibleDate = fchHasta1.Date
            Me.dtfchDesde.SelectedDate = fchDesde1.Date
            Me.dtfchHasta.SelectedDate = fchHasta1.Date
            tbfchDesde.Text = String.Format("{0:dd/MM/yyyy}", fchDesde1.Date)
            tbfchHasta.Text = String.Format("{0:dd/MM/yyyy}", fchHasta1.Date)
            yyyy = fchDesde1.Year
        Catch ex As Exception
            tbMsg.Text = ex.ToString
        End Try
    End Sub
    Function parseCondiciones(ByRef sql As String) As Boolean

        Dim e1 As String = ""
        Dim bEsTotalH, bEstotalD As Boolean
        Try
            Dim e2 As String = " AND "
            e2 += String.Format(" '{0:yyyyMMdd}'<=diario.fecha ", fchDesde1)
            e2 += " AND "
            e2 += String.Format(" diario.fecha<='{0:yyyyMMdd}' ", fchHasta1)
            Dim patron As String = "(?<val>\'[^\']*\'|[0-9\.\,]+)|(?<eq>[\=\<\>\(\)]+)"
            patron += "|totaldebe|totalhaber"
            patron += "|sum|len|having|subcuenta|contrapartida|asiento|debe|haber|factura|doc|titulo|concepto"
            patron += "|LIKE|AND|OR|(?<space>[\s+|\r|\n|\t|\f])|\;|(?<err>\.+)"

            Dim mc As MatchCollection = Regex.Matches(tbCondiciones.Text, patron, RegexOptions.IgnoreCase)
            For Each m As Match In mc
                Dim lc As String = LCase(m.ToString)
                If m.ToString = ";" OrElse m.Groups("err").Success Then
                    tbMsg.Text = "error en las condiciones"
                    Return False
                ElseIf m.Groups("val").Success Then
                    'If m.ToString.Chars(0) = "'" Then
                    '    Dim e3 As String = Mid(m.ToString, 2, Len(m.ToString) - 2)
                    '    If IsNumeric(e3) Then
                    '        e1 += e3
                    '    Else
                    '        e1 += "'" + e3 + "'"
                    '    End If
                    'Else
                    'End If
                    If bEstotalD Then
                        Double.TryParse(m.ToString, Globalization.NumberStyles.Float, us, Me.importeDebeMayorA)
                        bEstotalD = False
                    ElseIf bEsTotalH Then
                        Double.TryParse(m.ToString, Globalization.NumberStyles.Float, us, Me.importeHaberMayorA)
                        bEsTotalH = False
                    Else
                        e1 += m.ToString ' un valor numérico
                    End If
                    GoTo sig
                ElseIf lc = "sum" OrElse lc = "len" Then
                    e1 += m.ToString
                    GoTo sig
                ElseIf lc = "subcuenta" Then
                    e1 += "diario.subcuenta"
                    GoTo sig
                ElseIf lc = "asiento" Then
                    e1 += "diario.asiento"
                    GoTo sig
                ElseIf lc = "contrapartida" Then
                    e1 += "diario.contrapartida"
                    GoTo sig
                ElseIf lc = "totaldebe" Then
                    bEstotalD = True
                    GoTo sig
                ElseIf lc = "totalhaber" Then
                    bEsTotalH = True
                    GoTo sig
                ElseIf lc = "debe" Then
                    e1 += "diario.debe"
                    GoTo sig
                ElseIf lc = "haber" Then
                    e1 += "diario.haber"
                    GoTo sig
                ElseIf lc = "factura" Then
                    e1 += "diario.factura"
                    GoTo sig
                ElseIf lc = "doc" Then
                    e1 += "diario.documento"
                    GoTo sig
                ElseIf lc = "titulo" Then
                    e1 += "subcuentas.titulo"
                    GoTo sig
                ElseIf lc = "concepto" Then
                    e1 += "diario.concepto"
                    GoTo sig
                ElseIf lc = "having" Then
                    e1 += " HAVING"
                    GoTo sig
                ElseIf m.Groups("eq").Success Then
                    If bEstotalD = False AndAlso bEsTotalH = False Then
                        e1 += m.ToString
                    End If
                    GoTo sig
                ElseIf m.ToString = "(" OrElse m.ToString = ")" OrElse _
                lc = "like" OrElse lc = "and" OrElse _
                lc = "or" OrElse m.ToString = "=" OrElse m.ToString = "<=" OrElse _
                m.ToString = "<" OrElse m.ToString = ">" OrElse m.ToString = ">=" Then
                    If bEstotalD = False AndAlso bEsTotalH = False Then
                        e1 += m.ToString
                    End If
                ElseIf m.Groups("space").Success Then
                Else
                    tbMsg.Text = "error en las condiciones"
                    Return False
                End If
                e1 += " "
sig:
            Next
            If Len(Trim(e1)) Then
                Dim e3() As String = Split(LCase(e1), "having")
                If e3.Length > 1 Then
                    e1 = e3(0)
                    Me.sHaving = " HAVING " + e3(1)
                    If InStr(tbCondiciones.Text, "sum(") Then
                        Dim m As Match = Regex.Match(e3(1), _
                            "(?<izq>[0-9\.]+)\s*(?<eq>[\>\<\=]+)\s*(?<sum>sum\([^\)]+\))" + _
                            "|(?<sum>sum\([^\)]+\))\s*(?<eq>[\>\<\=]+)\s*(?<dch>[0-9\.]+)")
                        If m.Success Then
                            'Me.sHaving = " HAVING "
                            If m.Groups("izq").Success Then
                                'Me.sHaving += m.Groups("izq").ToString + _
                                '    m.Groups("eq").ToString + _
                                '    m.Groups("sum").ToString
                                sMasDe300506 = m.Groups("izq").ToString
                            Else
                                'Me.sHaving += m.Groups("sum").ToString + _
                                'm.Groups("eq").ToString + _
                                'm.Groups("dch").ToString
                                sMasDe300506 = m.Groups("dch").ToString
                            End If
                        End If
                    End If
                End If
                e1 = e2 + " AND (" + e1 + ")"
            Else
                e1 = e2
            End If
            sql = e1
        Catch ex As Exception
            tbMsg.Text = ex.ToString
            Return False
        End Try
        Return True
    End Function

    Private Sub chkPdf_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkPdf.CheckedChanged
        If Not (chkPdf.Checked) <> chkXls.Checked Then
            chkXls.Checked = Not chkPdf.Checked
        End If
    End Sub

    Private Sub chkXls_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkXls.CheckedChanged
        If Not (chkPdf.Checked) <> chkXls.Checked Then
            chkPdf.Checked = Not chkXls.Checked
        End If
    End Sub

End Class
Public Class informesParam
    Public sEmp, sTitulo, desdeFch, hastaFch, moneda As String
    Public importeDebeMayorA As Double
    Public importeHaberMayorA As Double
    Public dt As System.Data.DataTable
    Dim oFchDesde, oFchHasta As DateTime
    Dim vProvDesde(-1), vProvHasta(-1) As String, iP As Int32
    Dim vCliDesde(-1), vCliHasta(-1) As String, iC As Int32
    Dim oEmp As es.nom.xrjunque.CEmp
    Dim sql As String
    Dim sOrderBy As String
    Dim sGroupBy As String
    Dim sSelect As String
    Dim sHaving As String
    Dim sWhere As String
    Public Sub New(ByVal oEmp As es.nom.xrjunque.CEmp, _
                    ByVal sEmp As String, _
                   ByVal sTitulo As String, _
                   ByVal desdeFch As String, _
                   ByVal hastaFch As String, _
                   ByVal oFchDesde As DateTime, _
                   ByVal oFchHasta As DateTime, _
                   ByVal moneda As String, _
                   ByVal sql As String, _
                   ByVal sSelect As String, _
                   ByVal sGroupBy As String, _
                   ByVal sOrderBy As String, _
                   ByVal sHaving As String, _
                   ByVal sWhere As String, _
                   Optional ByVal importeDebeMayorA As Double = 0.0, _
                   Optional ByVal importeHaberMayorA As Double = 0.0)
        Me.oEmp = oEmp
        Me.sEmp = sEmp
        Me.sTitulo = sTitulo
        Me.desdeFch = desdeFch
        Me.hastaFch = hastaFch
        Me.oFchDesde = oFchDesde
        Me.oFchHasta = oFchHasta
        Me.moneda = moneda
        Me.sql = sql
        Me.sSelect = sSelect
        Me.sGroupBy = sGroupBy
        Me.sOrderBy = sOrderBy
        Me.sHaving = sHaving
        Me.sWhere = sWhere
        Me.importeDebeMayorA = importeDebeMayorA
        Me.importeHaberMayorA = importeHaberMayorA
    End Sub
    Function getDataTables(ByVal usuario As es.nom.xrjunque.CUsuario, _
                           ByVal request As System.Web.HttpRequest) As DataTable
        Try
            dt = getAsientos(usuario, request)
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
        Return Me.dt
    End Function

    Private Function getAsientos(ByVal usuario As es.nom.xrjunque.CUsuario, _
                           ByVal request As System.Web.HttpRequest) As DataTable
        Dim objConn As OleDbConnection = Nothing
        Dim dt As System.Data.DataTable = Nothing
        Try
            Dim dataAdapter As New OleDbDataAdapter
            Dim sr1 As New es.nom.xrjunque.Service1
            Dim u As New ContaJunforWebService.CUsuario
            u.usuario = usuario.usuario
            u.contrasenya = usuario.contrasenya
            ''If Not ContaJunforWebService.CUsuario.Getcon(u) Then
            ''    Throw New Exception("Error, por favor, intente nuevamente.")
            ''End If
            'sr1.getDatosUsuario(usuario)
            'sr1.GetRutaContaJunfor(usuario)

            Dim sconn As String
            If request.IsLocal Then
                sconn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + _
                "E:\new\Agentia Junfor\ContaJunfor\basededatos CopiasSeguridad\ContaJunfor20130304.mdb"
            Else
                sconn = sr1.getConnContaJunfor(usuario)
            End If
            objConn = New OleDbConnection(sconn) '(System.Web.HttpContext.Current.Server.MapPath("\")))
            objConn.Open()
            Dim objAdapter As New OleDbDataAdapter
            Dim e1 As String = "SELECT diario.*,Subcuentas.titulo "
            e1 += " FROM Diario,Subcuentas "
            If Len(sSelect) Then
                e1 = sSelect
            End If
            e1 += " WHERE Diario.subcuenta=Subcuentas.subcuenta "
            'sql = Replace(sql, "AND  '20120101'<=diario.fecha  AND  diario.fecha<='20121231'", "")
            If Len(sWhere) Then
                e1 += " AND (" + sWhere + ")"
            End If
            sql = Regex.Replace(sql, "\s{2,}", " ")
            'sql = Replace(sql, "AND ( 0000000 <=diario.subcuenta AND diario.subcuenta <=9999999 )", "")
            'sql = Replace(sql, "AND ( 000000000000 <=diario.asiento AND diario.asiento <=999999999999 )", "")
            'sql = Replace(sql, "AND ( 000000000000 <=diario.factura AND diario.factura <=999999999999 )", " ")
            'sql = Replace(sql, "AND ( -999999999999 <=diario.debe AND diario.debe <=999999999999 )", "")
            'sql = Replace(sql, "AND ( -999999999999 <=diario.haber AND diario.haber <=999999999999 )", "")
            'sql = Replace(sql, "AND ( -999999999999 <=diario.documento AND diario.documento <=999999999999 )", "")
            'sql = Replace(sql, "AND ( subcuentas.titulo LIKE '%' )", "")
            'sql = Replace(sql, "AND ( diario.concepto LIKE '%' )", "")

            e1 += sql
            If Len(sGroupBy) Then
                e1 += " GROUP BY " + sGroupBy
                If Len(sHaving) Then
                    e1 += " " + sHaving
                End If
            End If
            If Len(sOrderBy) Then
                e1 += " ORDER BY " + sOrderBy
            End If
            e1 = Replace(e1, vbLf, "")
            e1 = Replace(e1, vbCr, "")
            e1 = Replace(e1, "  ", " ")
            e1 = Replace(e1, " <", "<")
            e1 = Replace(e1, " >", ">")
            e1 = Replace(e1, "= ", "=")

            Dim objCmdSelect As New OleDbCommand(e1, objConn)
            ' Fill the dataset.
            objAdapter.SelectCommand = objCmdSelect
            Dim ds = New DataSet
            Try
                objAdapter.Fill(ds, "Diario")
            Catch ex2 As Exception
                Throw New Exception(ex2.ToString)
            Finally
                objAdapter.Dispose()
            End Try
            If ds.Tables.Count = 0 Then
                Exit Try
            End If
            dt = ds.Tables(0)
            objAdapter.Dispose()
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        Finally
            Try
                objConn.Close()
            Catch ex2 As Exception
            End Try
        End Try
        Return dt
    End Function
End Class