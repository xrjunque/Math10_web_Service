﻿Imports Microsoft.Office.Interop
Imports System.IO


Public Class Prov300506Xls
    Dim us As New Globalization.CultureInfo("en-US")
    Dim fontNameHead As String = "Arial Narrow"
    Dim fontSizeHead As Single = 11.0
    Dim fontNameBody As String = "Arial Narrow"
    Dim fontSizeBody As Single = 11
    Dim curPage As Int32 = 0
    Dim totalPages As Int32 = 0
    Dim curLine As Int32 = 0
    Dim linesPerPage As Int32 = 6
    Dim curRow As Int32 = 0
    Dim curExcelRow As Int32 = 0
    Dim ancho As Single = cmToPixels(19.03)
    Dim alto As Single = cmToPixels(1.85)
    Dim anchoLnInterior As Single = cmToPixels(18.21)
    Dim altoTxt As Single = 20.0
    Dim vMargin As Single = (alto - 2 * altoTxt) / 2
    Dim txtIndent As String = 5
    Dim margin As Single
    Dim oParam As informesParam
    Dim totalHaber As Double = 0.0
    Dim totalDebe As Double = 0.0
    Dim totalSubcuentaH As Double = 0.0
    Dim totalSubcuentaD As Double = 0.0
    Dim totalIntracomunitarias As Double = 0.0, totalNoIntraCom As Double = 0.0
    Dim posTitulos() As Single
    Dim posCampos() As Single
    Dim oMissing As Object = System.Reflection.Missing.Value
    Dim colImpte As Int32 = 3
    Dim LineaEncabezados1() As String = {"Titulo", _
                                      "Domicilio", _
                                       "Cód.Postal", _
                                       "Haber"}
    Dim LineaEncabezados2() As String = {"Población", _
                                       "Provincia", _
                                       "nif"}
    Dim LineaCampos1() As String = {"titulo", _
                                      "domicilio", _
                                       "codPostal", _
                                       "total"}
    Dim LineaCampos2() As String = {"poblacion", _
                                      "provincia", _
                                      "nif"}
    Dim tipoEsString1() As Boolean = {True, _
                                     True, _
                                     True, _
                                     False}
    Dim tipoEsString2() As Boolean = {True, _
                                     True, _
                                     True}
    Dim nomFileInput As String = "xmlInformes.txt"
    Dim nomFileInput2 As String = "xmlInformes2.txt"
    Dim inFs As FileStream
    Dim inSr As StreamReader
    Dim isLocal As Boolean
    Dim MyMappath As String = ""
    Public sOut2 As String
    Dim posInExcelOfRowCount As Int32
    Dim subcuentaOld As Int32 = -1
    Dim nomTempFileXLS As String
    Public nomTempFileXLS2 As String
    Dim fsXLS As FileStream
    Dim wrXLS As StreamWriter

    Public Sub New( _
            ByVal oParam As informesParam, ByVal isLocal As Boolean, _
                Optional ByVal mappath As String = "")
        Try
            Me.isLocal = False ' isLocal
            Me.oParam = oParam
            Dim inNomFile As String = ""
            Dim i As Int32
            If isLocal Then
                inNomFile = _
                 "E:\new\Agentia Junfor\ContaJunfor\ContaJunfor2\ContaJunforWebService\InformesAgentia\" + _
                 nomFileInput
                nomTempFileXLS = IO.Path.GetTempFileName
                fsXLS = New FileStream(nomTempFileXLS, FileMode.OpenOrCreate, FileAccess.ReadWrite)
                wrXLS = New StreamWriter(fsXLS)
            Else
                Dim pos As Int32 = InStr(mappath, "xrjunque\")
                pos = InStr(pos, mappath, "\")
                Me.MyMappath = Mid(mappath, 1, pos) + "database\agentia\" ' "C:\sites\premium2\xrjunque\database\agentia\"
                Dim rnd As New Random
                inNomFile = Me.MyMappath + nomFileInput
                inNomFile = Replace(inNomFile, "\\", "\")
                nomTempFileXLS = Me.MyMappath
                nomTempFileXLS = Replace(nomTempFileXLS, "\\", "\")
                nomTempFileXLS += (Math.Floor(rnd.NextDouble * 10 ^ 6)).ToString + ".xml"
                fsXLS = New FileStream(nomTempFileXLS, FileMode.OpenOrCreate, FileAccess.Write)
                wrXLS = New StreamWriter(fsXLS)
            End If
            inFs = New FileStream(inNomFile, FileMode.Open, FileAccess.Read)
            inSr = New StreamReader(inFs)
            Dim e1 As String = inSr.ReadToEnd
            inSr.Close()
            inFs.Close()
            e1 = Replace(e1, vbCrLf, vbLf)
            e1 = Replace(e1, vbLf, vbCrLf)
            Dim e2() As String = Split(e1, vbLf)
            For i = 0 To e2.Length - 1
                sOut(i, e2(i))
            Next
            curExcelRow = e2.Length - 1
            AddLine()
            sOut(curExcelRow, " <Worksheet ss:Name=""" + oParam.sTitulo + """>")
            AddLine()
            Dim colsWidth() As Int32 = {155, 125, 50, 80}
            sOut(curExcelRow, "  <Table ss:ExpandedColumnCount=""" + _
                (colsWidth.Length).ToString + """ ss:ExpandedRowCount=""" + _
                "@rowcount@" + """ x:FullColumns=""1""")
            posInExcelOfRowCount = curExcelRow
            sOut(curExcelRow, " x:FullRows=""1"" ss:DefaultColumnWidth=""60"" ss:DefaultRowHeight=""15"">")
            For i = 0 To colsWidth.Length - 1
                AddLine()
                sOut(curExcelRow, Replace( _
                    "   <Column ss:Width=""42""/>", _
                    "42", _
                    colsWidth(i).ToString))
            Next
            AddLine()
            sOut(curExcelRow, "   <Row>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:Index=""1""><Data ss:Type=""String"">")
            sOut(curExcelRow, oParam.sEmp + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">Fecha:</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62"">")
            sOut(curExcelRow, "    <Data ss:Type=""DateTime"">" + _
            String.Format("{0:yyyy-MM-dd}T00:00:00.000", Now) + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "   </Row>")
            AddLine()
            sOut(curExcelRow, "   <Row>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:Index=""1""><Data ss:Type=""String"">" + _
                 oParam.sTitulo + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "   </Row>")
            AddLine()
            sOut(curExcelRow, "   <Row>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:Index=""4""><Data ss:Type=""String"">Moneda: " _
                 + oParam.moneda + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "   </Row>")

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub sOut(ByVal i As Int32, ByVal txt As String)
        'If i >= sOut2.Length Then
        'ReDim Preserve sOut2(i)
        'End If
        'If sOut2(i) Is Nothing Then
        'sOut2(i) = New StringBuilder(txt)
        'Else
        sOut2 += txt
        'End If
    End Sub
    Private Sub AddLine()
        If InStr(sOut2, vbCrLf) = 0 Then
            sOut2 += vbCrLf
        End If
        wrXLS.Write(sOut2)
        sOut2 = ""
        curExcelRow += 1
        'ReDim Preserve sOut(curExcelRow)
    End Sub
    Private Sub Header()
        Try

            AddLine()
            sOut(curExcelRow, "   <Row>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">Desde:</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62"">")
            sOut(curExcelRow, "    <Data ss:Type=""String"">" + _
                 oParam.desdeFch + "</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">Hasta:</Data></Cell>")
            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s62"">")
            sOut(curExcelRow, "    <Data ss:Type=""String"">" + _
                 oParam.hastaFch + "</Data></Cell>")
            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">Moneda:</Data></Cell>")
            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s62""><Data ss:Type=""String"">€</Data></Cell>")
            'AddLine()
            sOut(curExcelRow, "   </Row>")
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub LineaDoColumnsHeader()
        Try
            Dim e1 As String = ""

            AddLine()
            sOut(curExcelRow, "   <Row>")

            For i = 0 To Me.LineaEncabezados1.Length - 1
                AddLine()
                sOut(curExcelRow, "    <Cell ss:StyleID=""s64"">" + _
                        "<Data ss:Type=""String"">" + _
                        Me.LineaEncabezados1(i) + "</Data></Cell>")
            Next
            AddLine()
            sOut(curExcelRow, "   </Row>")

            AddLine()
            sOut(curExcelRow, "   <Row>")

            For i = 0 To Me.LineaEncabezados2.Length - 1
                AddLine()
                sOut(curExcelRow, "    <Cell ss:StyleID=""s64"">" + _
                        "<Data ss:Type=""String"">" + _
                        Me.LineaEncabezados2(i) + "</Data></Cell>")
            Next
            AddLine()
            sOut(curExcelRow, "   </Row>")

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub LineaNext()
        Try
            Dim subcuentaCur As Int32 = _
                        Me.oParam.dt.Rows(curRow).Item("subcuenta")

            If subcuentaCur <> subcuentaOld AndAlso subcuentaOld > 0 Then
                Me.totalSubcuenta()
            End If

            If subcuentaCur <> subcuentaOld Then
                'LineaDoColumnsHeader()
            End If
            Dim col As Int32
            Dim iv As Int32 = 0

            AddBlankRow()


            AddLine()
            sOut(curExcelRow, "   <Row>")

            Dim e1 As String = ""

            For col = 0 To LineaCampos1.Length - 1
                ' dato columna "i":
                Dim nom As String = LineaCampos1(col)


                'If Array.IndexOf(noCeros, LCase(nom)) > -1 AndAlso e1 = "0" Then
                'e1 = ""
                'If LCase(nom) = "fecha" Then
                '    e1 = Mid(e1, 7, 2) + "/" + Mid(e1, 5, 2) + "/" + Mid(e1, 1, 4)
                'ElseIf (col - 2) * (col - 3) * (col - 4) = 0 AndAlso e1 = "0" Then
                '    e1 = ""
                'End If
                AddLine()
                If tipoEsString1(col) = False Then
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, True)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + e1 + "</Data></Cell>")
                Else
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, False)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""String"">" + e1 + "</Data></Cell>")
                End If
            Next
            AddLine()
            sOut(curExcelRow, "   </Row>")


            AddLine()
            sOut(curExcelRow, "   <Row>")

            Dim bEsIntracomunitaria As Boolean = False
            Dim vIntracomunitarias() As String = {"fr", "gb"}
            For col = 0 To LineaCampos2.Length - 1
                ' dato columna "i":
                Dim nom As String = LineaCampos2(col)
                If LCase(nom) = "nif" Then
                    Dim nif As String = LCase(Me.oParam.dt.Rows(curRow).Item(nom))
                    For iVI As Int32 = 0 To vIntracomunitarias.Length - 1
                        If InStr(nif, vIntracomunitarias(iVI)) > 0 Then
                            bEsIntracomunitaria = True
                            Exit For
                        End If
                    Next
                End If


                'If Array.IndexOf(noCeros, LCase(nom)) > -1 AndAlso e1 = "0" Then
                'e1 = ""
                'If LCase(nom) = "fecha" Then
                '    e1 = Mid(e1, 7, 2) + "/" + Mid(e1, 5, 2) + "/" + Mid(e1, 1, 4)
                'ElseIf (col - 2) * (col - 3) * (col - 4) = 0 AndAlso e1 = "0" Then
                '    e1 = ""
                'End If
                AddLine()
                If tipoEsString2(col) = False Then
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, True)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + e1 + "</Data></Cell>")
                Else
                    e1 = Me.supressCrLfAndTab( _
                            Me.oParam.dt.Rows(curRow).Item(nom).ToString, False)
                    sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""String"">" + e1 + "</Data></Cell>")
                End If
            Next

            ' Saldo:
            'Dim D As Double = Math.Round(Me.oParam.dt.Rows(curRow).Item("debe"), 2)
            Dim H As Double = Math.Round(Me.oParam.dt.Rows(curRow).Item("total"), 2)
            'e1 = Me.supressCrLfAndTab(H, False)
            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + e1 + "</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "   </Row>")

            Me.subcuentaOld = subcuentaCur
            'Me.totalSubcuentaD += Math.Round(Me.oParam.dt.Rows(curRow).Item("debe"), 2)
            Me.totalSubcuentaH += Math.Round(Me.oParam.dt.Rows(curRow).Item("total"), 2)
            If bEsIntracomunitaria Then
                Me.totalIntracomunitarias += Math.Round(Me.oParam.dt.Rows(curRow).Item("total"), 2)
            Else
                Me.totalNoIntraCom += Math.Round(Me.oParam.dt.Rows(curRow).Item("total"), 2)
            End If
            curRow += 1
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub totalSubcuenta()
        Try
            'Dim colDebe As Int32 = Array.IndexOf(Me.LineaEncabezados, "Debe")
            'Dim iv As Int32 = 0

            'AddLine()
            'sOut(curExcelRow, "   <Row>")

            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:Index=""" + (colDebe).ToString _
            '        + """><Data ss:Type=""String"">" + _
            '            "Total asiento:</Data></Cell>")

            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
            '           Me.supressCrLfAndTab(totalSubcuentaD, True) + "</Data></Cell>")
            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
            '           Me.supressCrLfAndTab(totalSubcuentaH, True) + "</Data></Cell>")
            'Dim e1 As String = ""
            'Dim D As Double = Math.Round(Me.totalSubcuentaD, 2)
            'Dim H As Double = Math.Round(Me.totalSubcuentaH, 2)
            'e1 = Me.supressCrLfAndTab(D - H, False)
            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + e1 + "</Data></Cell>")

            'AddLine()
            'sOut(curExcelRow, "   </Row>")

            'AddBlankRow()

            'Me.totalDebe += totalSubcuentaD
            Me.totalHaber += totalSubcuentaH

            totalSubcuentaD = 0.0
            totalSubcuentaH = 0.0
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub totalDiario()
        Try
            Dim colHaber As Int32 = Array.IndexOf(Me.LineaCampos1, "total")

            AddLine()
            sOut(curExcelRow, "   <Row>")

            AddLine()
            sOut(curExcelRow, "    <Cell  ss:Index=""" + (colHaber).ToString _
                    + """><Data ss:Type=""String"">Total:</Data></Cell>")

            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + _
            '           Me.supressCrLfAndTab(totalDebe, True) + "</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(totalHaber, True) + "</Data></Cell>")

            'Dim e1 As String = ""
            'Dim D As Double = Math.Round(Me.totalDebe, 2)
            'Dim H As Double = Math.Round(Me.totalHaber, 2)
            'e1 = Me.supressCrLfAndTab(D - H, False)
            'AddLine()
            'sOut(curExcelRow, "    <Cell ss:StyleID=""s66""><Data ss:Type=""Number"">" + e1 + "</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "   </Row>")

            AddBlankRow()



            ' TOTAL INTRACOMUNITARIAS

            AddLine()
            sOut(curExcelRow, "   <Row>")

            sOut(curExcelRow, "    <Cell  ss:Index=""3"">" _
                    + "<Data ss:Type=""String"">Comunitarias:</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(Me.totalIntracomunitarias, True) + "</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "   </Row>")


            ' TOTAL NO Intracomun.

            AddLine()
            sOut(curExcelRow, "   <Row>")

            AddLine()
            sOut(curExcelRow, "    <Cell  ss:Index=""3"">" _
                    + "<Data ss:Type=""String"">NO comun.:</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(Me.totalNoIntraCom, True) + "</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "   </Row>")


            ' TOTAL Intracomun.+No Intracomun.

            AddLine()
            sOut(curExcelRow, "   <Row>")

            AddLine()
            sOut(curExcelRow, "    <Cell  ss:Index=""3"">" _
                    + "<Data ss:Type=""String"">Total:</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "    <Cell ss:StyleID=""s65""><Data ss:Type=""Number"">" + _
                       Me.supressCrLfAndTab(Me.totalIntracomunitarias + Me.totalNoIntraCom, True) + "</Data></Cell>")

            AddLine()
            sOut(curExcelRow, "   </Row>")


            AddBlankRow()

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Function supressCrLfAndTab(ByVal o As Object, _
                                       ByVal bDecimales As Boolean) As String
        Dim e1 As String = ""
        Try
            If o Is Nothing OrElse o Is DBNull.Value Then
                e1 = ""
            ElseIf IsNumeric(o) Then
                Dim db As Double
                If Not Double.TryParse(o, db) Then
                    e1 = o.ToString
                ElseIf bDecimales Then
                    db = Math.Round(db, 2)
                    e1 = String.Format(us, "{0:##,###,##0.00}", db)
                Else
                    e1 = o.ToString ' db.ToString(us)
                End If
            Else
                e1 = o.ToString
                If Len(e1) Then
                    e1 = Replace(e1, vbCr, "")
                    e1 = Replace(e1, vbLf, "")
                    e1 = Replace(e1, "@", "")
                    e1 = Replace(e1, vbTab, " ")
                End If
                o = e1
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Return e1
    End Function
    Sub AddBlankRow()
        AddLine()
        sOut(curExcelRow, "   <Row>")
        AddLine()
        sOut(curExcelRow, "    <Cell ss:Index=""1""><Data ss:Type=""String"">" + _
                        " </Data></Cell>")
        AddLine()
        sOut(curExcelRow, "   </Row>")
    End Sub
    Sub AddBlankCell()
        AddLine()
        sOut(curExcelRow, "    <Cell><Data ss:Type=""String"">" + _
                        " </Data></Cell>")
    End Sub

    Public Sub Show()
        Try
            Header()
            LineaDoColumnsHeader()
            Dim nRows As Int32 = oParam.dt.Rows.Count
            Do While curRow < nRows
                LineaNext()
            Loop
            totalSubcuenta()
            totalDiario()
            'Me.wrXLS.Close()
            'fsXLS.Close()
            'fsXLS=New FileStream(Me.nomTempFileXLS ,FileMode.Open ,FileAccess.ReadWrite 
            'Dim filasExcel As Int32 = 0
            'For i As Int32 = 0 To sOut2.Length - 1
            '    If InStr(LCase(sOut2(i).ToString), "<row") Then
            '        filasExcel += 1
            '    End If
            'Next
            'sOut2(Me.posInExcelOfRowCount).Replace( _
            '            "rowsCount", _
            '            filasExcel)
            '4 + cliParam.dt.Rows.Count + _
            '0 + 1)
            AddLine()
            sOut(curExcelRow, "  </Table>")
            Dim bFin As Boolean = True
            AddLine()
            sOut(curExcelRow, " </Worksheet>")
            AddLine()
            sOut(curExcelRow, "</Workbook>")
            AddLine()
            wrXLS.Close()
            fsXLS.Close()
            System.Threading.Thread.Sleep(200)
            inFs = New FileStream(Me.nomTempFileXLS, FileMode.Open, FileAccess.Read)
            inSr = New StreamReader(inFs)
            Dim rnd As New Random
            nomTempFileXLS2 = Replace(nomTempFileXLS, ".", "2.")
            fsXLS = New FileStream(Me.nomTempFileXLS2, FileMode.OpenOrCreate, FileAccess.ReadWrite)
            Me.wrXLS = New StreamWriter(fsXLS)
            Dim e1 As String = ""
            nRows = 0
            Do While Not inSr.EndOfStream
                e1 = inSr.ReadLine
                If InStr(e1, "<Row") Then
                    nRows += 1
                End If
            Loop
            inSr.Close()
            inFs.Close()
            inFs = New FileStream(Me.nomTempFileXLS, FileMode.Open, FileAccess.Read)
            inSr = New StreamReader(inFs)
            fsXLS.Seek(0, SeekOrigin.Begin)
            Do While Not inSr.EndOfStream
                e1 = inSr.ReadLine
                If InStr(e1, "@rowcount@") Then
                    e1 = Replace(e1, "@rowcount@", nRows.ToString)
                    wrXLS.WriteLine(e1)
                    Exit Do
                End If
                wrXLS.WriteLine(e1)
            Loop
            Do While Not inSr.EndOfStream
                e1 = inSr.ReadLine
                wrXLS.WriteLine(e1)
            Loop
            wrXLS.Close()
            fsXLS.Close()
            inSr.Close()
            inFs.Close()
            inSr.Close()
            inFs.Close()
            Try
                IO.File.Delete(nomTempFileXLS)
            Catch ex As Exception

            End Try
        Catch ex As Exception
            Throw ex
        Finally
            Me.wrXLS.Close()
            fsXLS.Close()
        End Try
    End Sub
    Private Function cmToPixels(ByVal cm As Single) As Single
        Return cm * 29.14
    End Function

End Class

