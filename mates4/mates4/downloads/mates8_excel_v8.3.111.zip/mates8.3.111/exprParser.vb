﻿Imports System.Text.RegularExpressions

<Serializable()> _
Public Class exprParser
    Private Sub New()
        MyBase.New()
    End Sub

    Public cur As currentMatch
    Public ret As retMtx
    Dim vars As VarsAndFns
    Dim msgHTML1 As String
    Public bIsEquation As Boolean = False
    Dim retIsMtx As Boolean = False
    Dim parent As matrixParser
    Dim bIsIntegralSequence As Boolean = False
    Friend cfg As Config '= Config.cfg
    Dim posChgSgn As Int32

    Public Sub New(cfg As Config)
        MyBase.New()
        Me.cfg = cfg
    End Sub

    Public Sub New(ByVal parent As matrixParser, _
                   ByVal sExpression As String, _
                   ByVal sVars As String, _
                   ByVal cfg As Config, _
                   Optional ByRef vars As VarsAndFns = Nothing)
        Try
            Me.parent = parent
            cur = New currentMatch()
            cur.cfg = cfg
            cur.parseCurMatch(sExpression, vars, cfg)
            parent.cur = cur
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function tryParse(ByVal sExpression As String, _
                                    ByVal sVars As String, _
                            ByRef result As exprParser, _
                            ByRef msg As String, _
                            Optional ByRef vars As VarsAndFns = Nothing, _
                            Optional ByVal bDoParse As Boolean = True) As Boolean
        Dim ret As Boolean = False
        Try
            '' supress leading and trailing white spaces:
            'sExpression = Regex.Replace(sExpression, "(^(\+|\s)+)|((" + _
            '         MathGlobal8.sCol + "|" + MathGlobal8.sRow + "|\s+)$)", "")
            If sExpression Is Nothing OrElse _
            sExpression.Length = 0 Then
                Return False
            End If
            If vars Is Nothing Then
                VarsAndFns.parseVariables(cfg, sVars, vars)
                If Len(sVars) Then
                    Dim e1() As String = Split(sVars, vbLf)
                    Dim name As String = ""
                    For i = 0 To e1.Length - 1
                        vars.tryGetVarNameByID(i, name)
                        If Len(name) AndAlso _
                        vars.replaceVarsReferences(name) Then
                            msg = String.Format(msg8.num(19), name)
                            Return False
                        End If
                    Next
                End If
            Else
                vars = vars
            End If
            If vars Is Nothing Then
                vars = New VarsAndFns(cfg)
            End If
            Me.vars = vars
            cur = New currentMatch()
            If bDoParse Then
                cur.parseCurMatch(sExpression, vars, cfg)
                Me.ret = nextExpr() ' 2013/08/07 added 'me.ret'=...
            Else
                cur = New currentMatch()
            End If
            'cur.verifyLR()
            ret = True
        Catch ex As Exception
            msg = ex.Message
            msgHTML1 = ex.Message
        Finally
            msgHTML1 = cur.msg
        End Try
        Return ret
    End Function
    Public Sub parse(ByVal sExpression As String, _
                                 ByVal sVars As String, _
                                 Optional ByRef vars As VarsAndFns = Nothing, _
                                 Optional ByVal bDoParse As Boolean = True) 'As exprParser
        Try
            Dim msg As String = ""
            If Not tryParse(sExpression, sVars, Me, msg, vars, _
                             bDoParse) Then
            End If
        Catch ex As Exception
        End Try
    End Sub
    Public ReadOnly Property msgHTML As String
        Get
            Return msgHTML1
        End Get
    End Property
    Public Property getParent As matrixParser
        Get
            Return parent
        End Get
        Set(ByVal value As matrixParser)
            parent = value
        End Set
    End Property
    Public Property getVars() As VarsAndFns
        Get
            Return vars
        End Get
        Set(ByVal value As VarsAndFns)
            vars = value
        End Set
    End Property
    Public Function nextExpr(Optional maxCols As Int32 = 0) As retMtx ' expression treatment
        Dim curNCol As Int32 = 0
        Dim retA As retMtx = Nothing
        Dim rMtx As retMtx = Nothing
        Try
            retIsMtx = False
            rMtx = New retMtx(Me)

            Do While Not cur.bEnd
                retA = nextTerm()
                Do While Not cur.bEnd AndAlso _
                (cur.subT2 = currentMatch.exprSubType2.add OrElse _
                cur.subT2 = currentMatch.exprSubType2.subs)
                    Dim iCur As Int32 = cur.iCur
                    Dim subT2 As currentMatch.exprSubType2 = cur.subT2
                    Dim retB As retMtx = nextTerm()
                    If retB Is Nothing OrElse retB.curExpr Is Nothing Then
                        Throw New msg8B(cur, 6, cur.vsErr(0))
                    ElseIf cur.m.Groups("integral").Success Then
                        Exit Do
                    End If
                    If cfg.bDetail AndAlso Not retA.isMatrix _
                    AndAlso Not retB.isMatrix Then
                        cur.toStrAndInsertMsg( _
                         retA.curExpr, retB.curExpr, subT2, True)
                    End If
                    If subT2 = currentMatch.exprSubType2.add Then
                        If Not retA.isMatrix AndAlso Not retB.isMatrix Then
                            retA.curExpr = retA.curExpr + retB.curExpr
                        ElseIf retA.isMatrix AndAlso retB.isMatrix Then
                            retA.exprMtx = retA.exprMtx + retB.exprMtx
                        ElseIf retA.isMatrix Then
                            retA.exprMtx = retA.exprMtx + retB.curExpr
                        Else
                            retA.exprMtx = retA.curExpr + retB.exprMtx
                        End If
                    Else
                        If Not retA.isMatrix AndAlso Not retB.isMatrix Then
                            retA.curExpr = retA.curExpr - retB.curExpr
                        ElseIf retA.isMatrix AndAlso retB.isMatrix Then
                            retA.exprMtx = retA.exprMtx - retB.exprMtx
                        ElseIf retA.isMatrix Then
                            retA.exprMtx = retA.exprMtx - retB.curExpr
                        Else
                            retA.exprMtx = retA.curExpr - retB.exprMtx
                        End If

                    End If
                    If cfg.bDetail AndAlso Not retA.isMatrix _
                    AndAlso Not retB.isMatrix Then
                        cur.toStrAndInsertMsg(retA.curExpr, Nothing, 0, False)
                    End If
                Loop
                If retA.rows + retA.cols = 2 Then
                    'Dim rV As New retVal(retA.curExpr, retA.curDer, vars)
                    If retA.curExpr IsNot Nothing Then
                        'Dim rV As New retVal(retA.curExpr, Nothing, vars)
                        Dim rV As New retVal(retA.curExpr, vars)
                        rMtx.setRetVal(rV)
                    ElseIf Not (Me.cur.subT1 = currentMatch.exprSubType1.mtxFn OrElse _
                    Me.cur.tipo = currentMatch.exprType.integralRespVar OrElse _
                    cur.subT2 = currentMatch.exprSubType2.integral) Then
                        Dim e1 As String = cur.toStrCurMatch("", False, False)
                        e1 = Regex.Split(e1, MathGlobal8.sRow)(0)
                        Dim pos As Int32
                        If parent IsNot Nothing Then
                            currentMatch.checkParentheses(cfg, e1, True, parent.errMsg, pos)
                        Else
                            Dim msg As String = String.Empty
                            currentMatch.checkParentheses(cfg, e1, True, msg, pos)
                            Throw New Exception(msg)
                        End If
                    End If
                ElseIf rMtx IsNot Nothing AndAlso rMtx.cols > 1 Then
                    Try
                        Dim curRow As Int32 = rMtx.rows - 1
                        Dim curcol As Int32 = rMtx.cols - 1
                        For col As Int32 = curcol To rMtx.cols + retA.cols - 2
                            'rMtx.setRetVal( _
                            '    New retVal( _
                            'retA.exprMtx.getExpr(curRow, col + 2 - curcol), _
                            'retA.DerMtx.getExpr(curRow, col + 2 - curcol), vars))
                            rMtx.setRetVal(New retVal( _
                                retA.exprMtx.getExpr(curRow, col + 2 - curcol), vars))
                            rMtx.incrCol()
                        Next
                    Catch ex As Exception
                        Throw New Exception(msg8.num(13)) ' n/a
                    End Try
                Else
                    rMtx = retA
                    If cur.m.Groups("row").Success Then
                        cur.doNext()
                    End If
                    Exit Do
                End If
                'If Me.cur.m.Groups("col").Success OrElse _
                'Me.cur.m.Groups("row").Success OrElse _
                'Me.cur.m.Groups("mtxOp").Success OrElse _
                'Me.cur.m.Groups("rp").Success Then
                If Me.cur.subT1 = currentMatch.exprSubType1.mtxFn OrElse _
                Me.cur.subT1 = currentMatch.exprSubType1.mtxOp OrElse _
                Me.cur.tipo = currentMatch.exprType.RP Then
                    Exit Do
                End If
                If cur.m.Groups("col").Success Then
                    curNCol += 1
                    If maxCols AndAlso curNCol >= maxCols Then
                        maxCols = 0
                        Exit Do
                    End If
                    If bIsIntegralSequence Then
                        'Exit Do    
                    End If
                    rMtx.incrCol()
                ElseIf cur.m.Groups("row").Success Then
                    If Not Me.bIsEquation Then
                        cur.fstVarName = ""

                    End If
                    If maxCols Then
                        Exit Do
                    End If
                    bIsIntegralSequence = False
                    rMtx.incrRow()
                    'End If
                ElseIf Me.cur.subT1 = currentMatch.exprSubType1.mtxFn OrElse _
                Me.cur.tipo = currentMatch.exprType.integralRespVar OrElse _
                cur.subT2 = currentMatch.exprSubType2.integral Then
                    Exit Do
                End If
            Loop
            If rMtx Is Nothing Then
                Throw New Exception(msg8.num(13))
            End If
        Catch ex As Exception
            If TypeOf (ex) Is NullReferenceException OrElse _
            ex.Message = "n/a" Then
                Dim e1 As String = cur.toStringCurMatch
                Throw New Exception(e1 + msg8.num(57))
            Else
                Throw ex
            End If
        End Try
        rMtx.cfg = cfg
        rMtx.exprMtx.cfg = cfg
        Return rMtx
    End Function
    Private Function nextTerm() As retMtx      ' term treatm.
        Dim retA As retMtx = Nothing
        Try
            retA = nextPower()
            Do While cur.subT2 = currentMatch.exprSubType2.mult OrElse _
            cur.subT2 = currentMatch.exprSubType2.div
                Dim iCur As Int32 = cur.iCur
                Dim subT2 As currentMatch.exprSubType2 = cur.subT2
                Dim retB As retMtx = nextPower()
                If retB Is Nothing OrElse retB.exprMtx Is Nothing Then
                    cur.iCur1 += 2
                    Throw New msg8B(cur, 6, cur.vsErr(0))
                ElseIf cur.m.Groups("integral").Success Then
                    Exit Try
                End If
                If cfg.bDetail AndAlso Not retA.isMatrix _
                AndAlso Not retB.isMatrix Then
                    cur.toStrAndInsertMsg( _
                     retA.curExpr, retB.curExpr, subT2, True)
                    cfg.cur = cur
                End If
                If subT2 = currentMatch.exprSubType2.mult Then
                    If Not retA.isMatrix AndAlso Not retB.isMatrix Then
                        retA.curExpr = retA.curExpr * retB.curExpr
                    Else
                        retA.exprMtx = retA.exprMtx * retB.exprMtx
                    End If
                Else ' division
                    If Not retA.isMatrix AndAlso Not retB.isMatrix Then
                        retA.curExpr = retA.curExpr / retB.curExpr
                    Else
                        retA.exprMtx = retA.exprMtx / retB.exprMtx
                    End If
                End If
                If cfg.bDetail AndAlso Not retA.isMatrix _
                AndAlso Not retB.isMatrix Then
                    cur.toStrAndInsertMsg(retA.curExpr, Nothing, 0, False)
                End If
            Loop
            If retA Is Nothing Then
                Throw New Exception(msg8.num(13))
            End If
        Catch ex As Exception
            Throw ex
        Finally
        End Try
        Return retA
    End Function
    Private Function nextPower() As retMtx
        Dim retA As retMtx = Nothing
        Dim sgn As Int32
        Try
            retA = nextFactor(sgn)
            If Not cur.bEnd Then
                If cur.subT2 = currentMatch.exprSubType2.pow Then
                    Dim iCur As Int32 = cur.iCur
                    Dim vExponent(0) As retMtx, irve As Int32 = 0
                    Dim vSgn(0), vpos(0) As Int32
                    Do
                        ReDim Preserve vExponent(irve), vSgn(irve), vpos(irve)
                        vpos(irve) = cur.iCur
                        vExponent(irve) = nextFactor(vSgn(irve))
                        If vExponent(irve) Is Nothing OrElse vExponent(irve).curExpr Is Nothing Then
                            Throw New msg8B(cur, 6, cur.vsErr(0))
                        End If
                        If cfg.bDetail AndAlso vSgn(irve) = -1 Then
                            cfg.oDetail.pop_iCur(cur)
                        End If
                        irve += 1
                    Loop While Not cur.bEnd AndAlso cur.str = "^"
                    vExponent(0).cfg = cfg
                    For i As Int32 = irve - 1 To 1 Step -1
                        If vExponent(i - 1).isMatrix Then
                            If vSgn(i) = -1 Then
                                vExponent(i - 1).exprMtx ^= -vExponent(i).exprMtx
                            Else
                                vExponent(i - 1).exprMtx ^= vExponent(i).exprMtx
                            End If
                        Else
                            If vSgn(i) = -1 Then
                                If cfg.bDetail Then
                                    cur.toStrAndInsertMsg( _
                                        vExponent(i - 1).curExpr, _
                                        -vExponent(i).curExpr, _
                                        currentMatch.exprSubType2.pow, True)
                                End If
                                vExponent(i - 1).curExpr ^= -vExponent(i).curExpr
                            Else
                                If cfg.bDetail Then
                                    cur.toStrAndInsertMsg( _
                                        vExponent(i - 1).curExpr, _
                                        vExponent(i).curExpr, _
                                        currentMatch.exprSubType2.pow, True)
                                End If
                                vExponent(i - 1).curExpr ^= vExponent(i).curExpr
                            End If
                            If cfg.bDetail Then
                                cur.toStrAndInsertMsg( _
                                    vExponent(i - 1).curExpr, _
                                    Nothing, 0, False)
                            End If
                        End If
                        'cfg.cur = cur
                        'vExponent(i - 1).cfg = cfg
                        If cfg.bDetail Then
                            'cfg.oDetail.pushOperator(cur, vpos(i), 2, _
                            '    vExponent(i - 1).curExpr.ToStringExpr(cfg))
                        End If
                    Next
                    If retA.isMatrix Then
                        If vSgn(0) = -1 Then
                            retA.exprMtx ^= -vExponent(0).exprMtx
                        Else
                            retA.exprMtx ^= vExponent(0).exprMtx
                        End If
                    Else
                        If vSgn(0) = -1 Then
                            If cfg.bDetail Then
                                cur.toStrAndInsertMsg( _
                                    retA.curExpr, _
                                    -vExponent(0).curExpr, _
                                    currentMatch.exprSubType2.pow, True)
                            End If
                            retA.curExpr ^= -vExponent(0).curExpr
                        Else
                            If cfg.bDetail Then
                                cur.toStrAndInsertMsg( _
                                    retA.curExpr, _
                                    vExponent(0).curExpr, _
                                    currentMatch.exprSubType2.pow, True)
                            End If
                            retA.curExpr ^= vExponent(0).curExpr
                        End If
                        If cfg.bDetail Then
                            cur.toStrAndInsertMsg( _
                                retA.curExpr, _
                                Nothing, 0, False)
                        End If
                    End If
                    If cfg.bDetail Then
                        'cfg.oDetail.pushOperator(cur, _
                        '    iCur, 2, _
                        '    retA.curExpr.ToStringExpr(cfg))
                    End If
                    'cfg.cur = cur
                    'retA.cfg = cfg
                    'retA.curExpr.cfg = cfg
                    'Exit Try
                    'ElseIf cur.subT1 = currentMatch.exprSubType1.logicalOp Then
                    '    Dim pos As Int32 = cur.iCur
                    '    Dim subT2 As currentMatch.exprSubType2 = cur.subT2
                    '    If Not retA.curExpr.IsReal Then
                    '        Dim ce As New currentMatch.curMatchErr
                    '        Throw ce.err(Nothing, cur, msg8.num(4), pos - 1)
                    '    End If
                    '    Dim opA As Double = retA.curExpr.getPolynomial.cf(0).pRe.ToDouble
                    '    Dim rvB As retMtx = Nothing
                    '    Dim opb As Double
                    '    If cur.subT2 <> currentMatch.exprSubType2.NOT Then
                    '        If cur.bEnd Then
                    '            Dim ce As New currentMatch.curMatchErr
                    '            Throw ce.err(Nothing, cur, msg8.num(4))
                    '        End If
                    '        Dim sgnB As Int32 = 1
                    '        pos = cur.iCur
                    '        rvB = nextFactor(sgnB)
                    '        If sgnB = -1 Then
                    '            rvB.curExpr = -rvB.curExpr
                    '        End If
                    '        If Not rvB.curExpr.IsReal Then
                    '            Dim ce As New currentMatch.curMatchErr
                    '            cur.imc = cur.iCur
                    '            Dim sCur As String = String.Empty
                    '            Try
                    '                sCur = cur.toStrCurMatch(cfg.outputFormat = outputMsgFormat.HTML)
                    '            Catch ex As Exception
                    '            End Try
                    '            Throw New Exception(msg8.num(13) + vbCrLf + sCur)
                    '        End If
                    '        opb = rvB.curExpr.getPolynomial.cf(0).pRe.ToDouble
                    '    Else
                    '    End If
                    '    If cfg.bDetail Then
                    '        cfg.oDetail.pop_iCur(cur)
                    '        cur.toStrAndInsertMsg( _
                    '        New Expression(opA), _
                    '        New Expression(opb), subT2, True)
                    '    End If

                    '    Dim opR As Double
                    '    Select Case subT2
                    '        Case currentMatch.exprSubType2.AND
                    '            opR = (opA And opb)
                    '        Case currentMatch.exprSubType2.OR
                    '            opR = (opA Or opb)
                    '        Case currentMatch.exprSubType2.NOT
                    '            opR = Not (opA)
                    '        Case currentMatch.exprSubType2.XOR
                    '            opR = (opA Xor opb)
                    '        Case currentMatch.exprSubType2.NOR
                    '            opR = Not (opA Or opb)
                    '        Case currentMatch.exprSubType2.NAND
                    '            opR = Not (opA And opb)
                    '    End Select
                    '    retA.curExpr = New Expression(opR)
                    '    If cfg.bDetail Then
                    '        cur.toStrAndInsertMsg(retA.curExpr, Nothing, 0, False)
                    '    End If
                End If
            End If
            If sgn = -1 Then
                retA.exprMtx = -retA.exprMtx
                If cfg.bDetail Then
                    cfg.oDetail.pop_iCur(cur)
                End If
                'If cfg.bDetail Then
                '    Dim pos2 As Int32 = cur.iCur - 1
                '    If cur.bEnd Then pos2 += 1
                '    cfg.oDetail.pushOperator(cur, posChgSgn, 1, _
                '        retA.curExpr.ToStringExpr(cfg), True)
                'End If
            End If
            If retA Is Nothing Then
                Throw New Exception(msg8.num(13))
            ElseIf cfg.bDetail Then
                'cur.toStrAndInsertMsg(retA.curExpr, Nothing, 0, False)
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Return retA
    End Function


    Private Function nextFactor(ByRef sgn As Int32, _
                                Optional bOnlyOpnd As Boolean = False) As retMtx ' factor treatm.
        Dim rMtx As New retMtx(Me)
        Dim bFst As Boolean = True
        Try
            sgn = 1
            Do
                Do
sig:
                    cur.doNext()
                    If cur.bEnd Then
                        Exit Try
                    ElseIf bFst AndAlso _
                    (cur.subT2 = currentMatch.exprSubType2.subs OrElse _
                    cur.subT2 = currentMatch.exprSubType2.add) Then
                        If cur.subT2 = currentMatch.exprSubType2.add Then
                        Else
                            If cfg.bDetail Then
                                cfg.oDetail.push_iCur(cur, cur.iCur)
                                posChgSgn = cur.iCur
                            End If
                            sgn *= -1
                        End If
                    ElseIf cur.subT2 = currentMatch.exprSubType2.factorial OrElse _
                    cur.subT2 = currentMatch.exprSubType2.modulo OrElse _
                    cur.subT1 = currentMatch.exprSubType1.logicalOp Then
                        Exit Do
                    ElseIf cur.tipo = currentMatch.exprType.op OrElse _
                    cur.subT1 = currentMatch.exprSubType1.mtxOp OrElse _
                    cur.tipo = currentMatch.exprType.RP OrElse _
                    cur.subT1 = currentMatch.exprSubType1.mtxFn OrElse _
                    cur.subT1 = currentMatch.exprSubType1.delimiter OrElse _
                    cur.tipo = currentMatch.exprType.integralRespVar Then
                        Exit Try
                    Else
                        Exit Do
                    End If
                Loop
                bFst = False
                If cfg.bDetail Then
                    cfg.oDetail.push_iCur(cur, cur.iCur)
                End If
                If cur.str = "!" Then
                    If rMtx Is Nothing OrElse rMtx.curExpr Is Nothing OrElse _
                    Not rMtx.curExpr.IsReal Then
                        Dim e1 As String = cur.toStrCurMatch
                        Throw New Exception(e1 + msg8.num(57))
                    End If
                    Dim db As Double = Math.Floor(rMtx.curExpr.toDouble)
                    If db = 0 Then
                        db = 1.0
                    Else
                        For i As Int32 = db - 1 To 2 Step -1
                            db *= CDbl(i)
                        Next
                    End If
                    rMtx.curExpr = New Expression(db)
                ElseIf cur.subT2 = currentMatch.exprSubType2.modulo AndAlso _
                    rMtx.curExpr IsNot Nothing Then
                    If rMtx.curExpr IsNot Nothing AndAlso _
                    rMtx.curExpr.IsReal Then
                        ' Real % PositiveInteger or
                        ' Real mod PositiveInteger  
                        Dim eMtx = nextExpr() ' capture argument
                        If Not eMtx.exprMtx.IsReal OrElse _
                        eMtx.exprMtx.toDouble <> Math.Floor(eMtx.exprMtx.toDouble) OrElse _
                        eMtx.exprMtx.toDouble < 1 Then
                            Throw New Exception(msg8.num(59)) ' arg. should be a positive integer
                        End If
                        Dim dbMod As Double = eMtx.curExpr.toDouble
                        Dim db As Double = rMtx.curExpr.toDouble
                        rMtx.curExpr = New Expression(db Mod dbMod)
                    ElseIf rMtx.curExpr.IsPolynomial Then
                        ' (Polynomial) % PositiveInteger, or
                        ' (Polynomial) mod PositiveInteger 
                        Dim eMtx = nextExpr() ' capture argument
                        If Not eMtx.exprMtx.IsReal OrElse _
                        eMtx.exprMtx.toDouble <> Math.Floor(eMtx.exprMtx.toDouble) OrElse _
                        eMtx.exprMtx.toDouble < 1 Then
                            If eMtx.curExpr.IsPolynomial Then
                                ' (Polynomial) % (Polynomial)
                                ' or (Polynomial) mod (Polynomial)
                                ' see "Modulo Reduction" in:
                                ' http://stackoverflow.com/questions/13202758/multiplying-two-polynomials

                                Dim modP As Polynomial = eMtx.curExpr.getPolynomial
                                Dim div As Polynomial = rMtx.curExpr.getPolynomial / modP
                                If cfg.bDetail Then
                                    cfg.oDetail.Add("(" + rMtx.curExpr.getPolynomial.toStringPoly(cfg) + ")/(" + _
                                                      modP.toStringPoly(cfg) + ") =")
                                    cfg.oDetail.Add("= " + div.toStringPoly(cfg))
                                    cfg.oDetail.Add("=> (" + rMtx.curExpr.getPolynomial.toStringPoly(cfg) + ")mod(" + _
                                                     modP.toStringPoly(cfg) + ") =")
                                End If
                                ' can't extract div.PolyResto directly because very probably
                                ' div.PolyResto and div.PolyDivisor have been reduced:
                                rMtx.curExpr = New Expression(div.PolyResto * modP / div.PolyDivisor)
                                ' in case division isn't accurate, assure there is no remainder:
                                rMtx.curExpr.getPolynomial.PolyResto = Nothing
                                rMtx.curExpr.getPolynomial.PolyDivisor = Nothing

                                If cfg.bDetail Then
                                    cfg.oDetail.Add("= (" + div.PolyResto.toStringPoly(cfg) + ")*(" + _
                                                     modP.toStringPoly(cfg) + ")/(" + div.PolyDivisor.toStringPoly(cfg) + ")")
                                    cfg.oDetail.Add("=" + rMtx.curExpr.getPolynomial.toStringPoly(cfg))
                                End If
                            Else
                                Throw New Exception(msg8.num(13)) ' n/a
                            End If
                        Else
                            Dim dbMod As Double = eMtx.curExpr.toDouble
                            Dim Pa As Polynomial = _
                                rMtx.curExpr.getPolynomial
                            Pa.dbModuloInOperations = dbMod
                            rMtx.curExpr = New Expression(Pa)
                        End If
                    End If
                    'Else
                    '    ' mod( complex )
                    '    rMtx = nextExpr() ' capture argument
                    '    Dim cjo As Complex = rMtx.curExpr.toComplex
                    '    rMtx.curExpr = New Expression(cjo.opModulo)
                    'End If


                ElseIf cur.tipo = currentMatch.exprType.LP Then
                    If Me.parent Is Nothing Then
                        rMtx = Me.nextExpr()
                    Else
                        rMtx = Me.parent.mtxExpr()
                    End If
                    If rMtx.isMatrix Then
                        cur.doNext()
                        Exit Do
                    End If
                    If cfg.bDetail Then
                        Dim bLast As Boolean = False
                        Dim vC(-1) As Int32, ivc As Int32 = -1
                        Do
                            ivc += 1
                            ReDim Preserve vC(ivc)
                            vC(ivc) = cfg.oDetail.pop_iCur(cur, bLast)
                        Loop While Not bLast AndAlso vC(ivc) < 1000
                        If ivc > 0 Then
                            'vC(ivc - 1) -= 1
                        End If
                        For j As Int32 = ivc - 1 To 0 Step -1
                            cfg.oDetail.push_iCur(cur, vC(j) - 1, False)
                        Next
                    End If
                ElseIf cur.tipo = currentMatch.exprType.num Then
                    rMtx.curExpr = New Expression(cur.curValue)
                    'ElseIf cur.str = "-" Then
                    '    ' current.m is unary "-", change sign
                    '    ' (by default cur.sgn= +1 )
                    '    sgn *= -1
                ElseIf cur.tipo = currentMatch.exprType.var Then

                    Dim varID As Int32 = -1
                    If cur.iAt < cur.oVarsAt.Length Then
                        ' input is for example x+3*y @ x=2; y=3
                        ' output should be 11 (=2+3*3)
                        Dim ID As Int32
                        If cur.oVarsAt(cur.iAt).tryGetVarIDByName(cur.str, ID) Then
                            Dim eM As ExprMatrix = _
                                cur.oVarsAt(cur.iAt).getValueByID(ID)
                            If eM IsNot Nothing Then
                                rMtx.exprMtx = eM
                            Else
                                rMtx.curExpr = Nothing
                            End If
                        End If
                    Else
                        Dim eM2 As ExprMatrix = vars.getValueByName( _
                            cur.str, False)
                        Dim sM2 As String = ""
                        If eM2 IsNot Nothing Then
                            Dim vVar() As String = eM2.getAllVars
                            If vVar.Length > 1 OrElse _
                            (vVar.Length = 1 AndAlso _
                             vVar(0) <> cur.str) Then
                                For row As Int32 = 0 To eM2.Rows - 1
                                    For col As Int32 = 0 To eM2.Cols - 1
                                        eM2.getExpr(row, col) = _
                                            eM2.getExpr(row, col).evalExprToExpr(vars)
                                    Next
                                Next
                            End If
                            rMtx = New retMtx(Me, eM2)
                        ElseIf vars IsNot Nothing AndAlso _
                        vars.tryfindVarWithValue(cur.str, varID) Then
                            Dim eM As ExprMatrix = vars.getValueByID(varID)
                            If eM IsNot Nothing Then
                                rMtx.curExpr = New Expression(eM)
                            Else
                                rMtx.curExpr = Nothing
                            End If
                        ElseIf varID = -1 Then
                            Dim msg As String = ""
                            Dim eM As ExprMatrix = Nothing
                            If Not vars.AddVar(cur.str, Nothing, msg) Then
                                varID = _
                                    Units.oVar.getVarIDByName(cur.str, False)
                                If varID = -1 Then
                                    Throw New Exception(msg)
                                End If
                            Else
                                varID = vars.getVarIDByName(cur.str)
                                eM = vars.getValueByID(varID)
                            End If
                            If eM IsNot Nothing Then
                                rMtx.curExpr = New Expression(eM)
                            Else
                                rMtx.curExpr = New Expression( _
                                    Polynomial.GetPolynomial(cur.str))
                            End If
                        End If
                    End If
                    If rMtx.curExpr Is Nothing Then
                        rMtx.curExpr = New Expression( _
                            Polynomial.GetPolynomial(cur.str))
                    End If

                ElseIf cur.tipo = currentMatch.exprType.Dx Then ' cur.m.Groups("Dx").Success Then
                    If cur.bIsEquation Then
                        cur.bIsDiffEq = True
                    End If
                    ' Derivative:
                    Dim nOrder As Int32 = cur.DxOrder
                    Dim sDet1 As String = "", sDet2 As String = ""
                    ' Retrive respect to var.:
                    Dim sRespVar As String = cur.m.Groups("resp").ToString
                    Dim varID As Int32
                    If sRespVar.Length = 0 Then
                        ' get the first variable's name
                        sRespVar = cur.fstVarName
                    End If
                    If vars.tryfindVarWithValue(sRespVar, varID) Then

                    ElseIf varID = -1 Then
                        Dim msg As String = ""
                        If Not vars.AddVar(sRespVar, Nothing, msg) Then
                            Throw New Exception(msg)
                        End If
                        varID = vars.getVarIDByName(sRespVar)
                    End If
                    rMtx.curExpr = New Expression(0.0)
                    cur.doNext()
                    If Not cur.m.Groups("lp").Success Then
                        ' expected an opening '('
                        Throw New Exception(String.Format( _
                            msg8.num(1), " '('"))
                    End If

                    Dim pos As Int32 = cur.iCur
                    If Me.parent Is Nothing Then
                        rMtx = Me.nextExpr()
                    Else
                        rMtx = Me.parent.mtxExpr()
                    End If
                    Dim sVar As String = vars.getVarNameByID(varID)
                    If cur.bIsDiffEq Then
                        Dim arg As New Expression(rMtx.curExpr)
                        rMtx.curExpr = Expression.AddFnAndArg0("diff", arg)
                        ReDim Preserve rMtx.curExpr.getArgs(2)
                        rMtx.curExpr.getArgs(1) = New Expression(Polynomial.GetPolynomial(sVar))
                        rMtx.curExpr.getArgs(2) = New Expression(nOrder)
                    Else
                        For i As Int32 = 1 To nOrder
                            If cfg.bDetail Then
                                sDet1 = "D" + sVar + "("
                                sDet1 += rMtx.curExpr.ToStringExpr(cfg) + ")"
                                cfg.oDetail.Add(sDet1 + " =")
                            End If
                            rMtx.exprMtx = rMtx.exprMtx.opDerivative(sVar)
                            If cfg.bDetail Then
                                sDet2 = rMtx.curExpr.ToStringExpr(cfg)
                                'cfg.oDetail.Add(sDet1 + " =")
                                cfg.oDetail.Add("= " + sDet2)
                            End If
                        Next
                        If cfg.bDetail Then
                            cfg.oDetail.ClearDivisions()
                        End If
                    End If

                ElseIf cur.subT1 = currentMatch.exprSubType1.oneElemFn OrElse _
                cur.subT2 = currentMatch.exprSubType2.modulo Then
                    'ElseIf cur.m.Groups("fn").Success Then

                    Dim mFn As Match = MathGlobal8.CloneMatch(cur.m)
                    Dim fn As String = LCase(cur.str)
                    Dim pos As Int32 = cur.iCur
                    'Dim fnSgn As Int32 = rMtx.sgn : rMtx.sgn = 1
                    Dim bDetall As Boolean = cfg.bDetail
                    'cfg.bDetail = False
                    Dim rmArg As retMtx = Nothing
                    Static sMtxFn() As String = _
                        New String() {"identity", "echelon", "cof", _
                                      "eigenvalues", "eigenvectors", _
                                      "transpose", "adj", _
                                      "trace", "roots", "rank", _
                                      "det", "jordan", _
                                      "factor", "jacobian", _
                                      "lagrangianinterpolation", "orthog", "lim", "mod"}
                    If Array.IndexOf(sMtxFn, fn) > -1 Then
                        Dim bLP As Boolean = False
                        Dim t As currentMatch.exprType
                        Dim st1 As currentMatch.exprSubType1
                        Dim st2 As currentMatch.exprSubType2
                        Dim nxtMatch As Match = cur.testNextMatch(1, t, st1, st2)
                        If t = currentMatch.exprType.LP Then
                            cur.doNext()
                            bLP = True
                            If parent IsNot Nothing Then
                                rmArg = parent.mtxExpr
                            Else
                                rmArg = nextExpr()
                            End If
                        Else
                            Dim sgn1 As Int32 = 1
                            rmArg = nextFactor(sgn1, True)
                            If sgn1 = -1 Then
                                rmArg.exprMtx = -rmArg.exprMtx
                            End If
                        End If
                        Select Case fn
                            Case "identity"
                                Dim rows As Int32 = rmArg.exprMtx.getExpr(0, 0).toDouble
                                Dim cols As Int32 = 0
                                If rmArg.exprMtx.Cols > 1 Then
                                    cols = rmArg.exprMtx.getExpr(0, 1).toDouble
                                End If
                                rMtx = New retMtx(Me, ExprMatrix.Identity(cfg, rows, cols))
                            Case "echelon" ' Echelon form
                                rMtx = New retMtx(Me, rmArg.exprMtx.opEchelonForm)
                            Case "cof" ' cofactor
                                Dim cof As ExprMatrix = Nothing
                                rmArg.exprMtx.opDeterminant(True, cofactorMtx:=cof)
                                rMtx = New retMtx(Me, cof)
                            Case "eigenvalues"
                                rMtx = New retMtx(Me, New ExprMatrix(rmArg.exprMtx.opEigenValues(False)))
                            Case "eigenvectors"
                                rMtx = New retMtx(Me, New ExprMatrix(rmArg.exprMtx.opEigenVectors))
                            Case "transpose"
                                rMtx = New retMtx(Me, ExprMatrix.opTranspose(rmArg.exprMtx))
                            Case "adj"
                                Dim adj As ExprMatrix = Nothing
                                rmArg.exprMtx.opDeterminant(True, adjoint:=adj)
                                rMtx = New retMtx(Me, adj)
                            Case "trace" ' 
                                rMtx = New retMtx(Me, rmArg.exprMtx.opTrace)
                            Case "roots"
                                Dim mtx As Matrix = Nothing
                                Try
                                    mtx = Polynomial.opRoots( _
                                        rmArg.exprMtx.getCurExpr.getPolynomial, _
                                        False, cfg).mtx
                                    If mtx Is Nothing Then
                                        Throw New Exception(msg8.num(13)) ' n/a
                                    End If
                                Catch ex As Exception
                                    Throw New Exception(msg8.num(13)) ' n/a
                                End Try
                                rMtx = New retMtx(Me, New ExprMatrix(mtx))
                            Case "mod"
                                If rmArg.cols = 1 Then
                                    rMtx = New retMtx(Me, New ExprMatrix(evalFn("mod", rmArg.curExpr.toComplex)))
                                Else
                                    Dim Tr As ExprMatrix = ExprMatrix.opTranspose(rmArg.exprMtx)
                                    rMtx = New retMtx(Me, rmArg.exprMtx * Tr)
                                    rMtx = New retMtx(Me, New ExprMatrix(rMtx.curExpr ^ New Expression(0.5)))
                                End If
                            Case "lim"
                                Dim sVar As String = String.Empty
                                Dim limit As New Expression(0.0)
                                If rmArg.cols < 2 Then
                                    Throw New Exception(msg8.num(57))
                                End If
                                If rmArg.cols > 2 Then
                                    sVar = rmArg.exprMtx.getExpr(0, 1).getPolynomial.var(0)
                                    limit = rmArg.exprMtx.getExpr(0, 2)
                                ElseIf rmArg.exprMtx.getExpr(0, 0).IsPolynomial Then
                                    sVar = rmArg.curExpr.getPolynomial.var(0)
                                    limit = rmArg.exprMtx.getExpr(0, 1)
                                Else
                                    sVar = "x"
                                    limit = rmArg.exprMtx.getExpr(0, 1)
                                End If
                                rMtx = New retMtx(Me, New ExprMatrix(rmArg.exprMtx.getExpr(0, 0).opLimit(sVar, limit)))
                            Case "rank"
                                rMtx = New retMtx(Me, New ExprMatrix(rmArg.exprMtx.opRank))
                            Case "det"
                                Dim eMtx As New ExprMatrix( _
                                    rmArg.exprMtx.opDeterminant)
                                rMtx = New retMtx(Me, eMtx)
                            Case "jordan"
                                Dim eMtx As New ExprMatrix( _
                                    rmArg.exprMtx.opJordanForm)
                                rMtx = New retMtx(Me, eMtx)
                            Case "factor"
                                Dim vect As Vector = rmArg.exprMtx.getVector(0)
                                Dim mtx As Matrix = Nothing
                                Try
                                    Dim Pc() As Polynomial = _
                                        Polynomial.opFactor(rmArg.exprMtx.getExpr(0, 0).getPolynomial, cfg)
                                    mtx = New Matrix
                                    ReDim mtx.vVect(Pc.Length - 1)
                                    For i As Int32 = 0 To Pc.Length - 1
                                        mtx.vVect(i) = New Vector(Pc(i))
                                    Next
                                    If mtx Is Nothing Then
                                        Throw New Exception(msg8.num(13)) ' n/a
                                    End If
                                Catch ex As Exception
                                    Throw New Exception(msg8.num(13)) ' n/a
                                End Try
                                rMtx = New retMtx(Me, New ExprMatrix(mtx))
                            Case "jacobian"
                                Dim eM As ExprMatrix = _
                                    rmArg.exprMtx.opJacobian(vars)
                                rMtx = New retMtx(Me, eM)
                            Case "lagrangianinterpolation"
                                Dim eMtx As ExprMatrix = rmArg.exprMtx
                                If eMtx.Cols > 3 Then
                                    ' lagrangianInterpolation(a,b,n,f(x))
                                    Dim intp As Interpolation = _
                                        Interpolation.getChebyshevNodes( _
                                        eMtx.getExpr(0, 0).toDouble, _
                                        eMtx.getExpr(0, 1).toDouble, _
                                        eMtx.getExpr(0, 2).toDouble, _
                                        eMtx.getExpr(0, 3))
                                    rMtx = New retMtx(Me, New ExprMatrix( _
                                        intp.lagrangianinterpolation(cfg, True)))
                                    If cfg.sesID > -1 Then
                                        Try
                                            C_session.xi(cfg.sesID) = eMtx.getExpr(0, 0).toDouble
                                            C_session.xf(cfg.sesID) = eMtx.getExpr(0, 1).toDouble
                                            C_session.sfn(cfg.sesID) = ret.exprMtx.getCurExpr.ToStringExpr(cfg)
                                            C_session.sf2(cfg.sesID) = eMtx.getExpr(0, 3).ToStringExpr(cfg)
                                            C_session.sf3(cfg.sesID) = ""
                                            C_session.yAuto(cfg.sesID) = 1
                                        Catch ex As Exception

                                        End Try
                                    End If
                                Else
                                    ' lagrangianInterpolation(x0,f(x0)|x1,f(x1)| ...|xn,f(xn))
                                    Dim lagrInt As New Interpolation(rmArg.exprMtx.getMatrix)
                                    rMtx = New retMtx(Me, New ExprMatrix( _
                                        lagrInt.lagrangianinterpolation(cfg, True)))
                                End If
                            Case "orthog"
                                Dim cjo As Complex = _
                                    Polynomial.opOrthog( _
                                    rmArg.exprMtx.getMatrix)
                                rMtx = New retMtx(Me, New ExprMatrix(cjo))
                        End Select
                    Else
                        Select Case fn
                            Case "norm"
                                cur.doNext() ' skip (
                                rmArg = nextExpr()
                                If rmArg.cols = 1 Then
                                    rMtx = New retMtx(Me, New ExprMatrix(evalFn("mod", rmArg.curExpr.toComplex)))
                                Else
                                    Dim vectA As ExprMatrix = New ExprMatrix(rmArg.exprMtx.getExprMtxFromRow(0))
                                    Dim vectB As ExprMatrix = Nothing
                                    If rmArg.rows = 1 Then
                                        rmArg = nextExpr()
                                        cur.doNext()
                                        vectB = New ExprMatrix(rmArg.exprMtx.getExprMtxFromRow(0))
                                    Else
                                        vectB = New ExprMatrix(rmArg.exprMtx.getExprMtxFromRow(1))
                                    End If
                                    Dim dist As ExprMatrix = vectA - vectB
                                    rMtx = New retMtx(Me, dist * ExprMatrix.opTranspose(dist))
                                    rMtx = New retMtx(Me, New ExprMatrix(rMtx.curExpr ^ New Expression(0.5)))
                                End If
                            Case "exp"
                                Dim bLP As Boolean = False
                                Dim t As currentMatch.exprType
                                Dim st1 As currentMatch.exprSubType1
                                Dim st2 As currentMatch.exprSubType2
                                Dim nxtMatch As Match = cur.testNextMatch(1, t, st1, st2)
                                If t = currentMatch.exprType.LP Then
                                    cur.doNext()
                                    bLP = True
                                    If parent IsNot Nothing Then
                                        rmArg = parent.mtxExpr
                                    Else
                                        rmArg = nextExpr()
                                    End If
                                Else
                                    Dim sgn1 As Int32 = 1
                                    rmArg = nextFactor(sgn1, True)
                                    If sgn1 = -1 Then
                                        rmArg.exprMtx = -rmArg.exprMtx
                                    End If
                                End If
                                If fn = "norm" Then

                                End If
                                If rmArg.isMatrix Then
                                    Dim eMtx As New ExprMatrix( _
                                        rmArg.exprMtx.opExponential)
                                    rMtx = New retMtx(Me, eMtx)
                                ElseIf Not rmArg.curExpr.IsComplex Then
                                    Dim eMtx As New ExprMatrix( _
                                        Expression.AddFnAndArg0("exp", rmArg.curExpr))
                                    rMtx = New retMtx(Me, eMtx)
                                Else
                                    Dim eMtx As New ExprMatrix( _
                                        evalFn("exp", rmArg.curExpr.toComplex))
                                    rMtx = New retMtx(Me, eMtx)
                                End If
                            Case "integral", "∫", "integrate"
                                If bIsIntegralSequence Then
                                    Exit Try
                                End If
                                Dim sDet1 As String = "", sDet2 As String = ""
                                Dim vexpr(-1) As Expression
                                Dim nParams As Int32 = 0
                                Dim IRespVar As String = ""

                                bIsIntegralSequence = True
                                rmArg = Me.parent.mtxExpr(3)
                                bIsIntegralSequence = False
                                Dim t As currentMatch.exprType
                                Dim st1 As currentMatch.exprSubType1
                                Dim st2 As currentMatch.exprSubType2
                                Dim nxtMatch As Match = cur.testNextMatch(1, t, st1, st2)
                                If nxtMatch.Groups("Idx").Success Then
                                    cur.doNext()
                                End If

                                If cur.m.Groups("Idx").Success Then
                                    IRespVar = cur.m.Groups("IResp").ToString
                                    'cur.doNext()
                                    Me.bIsIntegralSequence = False
                                ElseIf cur.m.Groups("IResp").Success Then
                                    IRespVar = cur.m.Groups("IResp").ToString
                                ElseIf Len(cur.fstVarName) Then
                                    IRespVar = cur.fstVarName
                                Else
                                    IRespVar = "x"
                                End If


                                Dim varId As Int32 = vars.getVarIDByName(IRespVar, False)
                                If varId = -1 Then
                                    varId = 0
                                    Dim custFn As customFn = Nothing
                                    Do While varId + 1 < vars.getNamesList.Length AndAlso _
                                        vars.IsCustomFn(vars.getVarNameByID(varId), custFn)
                                        varId += 1
                                    Loop
                                    If IRespVar = "" AndAlso _
                                        vars.getNamesList.Length Then
                                        IRespVar = vars.getNamesList(0)
                                        Dim msg As String = ""
                                        vars.AddVar(IRespVar, Nothing, msg)
                                        varId = vars.getVarIDByName(IRespVar)
                                    End If
                                End If
                                ReDim vexpr(rmArg.cols - 1)
                                For i As Int32 = 0 To rmArg.cols - 1
                                    Dim expr As Expression = rmArg.exprMtx.getExpr(0, i)
                                    If expr Is Nothing AndAlso cur.m.Groups("Idx").Success Then
                                        expr = New Expression(1.0)
                                        rmArg.exprMtx.getExpr(0, i) = expr
                                    End If
                                    vexpr(i) = expr
                                Next
                                If cur.m.Groups("Idx").Success Then
                                    IRespVar = cur.m.Groups("IResp").ToString
                                    cur.doNext()
                                End If
                                'If cfg.bDetail Then
                                '    Dim eMtx As New ExprMatrix(cfg, 1, vexpr.Length)
                                '    For i = 0 To vexpr.Length - 1
                                '        eMtx.getExpr(0, i) = vexpr(i)
                                '    Next
                                '    sDet1 = "∫(" + eMtx.ToStringExprMtx(cfg) + ")d" + IRespVar
                                'End If
                                Dim ln0 As Int32 = rmArg.exprMtx.getExprAtRow(0).Length
                                Dim ln1 As Int32 = 0
                                Dim row2() As Expression = rmArg.exprMtx.getExprAtRow(1)
                                If row2 IsNot Nothing Then
                                    ln1 = row2.Length
                                End If
                                rMtx = New retMtx
                                If ln0 > 2 AndAlso ln0 > ln1 + 1 AndAlso _
                                vexpr(0).IsReal AndAlso vexpr(1).IsReal Then
                                    rMtx.exprMtx = _
                                        rmArg.exprMtx.opIntegralDefOrPolynFraction( _
                                                  varId, vexpr, cur, vars)
                                Else
                                    Dim vexpr1(0) As Expression
                                    If ln0 < 3 Then
                                        vexpr1(0) = vexpr(0)
                                    Else
                                        vexpr1(0) = vexpr(2)
                                    End If
                                    rMtx.exprMtx = rmArg.exprMtx.opIntegral( _
                                        cfg, varId, vexpr1, cur, vars, IRespVar, Nothing, Nothing, Nothing) '+ _
                                    If ln0 > 2 Then
                                        Dim eRet As Expression = rMtx.exprMtx.getExpr(0, 2)
                                        rMtx = New retMtx
                                        rMtx.exprMtx = New ExprMatrix(eRet)
                                        Dim oVarA As New VarsAndFns(cfg)
                                        oVarA.AddVar(IRespVar, vexpr(0))
                                        Dim a As Expression = rMtx.exprMtx.getExpr(0, 0).evalExprToExpr(oVarA)
                                        Dim oVarb As New VarsAndFns(cfg)
                                        oVarb.AddVar(IRespVar, vexpr(1))
                                        Dim b As Expression = rMtx.exprMtx.getExpr(0, 0).evalExprToExpr(oVarb)
                                        rMtx.exprMtx.getExpr(0, 0) = b - a
                                    End If
                                    'vexpr(0).opAntiDerivative( _
                                    ' cfg, varId, vexpr, cur, vars, IRespVar, Nothing, Nothing, Nothing)
                                    ' add a constant:
                                    'rMtx.curExpr = Expression.exprOp( _
                                    '    "+", rMtx.curExpr, New Expression(Polynomial.GetPolyomial( _
                                    '                   cfg.mathGlobal.integralCnst)))
                                    For i As Int32 = 0 To rMtx.exprMtx.Rows - 1
                                        For j As Int32 = 0 To rMtx.exprMtx.getExprAtRow(i).Length - 1
                                            Dim expr As Expression = rMtx.exprMtx.getExpr(i, j)
                                            If expr IsNot Nothing Then
                                                rMtx.exprMtx.getExpr(i, j) = expr + _
                                                    New Expression(Polynomial.GetPolynomial( _
                                                    cfg.mathGlobal.integralCnst))
                                            End If
                                        Next
                                    Next
                                End If
                                'If cur.bEnd OrElse _
                                'cur.subT1 = currentMatch.exprSubType1.delimiter OrElse _
                                'cur.tipo = currentMatch.exprType.RP OrElse _
                                'InStr("-+", cur.str) Then

                                'Me.maxCols = 0
                                If cur.bEnd OrElse _
                                cur.subT1 = currentMatch.exprSubType1.delimiter OrElse _
                                InStr("-+", cur.str) Then
                                    Exit Try
                                End If
                                'rMtx.curDer = Nothing
                                If cur.m.Groups("integral").Success Then
                                    If cur.oldTipo = currentMatch.exprType.op Then
                                        cur.imc -= 3
                                    Else
                                        cur.imc -= 2
                                    End If
                                    GoTo sig
                                End If
                                Exit Try
                                'GoTo sig
                            Case "re"
                                Dim sgn1 As Int32
                                Dim rMtx2 As retMtx = Nothing
                                cur.bOldFnHasLP = False
                                rMtx2 = nextFactor(sgn1, True)
                                If sgn1 = -1 Then
                                    rMtx2.exprMtx = -rMtx2.exprMtx
                                End If
                                rMtx.exprMtx = rMtx2.exprMtx.opReal
                            Case "im"
                                Dim sgn1 As Int32
                                Dim rMtx2 As retMtx = Nothing
                                cur.bOldFnHasLP = False
                                rMtx2 = nextFactor(sgn1, True)
                                If sgn1 = -1 Then
                                    rMtx2.exprMtx = -rMtx2.exprMtx
                                End If
                                rMtx.exprMtx = rMtx2.exprMtx.opImag
                            Case "sqr", "sqrt", "√"
                                Dim sgn1 As Int32
                                Dim rMtx2 As retMtx = Nothing
                                cur.bOldFnHasLP = False
                                rMtx2 = nextFactor(sgn1, True)
                                If sgn1 = -1 Then
                                    rMtx2.exprMtx = -rMtx2.exprMtx
                                End If
                                Dim rvArg As Expression = rMtx2.curExpr
                                Dim FnExpr As Expression = _
                                    rvArg ^ New Expression(0.5) '.reduceFactors(False)
                                rMtx.curExpr = FnExpr
                                'rMtx.curDer = Nothing
                                'cfg.oDetail.pushOperator(cur, pos, 1, rMtx.curExpr.ToStringExpr(cfg), True)
                            Case "gcd"
                                Dim bDetail As Boolean = cfg.bDetail
                                cfg.bDetail = False
                                Dim rMtx2 As retMtx = Nothing
                                If parent IsNot Nothing Then
                                    rMtx2 = parent.mtxExpr
                                Else
                                    rMtx = parent.mtxExpr
                                End If
                                Dim bAllPoly As Boolean = True
                                Dim bAllReal As Boolean = rMtx2.exprMtx.getExpr(0, 0).IsReal
                                For i As Int32 = 1 To rMtx2.cols - 1
                                    If Not rMtx2.exprMtx.getExpr(0, i).IsPolynomial OrElse _
                                        rMtx2.exprMtx.getExpr(0, i).IsReal Then
                                        bAllPoly = False
                                    End If
                                    If Not rMtx2.exprMtx.getExpr(0, i).IsReal Then
                                        bAllReal = False
                                    End If
                                Next
                                If Not bAllPoly AndAlso Not bAllReal Then
                                    Throw New Exception(msg8.num(54))
                                End If
                                cfg.bDetail = bDetall
                                If bAllReal Then
                                    Dim gcd As Double = rMtx2.exprMtx.getExpr(0, 0).toDouble
                                    For i As Int32 = 1 To rMtx2.cols - 1
                                        If gcd < 1.0 OrElse rMtx2.exprMtx.getExpr(0, i).toDouble < 1.0 Then
                                            Throw New Exception(msg8.num(9)) ' Argument(s) not valid.
                                        End If
                                        gcd = _
                                            Precis.gcd(gcd, rMtx2.exprMtx.getExpr(0, i).toDouble)
                                        If gcd < 2 Then
                                            Exit For
                                        End If
                                    Next
                                    If gcd < 2 Then
                                        gcd = 1
                                    End If
                                    rMtx.curExpr = New Expression(gcd)
                                Else
                                    If cfg.bDetail Then
                                        cfg.oDetail.AddAlways("(You may find an explanation at: " + _
                                            "<a href='http://en.wikipedia.org/wiki/Greatest_common_divisor_of_two_polynomials'>" + _
                                            "http://en.wikipedia.org/wiki/Greatest_common_divisor_of_two_polynomials" + "</a>")
                                    End If
                                    Dim gcd As Polynomial = rMtx2.exprMtx.getExpr(0, 0).getPolynomial
                                    For i As Int32 = 1 To rMtx2.cols - 1
                                        gcd = _
                                            Polynomial.opGcd(gcd, _
                                                rMtx2.exprMtx.getExpr(0, i).getPolynomial, cfg)
                                    Next
                                    rMtx.curExpr = New Expression(gcd)
                                End If
                                cfg.bDetail = bDetail
                            Case Else
                                Dim iCur As Int32 = cur.iCur
                                Dim bDetail As Boolean = cfg.bDetail
                                cfg.bDetail = False
                                Dim exponent As Int32 = 1

                                Dim nxtMatch As Match = Nothing
                                Dim t As currentMatch.exprType
                                Dim st1 As currentMatch.exprSubType1
                                Dim st2 As currentMatch.exprSubType2
                                If Not cur.bEnd Then
                                    'cur.bOldFnHasLP = True
                                    nxtMatch = cur.testNextMatch(1, t, st1, st2)
                                    If nxtMatch.Groups("num").Success Then
                                        Dim nxtMatch2 As Match = _
                                            cur.testNextMatch(2, t, st1, st2)
                                        If t = currentMatch.exprType.LP AndAlso _
                                        Int32.TryParse(nxtMatch.ToString, exponent) Then
                                            If Not (exponent = Math.Floor(exponent) AndAlso _
                                            0 < exponent AndAlso exponent < 10) Then
                                                exponent = 1
                                            Else
                                                cur.bVerify = False
                                                cur.doNext()
                                                'cur.doNext()
                                                cur.bVerify = True
                                            End If
                                        Else
                                            exponent = 1
                                        End If
                                    End If
                                    'cur.bOldFnHasLP = False
                                End If
                                Dim rMtx2 As retMtx = Nothing
                                nxtMatch = cur.testNextMatch(1, t, st1, st2)
                                Dim bLP As Boolean = nxtMatch.Groups("lp").Success
                                If bLP AndAlso exponent <> 1 Then
                                    cur.doNext()
                                    cur.LP -= 1
                                End If

                                Dim sgn1 As Int32
                                rMtx2 = nextFactor(sgn1, True)
                                If sgn1 = -1 Then
                                    rMtx2.exprMtx = -rMtx2.exprMtx
                                End If
                                nxtMatch = cur.testNextMatch(1, t, st1, st2)
                                If bLP AndAlso exponent <> 1 Then
                                    cur.bVerify = False
                                    'cur.doNext() ' skip )
                                    cur.bVerify = True
                                End If
                                Dim rvArg As Expression = rMtx2.curExpr
                                Dim isCjo As Boolean = rvArg.IsComplex
                                If isCjo = False Then
                                    Select Case fn
                                        Case Else
                                            Dim iFn As Int32 = -1
                                            If rvArg.getMatch IsNot Nothing AndAlso _
                                            rvArg.getMatch.Groups("fn").Success AndAlso _
                                            exponent = 1 Then
                                                Dim fn2 As String = LCase(rvArg.getMatch.ToString)
                                                iFn = Array.IndexOf( _
                                                    MathGlobal8.vFn, fn)
                                                If iFn > -1 AndAlso _
                                                MathGlobal8.vInvFn(iFn) = fn2 Then
                                                    If rvArg.sign = -1 Then
                                                        rMtx.curExpr = New Expression(New Expression(1.0) / rvArg.getArgs(0))
                                                    Else
                                                        rMtx.curExpr = New Expression(rvArg.getArgs(0))
                                                    End If
                                                    'Else
                                                    '    iFn = -1
                                                End If
                                            End If
                                            If (fn = "ln" OrElse _
                                            (Len(fn) >= 3 AndAlso Mid(fn, 1, 3) = "log")) AndAlso _
                                            rvArg.getMatch IsNot Nothing AndAlso _
                                            rvArg.getMatch.ToString = "/" AndAlso _
                                            rvArg.getArgs(0).IsReal AndAlso _
                                            (rvArg.getArgs(0).toDouble = 1 OrElse _
                                            rvArg.getArgs(0).toDouble = -1) Then
                                                Dim num As Double = rvArg.getArgs(0).toDouble
                                                Dim sgnArg0 As Int32 = rvArg.getArgs(0).sign
                                                rMtx.curExpr = New Expression(rvArg.getArgs(1))
                                                rMtx.curExpr.sign *= num * sgnArg0 * rvArg.sign
                                                rvArg = rMtx.curExpr
                                            ElseIf (fn = "ln" OrElse _
                                            (Len(fn) >= 3 AndAlso Mid(fn, 1, 3) = "log")) AndAlso _
                                            rvArg.IsPolynomial Then
                                                Dim polyArg As New Polynomial(rvArg.getPolynomial)
                                                polyArg.PolyResto = Nothing
                                                polyArg.PolyDivisor = Nothing
                                                If rvArg.getPolynomial.IsOnlyFraction Then
                                                    polyArg = New Polynomial(rvArg.getPolynomial)
                                                    If polyArg.PolyResto.isReal Then
                                                        Dim num As Double = polyArg.PolyResto.ToDouble
                                                        If num = 1 OrElse num = -1 Then
                                                            rMtx.curExpr = New Expression(polyArg.PolyDivisor)
                                                            rMtx.curExpr.sign *= num * rvArg.sign * -1
                                                            rvArg = rMtx.curExpr
                                                        End If
                                                    End If
                                                End If
                                            End If

                                            If iFn = -1 Then
                                                Dim FnExpr As Expression = _
                                                Expression.AddFnAndArg0(mFn, rvArg)
                                                If exponent <> 1 Then
                                                    FnExpr ^= New Expression(exponent)
                                                End If
                                                rMtx.curExpr = FnExpr
                                            End If
                                    End Select
                                    cfg.bDetail = bDetall
                                Else
                                    'Dim sDet1 As String = "", sDet2 As String = ""
                                    Dim cjoA As Complex = rvArg.toComplex
                                    If cfg.bDetail Then
                                        'sDet1 = fn + "(" + cjoA.toStringComplex(cfg) + ")"
                                    End If
                                    If fn = "√" Then fn = "sqr"
                                    Dim rCjo As Complex = evalFn(fn, cjoA, cur)
                                    rMtx.curExpr = New Expression(New Polynomial(rCjo))
                                    If exponent <> 1 Then
                                        rMtx.curExpr ^= New Expression(exponent)
                                    End If
                                    cfg.bDetail = bDetall
                                    If cfg.bDetail Then
                                        'cfg.oDetail.pushOperator(cur, pos, 1, rMtx.curExpr.ToStringExpr(cfg), True)
                                        'sDet2 = rMtx.curExpr.ToStringExpr(cfg)
                                        'If sDet1 <> sDet2 Then
                                        '    cfg.oDetail.Add(sDet1 + " =")
                                        '    cfg.oDetail.Add("= " + sDet2)
                                        'End If
                                        'popInDetail()
                                    End If
                                End If
                                'sgn *= fnSgn
                                'If cur.bOldFnHasLP AndAlso Not cur.m.Groups("rp").Success Then
                                '    Throw New Exception(String.Format( _
                                '        msg8.num(1), " ')'"))
                                'ElseIf cur.bOldFnHasLP Then
                                '    cur.bOldFnHasLP = False
                                'End If
                                'rMtx.curDer = Nothing
                                'If cfg.bDetail Then
                                '    cfg.oDetail.pushOperator(iCur, 1, _
                                '        rMtx.curExpr.ToStringExpr(cfg))
                                'End If
                        End Select
                    End If
                    'ElseIf cur.m.Groups("Idx").Success Then
                    '   Exit Try
                ElseIf cur.m.Groups("cnt").Success Then
                    Select Case LCase(cur.str)
                        Case "pi" : rMtx.curExpr = New Expression(Math.PI)
                        Case "e" : rMtx.curExpr = New Expression(Math.E)
                    End Select
                ElseIf cur.m.Groups("img").Success Then
                    rMtx.curExpr = New Expression(New Polynomial( _
                                New Complex(0.0, 1.0)))
                    'ElseIf cur.str = "=" Then
                    '    cur.equalSign()
                    '    Me.bIsEquation = True
                    '    If cfg.bDetail Then
                    '        'cfg.oDetail.Clear()
                    '        cfg.oDetail.pop_iCur(cur)
                    '    End If
                ElseIf cur.tipo = currentMatch.exprType.custFn Then
                    Dim varID As Int32 = -1
                    Dim pos As Int32 = cur.iCur
                    Dim fn As customFn = Nothing
                    ' retrive custom function fn:
                    Dim nomFn As String = Mid(cur.str, 1, Len(cur.str) - 1)
                    vars.IsCustomFn(cur.str, fn)

                    ' get fn's parameters:
                    Dim sParams As String = ""
                    Dim fnrMtx As retMtx = Nothing
                    'cur.doNext()
                    'If Not cur.m.Groups("lp").Success Then
                    '    ' expected an opening '('
                    '    Throw New Exception(String.Format( _
                    '        msg8.num(1), " '('"))
                    'End If
                    If Me.parent Is Nothing Then
                        fnrMtx = nextExpr()
                    Else
                        fnrMtx = Me.parent.mtxExpr()
                    End If
                    If Not cur.m.Groups("rp").Success Then
                        Throw New Exception(String.Format( _
                            msg8.num(1), " ')'"))
                    End If
                    Dim bDetail As Boolean = cfg.bDetail
                    cfg.bDetail = False
                    If bDetail Then
                        cfg.oDetail.Add(nomFn + "(" + fnrMtx.ToString + ") =")
                    End If

                    ' eval the function at sParams:
                    'rMtx.curExpr = fn.evalMtx(fnrMtx.exprMtx)
                    rMtx = New retMtx(Me, fn.evalMtxToExprMtx(cfg, fnrMtx))
                    If bDetail Then
                        cfg.oDetail.Add(" = " + rMtx.toStringRetVal(cfg))
                    End If
                    cfg.bDetail = bDetail
                    'If cfg.bDetail Then
                    '    cfg.oDetail.pushOperator(pos, 1, _
                    '    rMtx.curExpr.ToStringExpr(cfg))
                    'End If
                ElseIf cur.subT1 = currentMatch.exprSubType1.logicalOp Then
                    Dim pos As Int32 = cur.iCur
                    Dim subT2 As currentMatch.exprSubType2 = cur.subT2
                    If Not rMtx.curExpr.IsReal Then
                        Dim ce As New currentMatch.curMatchErr
                        Throw ce.err(Nothing, cur, msg8.num(4), pos - 1)
                    End If
                    Dim opA As Double = rMtx.curExpr.getPolynomial.cf(0).pRe.ToDouble
                    Dim rvB As retMtx = Nothing
                    Dim opb As Double
                    If cur.subT2 <> currentMatch.exprSubType2.NOT Then
                        If cur.bEnd Then
                            Dim ce As New currentMatch.curMatchErr
                            Throw ce.err(Nothing, cur, msg8.num(4))
                        End If
                        Dim sgnB As Int32 = 1
                        pos = cur.iCur
                        rvB = nextFactor(sgnB)
                        If sgnB = -1 Then
                            rvB.curExpr = -rvB.curExpr
                        End If
                        If Not rvB.curExpr.IsReal Then
                            Dim ce As New currentMatch.curMatchErr
                            cur.imc = cur.iCur
                            Dim sCur As String = String.Empty
                            Try
                                sCur = cur.toStrCurMatch(cfg.outputFormat = outputMsgFormat.HTML)
                            Catch ex As Exception
                            End Try
                            Throw New Exception(msg8.num(13) + vbCrLf + sCur)
                        End If
                        opb = rvB.curExpr.getPolynomial.cf(0).pRe.ToDouble
                    Else
                    End If
                    If cfg.bDetail Then
                        cfg.oDetail.pop_iCur(cur)
                        cur.toStrAndInsertMsg( _
                        New Expression(opA), _
                        New Expression(opb), subT2, True)
                    End If

                    Dim opR As Double
                    Select Case subT2
                        Case currentMatch.exprSubType2.AND
                            opR = (opA And opb)
                        Case currentMatch.exprSubType2.OR
                            opR = (opA Or opb)
                        Case currentMatch.exprSubType2.NOT
                            opR = Not (opA)
                        Case currentMatch.exprSubType2.XOR
                            opR = (opA Xor opb)
                        Case currentMatch.exprSubType2.NOR
                            opR = Not (opA Or opb)
                        Case currentMatch.exprSubType2.NAND
                            opR = Not (opA And opb)
                    End Select
                    rMtx.curExpr = New Expression(opR)
                    If cfg.bDetail Then
                        cur.toStrAndInsertMsg(rMtx.curExpr, Nothing, 0, False)
                    End If
                ElseIf cur.m.Groups("resto").Success Then
                    Throw New Exception(String.Format( _
                        msg8.num(5), cur.str))
                Else
                    Exit Do
                End If
                If bOnlyOpnd Then
                    Exit Do
                End If
            Loop While Not cur.bEnd AndAlso _
                cur.subT2 <> currentMatch.exprSubType2.integralResp

        Catch ex As Exception
            If TypeOf (ex) Is NullReferenceException Then
                Throw New Exception(msg8.num(13))
            Else
                Throw New Exception(ex.Message)
            End If
        End Try
        'If rMtx IsNot Nothing Then
        '    rMtx.cfg = cfg
        '    If rMtx.curExpr IsNot Nothing Then
        '        rMtx.curExpr.cfg = cfg
        '    End If
        'End If
        Return rMtx
    End Function


    Public Shared Function evalFn( _
                    ByVal fn As String, _
                    ByVal cjoA As Complex, _
                    Optional ByVal cur As currentMatch = Nothing) As Complex
        Static vTrigonFns() As String = _
            New String() { _
            "sin", "cos", "tan", _
            "sinh", "cosh", "tanh", _
            "csc", "sec", "cot", _
            "csch", "sech", "coth" _
            }
        Dim rCjo As Complex = Nothing
        Try
            fn = LCase(fn)
            Dim bArgNotValid As Boolean = False
            If cur IsNot Nothing Then
                If cur.getCurAngle <> currentMatch.exprSubType1.radian AndAlso _
                Array.IndexOf(vTrigonFns, fn) > -1 Then
                    If cur.getCurAngle = currentMatch.exprSubType1.degree Then
                        cjoA *= New Complex(MathGlobal8.degree2Radians)
                    Else 'If cur.getCurAngle = currentMatch.exprSubType1.gradian Then
                        cjoA *= New Complex(MathGlobal8.centesimal2Rad)
                    End If
                End If
            End If
repiteFn:
            Select Case Len(fn)
                Case 6
                    Select Case fn
                        Case "logtwo" : rCjo = Complex.opLn(cjoA) / Math.Log(2.0)
                        Case "logten" : rCjo = Complex.opLn(cjoA) / Math.Log(10.0)
                    End Select
                Case 5
                    Select Case fn
                        Case "acosh" : rCjo = Complex.opACosH(cjoA)
                        Case "acoth" : rCjo = Complex.opACotH(cjoA)
                        Case "acsch" : rCjo = Complex.one / Complex.opASinH(cjoA)
                        Case "asech" : rCjo = Complex.opASecH(cjoA)
                        Case "asinh" : rCjo = Complex.opASinH(cjoA)
                        Case "atanh" : rCjo = Complex.opAtanH(cjoA)
                        Case "floor" : rCjo = New Complex(Math.Floor(cjoA.pRe.ToDouble))
                            If cjoA.pIm.IsZero = False Then
                                bArgNotValid = True
                            End If
                        Case "round" : rCjo = New Complex(Math.Round(cjoA.pRe.ToDouble))
                            If cjoA.pIm.IsZero = False Then
                                bArgNotValid = True
                            End If
                    End Select
                Case 4
                    Select Case fn
                        Case "coth" : rCjo = Complex.opCotH(cjoA)
                        Case "csch" : rCjo = Complex.opCscH(cjoA)
                        Case "sech" : rCjo = Complex.opSecH(cjoA)
                        Case "acos" : rCjo = Complex.opACos(cjoA)
                        Case "acot" : rCjo = Complex.opAtan(Complex.one / cjoA)
                        Case "acsc" : rCjo = Complex.opASin(Complex.one / cjoA)
                        Case "asec" : rCjo = Complex.opASec(cjoA)
                        Case "asin" : rCjo = Complex.opASin(cjoA)
                        Case "atan" : rCjo = Complex.opAtan(cjoA)
                        Case "conj" : rCjo = Complex.opConjugate(cjoA)
                        Case "cosh" : rCjo = Complex.opCosH(cjoA)
                        Case "norm" : rCjo = New Complex(cjoA.opNorm, 0.0)
                        Case "sign" : rCjo = New Complex(Math.Sign(cjoA.pRe.ToDouble))
                            If cjoA.pIm.IsZero = False Then
                                bArgNotValid = True
                            End If
                        Case "sinh" : rCjo = Complex.opSinH(cjoA)
                        Case "sqrt" : rCjo = cjoA ^ Complex.oneHalf  ' 2013/08/09
                        Case "tanh" : rCjo = Complex.optanh(cjoA)
                    End Select
                Case 3
                    Select Case fn
                        Case "abs" : rCjo = cjoA.opAbs
                        Case "arg" : rCjo = Complex.opArg(cjoA)
                        Case "cos" : rCjo = Complex.opCos(cjoA)
                        Case "cot" : rCjo = Complex.opCot(cjoA)
                        Case "csc" : rCjo = Complex.opCsc(cjoA) ' csc=1/sin
                        Case "exp" : rCjo = Complex.opExp(cjoA)
                        Case "log" : fn = "ln" : GoTo repiteFn ' log()= ln()
                        Case "mod" : rCjo = New Complex(cjoA.opModulo, 0.0)
                        Case "sec" : rCjo = Complex.opSec(cjoA) ' sec
                        Case "sin" : rCjo = Complex.opSin(cjoA)
                        Case "sqr" : rCjo = cjoA ^ Complex.oneHalf  ' 2013/08/09
                        Case "tan" : rCjo = Complex.optan(cjoA)
                    End Select
                Case 2
                    Select Case fn
                        Case "ln" : rCjo = Complex.opLn(cjoA) ' ln()= log()
                        Case "im" : rCjo = New Complex(New Precis(0.0), cjoA.pIm)
                        Case "re" : rCjo = New Complex(cjoA.pRe, New Precis(0.0))
                    End Select
            End Select
            If bArgNotValid Then
                Throw New Exception( _
                String.Format(msg8.num(29), fn))
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
        Return rCjo
    End Function
    Public ReadOnly Property ToStringExprParser(cfg As Config) As String
        Get
            Return ret.toStringRetVal(cfg)
        End Get
    End Property
    Public Overrides Function ToString() As String
        Return ret.toStringRetVal(Config.cfg)
    End Function
End Class


<Serializable()> _
Public Class retVal
    Public expr As Expression
    'Public deriv As New Expression(0.0)
    Public sgn As Int32 = 1
    Dim vars As VarsAndFns
    Public rMtx As retMtx = Nothing
    Public Sub New()
    End Sub
    Public Sub New(ByVal expr As Expression, _
                   ByVal vars As VarsAndFns)
        If expr IsNot Nothing Then
            Me.expr = New Expression(expr)
        End If
        Me.vars = vars
    End Sub
    'Public Sub New(ByVal expr As Expression, _
    '               ByVal deriv As Expression, _
    '               ByVal vars As VarsAndFns)
    '    If expr IsNot Nothing Then
    '        Me.expr = New Expression(expr)
    '    End If
    '    If deriv IsNot Nothing Then
    '        Me.deriv = New Expression(deriv)
    '    End If
    '    Me.vars = vars
    'End Sub
    Public Sub New(ByVal rv As retVal)
        With rv
            If .expr IsNot Nothing Then
                Me.expr = .expr.Clone() ' MathGlobal8.CloneObject(.expr)
            End If
            Me.sgn = .sgn
            Me.vars = .vars
        End With
    End Sub
    'Public Sub New(ByVal rv As retVal)
    '    With rv
    '        If .expr IsNot Nothing Then
    '            Me.expr = .expr.Clone() ' MathGlobal8.CloneObject(.expr)
    '        End If
    '        If .deriv IsNot Nothing Then
    '            Me.deriv = .deriv.Clone ' MathGlobal8.CloneObject(.deriv)
    '        End If
    '        Me.sgn = .sgn
    '        Me.vars = .vars
    '    End With
    'End Sub
    Public Sub setVars(ByVal vars As VarsAndFns)
        Me.vars = vars
    End Sub
    Public Sub getSgn()
        If sgn = -1 Then
            expr = -expr
            'If deriv IsNot Nothing Then
            '    deriv = -deriv
            'End If
        End If
        sgn = 1
    End Sub
    Public Overrides Function ToString() As String
        Return expr.ToString
    End Function
    Public ReadOnly Property toStringRetVal(cfg As Config) As String
        Get
            Return expr.ToStringExpr(cfg)
        End Get
    End Property

End Class
