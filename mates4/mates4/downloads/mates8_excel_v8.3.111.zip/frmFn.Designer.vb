﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFn
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbFn = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbActiveCell = New System.Windows.Forms.TextBox()
        Me.btnAminus = New System.Windows.Forms.Button()
        Me.btnAplus = New System.Windows.Forms.Button()
        Me.cbExamples = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 34)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select a function " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to add to the active cell:"
        '
        'cbFn
        '
        Me.cbFn.FormattingEnabled = True
        Me.cbFn.Location = New System.Drawing.Point(3, 37)
        Me.cbFn.Name = "cbFn"
        Me.cbFn.Size = New System.Drawing.Size(121, 25)
        Me.cbFn.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(135, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "...or edit Active Cell:"
        '
        'tbActiveCell
        '
        Me.tbActiveCell.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbActiveCell.Location = New System.Drawing.Point(3, 97)
        Me.tbActiveCell.Multiline = True
        Me.tbActiveCell.Name = "tbActiveCell"
        Me.tbActiveCell.Size = New System.Drawing.Size(301, 163)
        Me.tbActiveCell.TabIndex = 3
        '
        'btnAminus
        '
        Me.btnAminus.Image = Global.ExcelWorkbook1.My.Resources.Resources.Ap
        Me.btnAminus.Location = New System.Drawing.Point(205, 68)
        Me.btnAminus.Name = "btnAminus"
        Me.btnAminus.Size = New System.Drawing.Size(23, 23)
        Me.btnAminus.TabIndex = 5
        Me.btnAminus.UseVisualStyleBackColor = True
        '
        'btnAplus
        '
        Me.btnAplus.Image = Global.ExcelWorkbook1.My.Resources.Resources.Am
        Me.btnAplus.Location = New System.Drawing.Point(176, 68)
        Me.btnAplus.Name = "btnAplus"
        Me.btnAplus.Size = New System.Drawing.Size(23, 23)
        Me.btnAplus.TabIndex = 4
        Me.btnAplus.UseVisualStyleBackColor = True
        '
        'cbExamples
        '
        Me.cbExamples.DropDownWidth = 350
        Me.cbExamples.FormattingEnabled = True
        Me.cbExamples.Items.AddRange(New Object() {"---Basic operations:---", "1600/((1-(1+1/4)^30)/(1-(1+1/4)))", "                ", "---Evaluating:---", "x^2-9*x+20@x=5", "x^2-9x+20@x=4.5", "2+(xy)(xa)@x=3|y=4|xa=-3", "                ", "---Hex, octal, binary:", "&amp;hF+&amp;o17+&amp;b1111+15", "                ", "---Logical operators:", "(&amp;hffAND&amp;h0f)+3", "                ", "---Modulus:", "((x5+3x3+4)*(6x6+4x3))%11", "                ", "---POLYNOMIALS:", "---Root finder:", "roots(x16-1)", "(x-1)*(x+1)", "x^2-9x+20", "---Orthogonality:", "orthog(-1,1,2*t+3,5*t^2+t-17/9)", "---Interpolation:---", "x|*|lagrangianinterpolation(-2,1|0,-1|2,1)", "                ", "---Derivatives:---", "Dx(cosh(x))", "Dy(sin(x^2*y^2+y))", "Dy(z)@z=x+y|x=y^2", "                ", "---2nd.derivative:---", "D2x(3x^2-2x+5)", "                ", "---Jacobian:---", "jacobian(1,000x^2-2x+5,sin(x2)|xsinh(y),xasinh(y))", "                ", "---Vector operation:", "1 2|*|3|-1", "                ", "---MATRIX operations:", "(1 0|0 -1|^|-1)|*|1 0|0 -1", "(1 2|3 4|+|1 0|0 1)|*|-1 0|0 1", "((1 0|0 3|-|5 0|3 -2)|^|-1)|*|(-4 0|-3 5)", "(x 0|0 1|^|-1)|*|a@a=x 0|0 1", "x+1 0|0 -1|^|-1|*|a@a=(x+1) 0|0 -1", "A+(-B*C)@A=1 2|3 -1||B=A|C=1 0|0 1", "---Inverse matrix:", "A^-1@A=1 2|3 -1", "A^-1*A@A=1 2|3 -1", "                ", "---System of equations:---", "---Linear:---", "_XC=1/(2*pi*f*C)@_XC=50@f=10e6", "x+y=2|x-y=1", "---Non-Linear:---", "x2-10x+y2+8=0|xy2+x-10y+8=0", "                ", "---INTEGRATION:", "---Integration of polynomials:", "integral(6x-2)", "integral(3x2+y)dx", "∫(x2+y)dy", "                ", "---Inmediate integrals:", "∫(sin(x))dx", "∫(ln(x))dx", "                ", "---Definite integrals:", "integral(1,2,x)dx", "integral(1,2,xy)dy", "∫(1,2,x)dx", "∫(a,b,xy)dx@a=1|b=2", "∫(a,b,S(x))dx,pi(10^(3/2)-1)/27@a=0@b=1@f(x)=x3@S(x)=2*pi*f(x)*sqr(1+(Dx(f(x)))^2" & _
                ")", "                ", "---Partial fractions integration:", "∫1/(x(x-2)^2)dx", "                ", "---Trigonometric integration:", "∫(sec(x)*tan2(x))dx", "                ", "---Integration by parts:", "13*∫(sin(3*x)*exp(2*x))dx"})
        Me.cbExamples.Location = New System.Drawing.Point(183, 37)
        Me.cbExamples.Name = "cbExamples"
        Me.cbExamples.Size = New System.Drawing.Size(121, 25)
        Me.cbExamples.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(187, 17)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 17)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "...or an example:"
        '
        'frmFn
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(307, 261)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbExamples)
        Me.Controls.Add(Me.btnAminus)
        Me.Controls.Add(Me.btnAplus)
        Me.Controls.Add(Me.tbActiveCell)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cbFn)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmFn"
        Me.Text = "Add a Function"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbFn As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tbActiveCell As System.Windows.Forms.TextBox
    Friend WithEvents btnAplus As System.Windows.Forms.Button
    Friend WithEvents btnAminus As System.Windows.Forms.Button
    Friend WithEvents cbExamples As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
