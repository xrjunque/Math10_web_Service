﻿
Public Class Hoja1

    Private Sub Hoja1_Startup() Handles Me.Startup

    End Sub

    Private Sub Hoja1_Shutdown() Handles Me.Shutdown

    End Sub

End Class
Partial Friend NotInheritable Class Globals

    Private Shared _Hoja1 As Hoja1

    Friend Shared Property Hoja1() As Hoja1
        Get
            Return _Hoja1
        End Get
        Set
            If (_Hoja1 Is Nothing) Then
                _Hoja1 = Value
            Else
                Throw New System.NotSupportedException()
            End If
        End Set
    End Property
End Class
