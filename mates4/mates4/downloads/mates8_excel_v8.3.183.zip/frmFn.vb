﻿Imports System.Drawing

Public Class frmFn
    Public wb As ThisWorkbook
    Public hoja As Excel.Worksheet
    Dim emSizes() As Single = {6.0, 8.0, 9.0, 10.0, 11.0, 14.0, 18.0, 22, 26, 32, 48}
    Dim iSize As Single = 4
    Dim fnt As Font
    Dim sVariables As String = "variables"
    Dim sResponse As String = "response"
    Dim sCalculate As String = "calculate:"
    Dim rowResponse, rowCalculate As Int32
    Public Shared bActivo As Boolean
    Private Sub cbFn_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbFn.SelectedIndexChanged
        Try
            If hoja IsNot Nothing Then
                Dim i As Int32 = cbFn.SelectedIndex
                If i < 0 OrElse i >= cbFn.Items.Count Then
                    Exit Sub
                End If
                Dim o = hoja.Application.ActiveCell.Value
                o += cbFn.Items(i) + "( )"
                hoja.Application.ActiveCell.Value = o
                tbActiveCell.Text = o
            End If
        Catch ex As Exception
            Me.Close()
        End Try
    End Sub

    Private Sub frmFn_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Dim enUsoActiv As Boolean = False
        If enUsoActiv Then
            Exit Sub
        End If
        Try
            enUsoActiv = True
            hoja = ThisWorkbook.app.ActiveSheet
            If hoja IsNot Nothing Then
                Dim o = hoja.Application.ActiveCell.Value
                tbActiveCell.Text = CStr(o)
                tbActiveCell.Refresh()
            End If
        Catch ex As Exception
            Me.Close()
        Finally
            enUsoActiv = False
        End Try
    End Sub

    Private Sub frmFn_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        frmFn.bActivo = False
    End Sub

    Private Sub Fn_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            frmFn.bActivo = True
            hoja = ThisWorkbook.app.ActiveSheet
            Dim i As Int32
            Dim vSort(MathGlobal8.vFn.Length - 1) As String
            For i = 0 To MathGlobal8.vFn.Length - 1
                vSort(i) = MathGlobal8.vFn(i)
            Next
            Array.Sort(vSort)
            For i = 0 To vSort.Length - 1
                cbFn.Items.Add(vSort(i))
            Next
            fuente()
        Catch ex As Exception
            Me.Close()
        End Try
    End Sub


    Private Sub tbActiveCell_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbActiveCell.TextChanged
        Dim enUsoTB As Boolean = False
        If enUsoTB Then
            Exit Sub
        End If
        Try
            If hoja IsNot Nothing Then
                hoja.Application.ActiveCell.Value = tbActiveCell.Text
            End If
        Catch ex As Exception
            Me.Close()
        Finally
            enUsoTB = False
        End Try
    End Sub

    Private Sub btnAplus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAplus.Click
        If iSize < emSizes.Length Then
            iSize += 1
            fuente()
        End If
    End Sub

    Private Sub btnAminus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAminus.Click
        If iSize > 0 Then
            iSize -= 1
            fuente()
        End If
    End Sub
    Sub fuente()
        Try
            fnt = New Font("Arial", emSizes(iSize))
            tbActiveCell.Font = fnt
        Catch ex As Exception

        End Try
    End Sub
    Private Sub cbExamples_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbExamples.SelectedIndexChanged
        Try
            If cbExamples.SelectedIndex > -1 Then
                clearAll()
                clear()
                Dim e1 As String = ""
                If hoja Is Nothing Then
                    Exit Sub
                End If
                e1 = cbExamples.Items(cbExamples.SelectedIndex)
                e1 = Trim(e1)
                If Len(e1) = 0 Then
                    Exit Sub
                End If
                If Len(e1) > 3 AndAlso _
                Mid(e1, 1, 3) = "---" Then
                    Exit Sub
                End If
                'If cbExamples.SelectedIndex >= 11 Then
                e1 = Replace(e1, " ", ";")
                'End If
                e1 = Replace(e1, "&amp;", "&")
                e1 = Replace(e1, "|", vbCrLf)
                Dim e2() As String = Split(e1, "@")
                Dim pe As ParseExcel = wb.pE
                If pe Is Nothing Then
                    pe = New ParseExcel(hoja)
                End If
                pe.DoAll(True)
                Dim cfg As Config = pe.cfg
                cfg.bIgnoreSpaces = False
                cfg.bRounding = True
                cfg.bCaseSensitive = True
                pe.setConfig()
                Dim m8 As New matrixParser
                Dim oVar As VarsAndFns = Nothing
                hoja.Cells.Cells(rowCalculate, 2).Value = e2(0)
                Dim row0 As Int32 = 2
                If e2.Length = 1 Then
                    m8.parse( _
                             e2(0), "", oVar, cfg)
                Else
                    Dim e3(e2.Length - 2) As String
                    Array.Copy(e2, 1, e3, 0, e3.Length)
                    m8.parse( _
                             e2(0), Join(e3, vbCrLf), oVar, cfg)
                    If oVar IsNot Nothing Then
                        For i = 0 To oVar.getNamesList.Length - 1
                            Dim sVar As String = oVar.getNamesList(i)
                            Dim custFn As customFn = Nothing
                            Dim bCustFn As Boolean = oVar.IsCustomFn(sVar, custFn)
                            Dim eMtx As ExprMatrix = _
                                oVar.getValueByName(sVar, False)
                            If eMtx IsNot Nothing Then
                                Dim sMtx As String = eMtx.ToStringExprMtx(cfg)
                                If bCustFn Then
                                    hoja.Cells.Cells(row0, 1).Value = _
                                       Split(custFn.ToString, "=")(0) + "="
                                Else
                                    hoja.Cells.Cells(row0, 1).Value = sVar + "="
                                End If
                                Dim vRow() As String = Split(sMtx, vbCrLf)
                                For row As Int32 = 0 To vRow.Length - 1
                                    Dim vCol() As String = Split(vRow(row), ";")
                                    For col As Int32 = 0 To vCol.Length - 1
                                        hoja.Cells.Cells(row0, 2 + col).Value = vCol(col)
                                        hoja.Cells.Cells(row0, 2 + col).numberformat = "0.00E+00"
                                    Next
                                    row0 += 1
                                Next
                            End If
                        Next
                    End If
                End If
                If True Then
                    row0 = rowResponse + 1
                    hoja.Cells.Cells(row0, 1).Value = e2(0) + "="
                    Dim sMtx As String = m8.ret.toStringRetVal(cfg)
                    Dim vRow() As String = Split(sMtx, vbCrLf)
                    If m8.ret.getParser.bIsEquation Then
                        Dim sResult As String = ""
                        Dim soe As SystemOfEquations = Nothing
                        Try
                            soe = New SystemOfEquations( _
                             Nothing, m8.ret.exprMtx, m8.getVars, m8.ret.getParser.cur, cfg)
                            soe.resolveSysOfEqs(cfg)
                            sResult = soe.ToStringInfo(cfg)
                        Catch ex As Exception
                            sResult += vbCrLf + m8.ret.exprMtx.ToStringExprMtx(cfg) + _
                            ex.Message
                            'vbCrLf(+msg8.num(12))
                        End Try
                        For row As Int32 = 0 To soe.sSolutionVars.Length - 1
                            hoja.Cells.Cells(row0, 1).Value = soe.sSolutionVars(row)(0) + "="
                            hoja.Cells.Cells(row0, 2).Value = soe.sSolutionVars(row)(1)
                            hoja.Cells.Cells(row0, 2).numberformat = "0.00E+00"
                            row0 += 1
                        Next
                    Else
                        For row As Int32 = 0 To vRow.Length - 1
                            Dim vCol() As String = Split(vRow(row), ";")
                            For col As Int32 = 0 To vCol.Length - 1
                                hoja.Cells.Cells(row0, 2 + col).Value = vCol(col)
                                hoja.Cells.Cells(row0, 2 + col).numberformat = "0.00E+00"
                            Next
                            row0 += 1
                        Next
                    End If
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub
    Sub clearAll()
        Try
            Dim row As Int32
            Dim o = Nothing
            Dim col As Int32
            For row = 1 To hoja.UsedRange.Rows.Count
                o = hoja.Cells.Cells(row, 1).value
                Dim bDoClear As Boolean = False
                If o IsNot Nothing AndAlso Len(o) Then
                    If InStr(LCase(CStr(o)), sResponse) > 0 OrElse _
                     InStr(LCase(CStr(o)), sCalculate) > 0 OrElse _
                     InStr(LCase(CStr(o)), sVariables) > 0 Then
                        If InStr(LCase(CStr(o)), sCalculate) > 0 Then
                            rowCalculate = row
                        End If
                        For col = 2 To hoja.UsedRange.Columns.Count
                            hoja.Cells.Cells(row, col).value = ""
                        Next
                    Else
                        bDoClear = True
                    End If
                Else
                    bDoClear = True
                End If
                If bDoClear Then
                    For col = 1 To hoja.UsedRange.Columns.Count
                        hoja.Cells.Cells(row, col).value = ""
                    Next
                End If
            Next
            For row = rowResponse + 1 To hoja.UsedRange.Rows.Count
            Next
        Catch ex As Exception

        End Try
    End Sub
    Sub clear()
        Try
            Dim row As Int32
            Dim o = Nothing
            Dim col As Int32
            For row = 1 To hoja.UsedRange.Rows.Count
                o = hoja.Cells.Cells(row, 1).value
                If o IsNot Nothing AndAlso Len(o) Then
                    If InStr(LCase(CStr(o)), sResponse) > 0 Then
                        rowResponse = row
                        Exit For
                    End If
                End If
            Next
            For row = rowResponse + 1 To hoja.UsedRange.Rows.Count
                For col = 1 To hoja.UsedRange.Columns.Count
                    hoja.Cells.Cells(row, col).value = ""
                Next
            Next
        Catch ex As Exception

        End Try
    End Sub
End Class