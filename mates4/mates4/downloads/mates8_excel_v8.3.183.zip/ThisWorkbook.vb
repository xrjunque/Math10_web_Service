﻿
Public Class ThisWorkbook

    Public Shared app As Excel.Application
    Public hoja As Excel.Worksheet
    Public pE As ParseExcel
    Dim frmFn1 As frmFn
    Private Sub ThisWorkbook_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup
        app = Application
        With Globals.ThisWorkbook.ActionsPane
            .Clear()
            .Visible = True
            .AutoRecover = True
        End With
        AddHandler Globals.ThisWorkbook.ActionsPane.OrientationChanged,
     AddressOf ActionsPane_OrientationChanged
        ResetStackOrder()

        ' Create the button that will update the stack order.
        Dim button1 As New Button()
        button1.Text = "Change stack order"
        AddHandler button1.Click, AddressOf button1_Click


        Dim button2 As New Button()
        button2.Text = "Calculate"
        AddHandler button2.Click, AddressOf button2_Click
        Dim button3 As New Button()
        button3.Text = "Add Function"
        AddHandler button3.Click, AddressOf function_Click

        Dim button4 As New Button()
        button4.Text = "Clear"
        AddHandler button4.Click, AddressOf clear_click

        Globals.ThisWorkbook.ActionsPane.Controls.AddRange(New Control() _
            {button1, button2, button3, button4}) ' , button3})

        app = Application
    End Sub
    ' Switch the stack order according to the current orientation.
    Private Sub button1_Click(ByVal sender As Object, ByVal e As EventArgs)

        If Globals.ThisWorkbook.ActionsPane.Orientation =
            Orientation.Horizontal Then

            If Globals.ThisWorkbook.ActionsPane.StackOrder =
                Microsoft.Office.Tools.StackStyle.FromLeft Then
                Globals.ThisWorkbook.ActionsPane.StackOrder =
                    Microsoft.Office.Tools.StackStyle.FromRight
            Else
                Globals.ThisWorkbook.ActionsPane.StackOrder =
                    Microsoft.Office.Tools.StackStyle.FromLeft
            End If
        Else
            If Globals.ThisWorkbook.ActionsPane.StackOrder =
                Microsoft.Office.Tools.StackStyle.FromTop Then
                Globals.ThisWorkbook.ActionsPane.StackOrder =
                    Microsoft.Office.Tools.StackStyle.FromBottom
            Else
                Globals.ThisWorkbook.ActionsPane.StackOrder =
                    Microsoft.Office.Tools.StackStyle.FromTop
            End If
        End If
    End Sub

    Private Sub ActionsPane_OrientationChanged(ByVal sender As Object,
        ByVal e As EventArgs)
        ResetStackOrder()
    End Sub

    ' Readjust the stack order so that it matches the current orientation.
    Sub ResetStackOrder()
        If Globals.ThisWorkbook.ActionsPane.Orientation =
            Orientation.Horizontal Then

            If (Globals.ThisWorkbook.ActionsPane.StackOrder =
            Microsoft.Office.Tools.StackStyle.FromTop Or
            Globals.ThisWorkbook.ActionsPane.StackOrder =
            Microsoft.Office.Tools.StackStyle.FromBottom) Then
                Globals.ThisWorkbook.ActionsPane.StackOrder =
                    Microsoft.Office.Tools.StackStyle.FromLeft
            End If
        End If

        If Globals.ThisWorkbook.ActionsPane.Orientation =
            Orientation.Vertical Then

            If (Globals.ThisWorkbook.ActionsPane.StackOrder =
            Microsoft.Office.Tools.StackStyle.FromLeft Or
            Globals.ThisWorkbook.ActionsPane.StackOrder =
            Microsoft.Office.Tools.StackStyle.FromRight) Then
                Globals.ThisWorkbook.ActionsPane.StackOrder =
                    Microsoft.Office.Tools.StackStyle.FromTop
            End If
        End If
    End Sub


    Public Sub button2_Click(ByVal sender As Object, ByVal e As EventArgs)

        ' CALCULATE
        Try
            hoja = app.ActiveSheet
            If pE Is Nothing Then
                pE = New ParseExcel(hoja)
            End If
            pE.DoAll(False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Function extrae(ByVal row As Int32, ByVal col As Int32) As Complex
        Dim cjo As New Complex
        Try
            cjo.pRe = New Rational(hoja.Cells(row, col).value, False)
        Catch ex As Exception

        End Try
        Return cjo
    End Function
    Private Sub function_Click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            If frmFn1 Is Nothing OrElse frmFn.bActivo = False Then
                frmFn1 = New frmFn
            End If
            frmFn1.wb = Me
            frmFn1.hoja = Me.Sheets(1)
            frmFn1.Show()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub clear_click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            hoja = app.ActiveSheet
            If pE Is Nothing Then
                pE = New ParseExcel(hoja)
            End If
            pE.DoAll(True)
        Catch ex As Exception

        End Try
    End Sub
End Class
