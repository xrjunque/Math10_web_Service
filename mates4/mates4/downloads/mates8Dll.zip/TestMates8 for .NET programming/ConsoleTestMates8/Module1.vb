﻿Imports m8 = mates8

Module Module1

    Dim N As Int32 = 1
    Sub Main()
        testMates8()
    End Sub
    Sub testMates8()
        Try
            Dim mP As New m8.matrixParser
            Dim sResult As String = ""
            Dim strVarsAndFns As String = ""
            Dim cfg As New m8.Config

            ' Set configuration for input data:
            cfg.bIgnoreSpaces = True
            cfg.bCaseSensitive = True
            cfg.bVarName1Char = True ' variables name length = 1 char (not 2 chars, unless preceeded by underscore _longName)
            cfg.bNumsInVarName = False ' var. name will not be, for ex. x1, y3 or z0        

            ' the following are examined only when 
            ' 'ToString" type methods are invoked:
            cfg.bEngNotation = True ' exponents multiples of 3 (10.3e3, 1.2e6, ...)
            cfg.bFractions = True
            cfg.bRounding = True ' round to 3 decimals 
            cfg.bDetail = False ' no detailed info
            cfg.Base = m8.MathGlobal8.outputBase.decimal
            cfg.timeOutms = 2000 ' 2 seconds timeout
            cfg.outputFormat = mates8.outputMsgFormat.plainText


            '     INPUT for matrixParser.Parse(strQuery,strVarsAndFns,oVars,cfg)
            '     ==============================
            '  (Only the first string parameter strQuery is mandatory, the other
            '  three may be omitted).
            '  1) strQuery = the math expression to parse,
            '     for example: strQuery="2*2", "2*x+3*x", "∫(cos(x))dx", "roots(x^16-1)"
            '                  or a matrix expression with columns delimited by
            '                  semicolons and rows by vbCrLf as "A^-1"
            '  2) strVarsAndFns = "" or eventualy variables values or functions
            '                    for ex. "x=-1" or  "A=2;3" + vbCrLf + "-1;2"
            '                    Dim oVars As VarsAndFns = Nothing
            '  3) oVars is a VarsAndFns object. Its finality is to store all the
            '    variables or custom functions contained in strQuery and/or strVarsAndFns.
            '    Each variable will have only one entry in oVars. For example, if
            '    strQuery is "z+x^2+3*x+y" then oVars.getNamesList will return a string
            '    array = {"z","x","y"}. Below you may find an example where oVars.setValue is
            '    used to evaluate an expression ("2x^2+5*y") with 2 variables.
            '   4) An instance, 'cfg', of Config class in order to determine how the input
            '    data will be parsed.

            '     OUTPUT:
            '     =======
            '     1) mP.toString(cfg) returns the result as a string.
            '     2) mP.retCjo() returns a complex or, eventually, an array of complex.
            '     3) When the result is a matrix
            '       xmP.ret.exprMtx.getExpr(row, column) returns the expression
            '       contained at a row and column ((0,0) is the first row and columns)

            ' mP.ret.exprMtx.getExpr(row, column).IsReal will tell
            ' if the element's content is a real number and 
            ' mP.ret.exprMtx.getExpr(row, column).toDouble its value.
            ' mP.ret.exprMtx.rows gives the number of rows in the matrix
            ' mP.ret.exprMtx.cols gives the # of columns

            ' As an exxmple, if we want the roots of x^16-1
            ' we equal strQuery="roots(x^16-1)", execute
            ' mP = matrixParser.parse(strQuery,"", nothing)
            ' and, at the output, the roots will be in mP.retCjo(); first, the real
            ' roots (if any) and then the complex (if any):
            ' 
            ' root1:  mp.retCjo(0)  ' = -1 (real)
            ' root2:  mp.retCjo(1)  ' =  1 (real)
            ' root2:  mp.retCjo(2)  ' = -i (complex)
            ' ...
            ' root16: mp.retCjo(15) ' = (0.923879532511287 -i*0.38268343236509) (complex)

            ' Real roots, in mP.retCjo(), are ordered from most negative to most positive.
            ' If a root is real and not complex, i.e. the imaginary value is zero, 
            ' mP.retCjo(0).IsReal will be True.


            Dim strQuery As String
            Dim oVars As m8.VarsAndFns = Nothing

            strQuery = "3&h+10.8" ' 3 plus hexadecimal 10.8 (=3+16.5=6/2+33/2=39/2 decimal)
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()

            strQuery = "Xc=1/(2*pi*f*_Capacity)"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            cfg.bUseUnits = True
            cfg.bVarName1Char = False ' Xc has 2 char length
            mP.parse(strQuery, "Xc=50Ohm|f=10 MHz", cfg:=cfg)
            cfg.bUseUnits = False
            cfg.bVarName1Char = True
            DisplaySolution(mP, cfg)
            nextSample()

            strQuery = "18x^2e^(18x)+2xe^(18x) = 0" ' solve the equation
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()

            'strQuery = "(x)/(15√(x^2+1600))+(x-100)/(6√((100-x)^2+3600)) =0" ' solve the equation
            'Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            'mP.parse(strQuery)
            'DisplaySolution(mP, cfg)
            'nextSample()

            'strQuery = "(x-2⅞)(x+2⅞)" ' operate
            'Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            'mP.parse(strQuery)
            'DisplaySolution(mP, cfg)
            'nextSample()

            'strQuery = "roots(det(A))@A=(1-x;2|3;2-x)" ' roots of matrix's A determinant
            'Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            'mP.parse(strQuery)
            'DisplaySolution(mP, cfg)
            'nextSample()

            strQuery = "roots(det(A-B))@A=(1,2|3,2)|B=_lambda*(1,0|0,1)" ' roots of matrix's A-B determinant
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()


            strQuery = "cof(A)@A=(1-x;2|3;2-x)" ' cofactor
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()


            strQuery = "adj(A)@A=(1-x;2|3;2-x)" ' adjoint
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()

            strQuery = "jordan(A)@A=(2,0,0,0|1,2,0,0|0,1,3,0|0,0,1,3)" ' Jordan form
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()



            strQuery = "√(12x+4+√(16x^4+40x^2+6x+10))=3+2x"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()

            'strQuery = "(1-z^3)/(1-z)"
            'Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            'mP.parse(strQuery)
            'DisplaySolution(mP, cfg)
            'nextSample()

            'strQuery = "(√(y-1)+1)* /* my comment */ (√(y-1)+1)"
            'Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            'mP.parse(strQuery)
            'DisplaySolution(mP, cfg)
            'nextSample()

            strQuery = "(integral(1/(x2+4x+4)2))"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()

            'strQuery = "integral(sin(at-ax)sin(ax))dx"
            'Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            'mP.parse(strQuery)
            'DisplaySolution(mP, cfg)
            'nextSample()

            'strQuery = "x(1-(1/x))^(x-1) - (x-1)x(1-(1/x))^(x-2)*(1/x)=0"
            'Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery) ' 2*x+3*x
            'mP.parse(strQuery)
            'DisplaySolution(mP, cfg)
            'nextSample()

            strQuery = "((y^2)(√y)+(y)(√y)+(√y)+y^2+y+1) / ((y^2)(√y)+(y)(√y)+(√y)+y^2+y+1)"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + vbCrLf + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()

            ' ********************************************************************

            '   Step by step arithmetic info:
            strQuery = "1600/((1-(1+1/4)^30)/(1-(1+1/4)))"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            cfg.bDetail = True ' 1) set to 'True'
            mP.parse(strQuery) ' 2) parse
            DisplaySolution(mP, cfg)
            cfg.outputFormat = mates8.outputMsgFormat.plainText ' 3)  set output type
            ' ... 5) ToStringDetail() returns an array of strings, join all into a string:
            Dim sDetail As String = Join(mates8.Detall.ToStringDetail(mP.getParser.cur, mP, cfg.oDetail), vbCrLf)
            Console.WriteLine("Detail:" + vbCrLf + sDetail) ' Display the detailed info.
            cfg.bDetail = False ' 6) Restore bDetail to no detail (detailing is more time consuming)
            nextSample()

            ' ********************************************************************



            strQuery = "1/0"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()

            ' Prefix for hexa numbers &h, for octal &o, binary prefixed by &b
            ' 255 as hexadecimal (&hFF),  logical optor. AND, 15 as hexa.(&hF)
            ' logical operators valid are "and", "or", "xor", "not", "nand", "nor"
            strQuery = "(&hff xor &hf)+3" ' ...and add 3 (decimal)
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()

            strQuery = "∫(cos(x))dx"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery) ' integral(cos(x))dx
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            nextSample()

            strQuery = "f(3)-f(2)"
            strVarsAndFns = "f(x)=x^2-1"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery + _
                    " where " + strVarsAndFns)
            mP.parse(strQuery, strVarsAndFns)
            DisplaySolution(mP, cfg)
            nextSample()

            cfg.bIgnoreSpaces = False ' carrige return (vbCrLf) must be considered
            strQuery = "A+B"
            ' semicolons (or comma) delimit columns, vbCrLf (or pipe |) delimits rows:
            strVarsAndFns = "A=2;3" + vbCrLf + "-1;-2" + vbCrLf + "B=6;5" + vbCrLf + " 3;2" ' watch for semicolons and vbCrLf
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery + " where " + strVarsAndFns) ' integral(cos(x))dx
            mP.parse(strQuery, strVarsAndFns)
            DisplaySolution(mP, cfg)
            Console.WriteLine("element at row 2, column 2 is: {0}", _
                              mP.ret.exprMtx.getExpr(1, 1).toDouble)
            nextSample()

            strQuery = "A*A^-1"
            strVarsAndFns = "A=2;3|-1;-2" ' "|" is also valid for row delimiter
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery + " where " + strVarsAndFns)
            mP.parse(strQuery, strVarsAndFns)
            DisplaySolution(mP, cfg)
            Console.WriteLine("element at row 2, column 2 is:  {0}", _
                              mP.ret.exprMtx.getExpr(1, 1).ToStringExpr(cfg))
            nextSample()

            strQuery = "A*A^-1*A"
            strVarsAndFns = "A=1;sin(x)|-sin(x);-1" ' "|" is also valid for row delimiter
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery + " where " + strVarsAndFns)
            mP.parse(strQuery, strVarsAndFns)
            DisplaySolution(mP, cfg)
            Console.WriteLine("element at row 2, column 1 is:  {0}", _
                              mP.ret.exprMtx.getExpr(1, 0).ToStringExpr(cfg))
            nextSample()

            strQuery = "A^-1"
            strVarsAndFns = "A=z;x|-2;3" + vbCrLf + "x=y+4"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery + " where " + strVarsAndFns)
            mP.parse(strQuery, strVarsAndFns)
            DisplaySolution(mP, cfg)
            Console.WriteLine("element at row 2, column 2 is:  {0}", _
                              mP.ret.exprMtx.getExpr(1, 1).ToStringExpr(cfg))
            nextSample()


            strQuery = "A*A^-1"
            strVarsAndFns = "A=z;x|-2;3" + vbCrLf + "x=y+4"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery + " where " + strVarsAndFns)
            mP.parse(strQuery, strVarsAndFns)
            DisplaySolution(mP, cfg)
            Console.WriteLine("element at row 2, column 2 is:  {0}", _
                              mP.ret.exprMtx.getExpr(1, 1).ToStringExpr(cfg))
            nextSample()


            strQuery = "A^-1*A"
            strVarsAndFns = "A=z;x|-2;3" + vbCrLf + "x=y+4"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery + " where " + strVarsAndFns)
            mP.parse(strQuery, strVarsAndFns)
            DisplaySolution(mP, cfg)
            Console.WriteLine("element at row 2, column 2 is:  {0}", _
                              mP.ret.exprMtx.getExpr(1, 1).ToStringExpr(cfg))
            nextSample()


            strQuery = "1,234 , 3|5,678 , 6|+|6 , 7|8 , 9"
            strVarsAndFns = "" ' "|" is also valid for row delimiter
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery) '+ " where " + strVarsAndFns)
            mP.parse(strQuery, strVarsAndFns)
            DisplaySolution(mP, cfg)
            Console.WriteLine("element at row 2, column 2 is:  {0}", _
                              mP.ret.exprMtx.getExpr(1, 1).ToStringExpr(cfg))
            nextSample()

            strQuery = "roots(x^16-1)"
            'strQuery = "roots((x-1)(x-2)(x-3)(x-4)(x-5)(x-6)(x-7)(x-8)(x-9)(x-10)(x-11)(x-12)(x-13)(x-14)(x-15)(x-16)(x-17)(x-18)(x-19))"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery) ' roots(x^16-1)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            Console.WriteLine("The 3rd. root is " + mP.retCjo(2).toStringComplex(cfg))
            nextSample()

            strQuery = "roots(6*x^5 -10*x^4 -18*x^3 +24*x^2 +14*x -12)"
            'strQuery = "roots((x-1)(x-2)(x-3)(x-4)(x-5)(x-6)(x-7)(x-8)(x-9)(x-10)(x-11)(x-12)(x-13)(x-14)(x-15)(x-16)(x-17)(x-18)(x-19))"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery) ' roots(x^16-1)
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)
            Console.WriteLine("The 4th. root is " + mP.retCjo(3).toString)
            nextSample()

            ' Now we want to evaluate "2x^2+5" for x=-1, x=2, x=3 and x=-i
            strQuery = "2x^2+5"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            ' 1) Call parse() method:
            mP.parse(strQuery)
            DisplaySolution(mP, cfg)

            ' 2) An AST tree has been created; call the evalExpression() method
            '    for each value of x:
            Console.Write("  Evaluating " + strQuery + ", for x=-1")
            Dim cmplx As m8.Complex = mP.ret.curExpr.evalExpression(New m8.Complex(-1))
            Console.WriteLine(": " + cmplx.toStringComplex(cfg)) ' = 7

            Console.Write("  Evaluating " + strQuery + ", for x=2")
            cmplx = mP.ret.curExpr.evalExpression(New m8.Complex(2))
            Console.WriteLine(": " + cmplx.toStringComplex(cfg)) ' = 13

            Console.Write("  Evaluating " + strQuery + ", for x=3")
            cmplx = mP.ret.curExpr.evalExpression(New m8.Complex(3))
            Console.WriteLine(": " + cmplx.toStringComplex(cfg)) ' = 23

            Console.Write("  Evaluating " + strQuery + ", for x=-i")
            ' note x= -i => real part= 0, imaginary= -1:
            cmplx = mP.ret.curExpr.evalExpression(New m8.Complex(0, -1))
            Console.WriteLine(": " + cmplx.toStringComplex(cfg)) ' = 3
            nextSample()

            strQuery = "2x^2+5*y"
            Console.WriteLine(N.ToString + ". Parsing and evaluating: " + strQuery)
            ' 1) Call parse() method:
            oVars = New mates8.VarsAndFns(cfg)
            mP.parse(strQuery, "", oVars)
            If mP.errMsg.Length Then
                Throw New Exception(mP.errMsg)
            End If

            Console.Write("  Evaluating " + strQuery + ", for x=1 and y=2")
            oVars.setValue(oVars.getVarIDByName("x"), _
                           New m8.ExprMatrix(New m8.Complex(1)))
            oVars.setValue(oVars.getVarIDByName("y"), _
                           New m8.ExprMatrix(New m8.Complex(2)))
            cmplx = mP.ret.curExpr.evalExpression(Nothing, oVars)
            Console.WriteLine(": " + cmplx.toStringComplex(cfg)) ' 2+10=12
            Console.WriteLine("")

            Console.WriteLine(" Multiply previous expression " + strQuery + " by 'Pi:'")
            Dim product As m8.Expression = _
                (New m8.Expression(Math.PI)) * mP.ret.curExpr
            Console.WriteLine("...* Pi = " + product.ToStringExpr(cfg)) ' 
            Console.WriteLine("")

            Console.WriteLine(" ... and multiply same expression " + strQuery + " by 'i*Pi:'")
            product = _
                (New m8.Expression(New m8.Complex(0, Math.PI))) * mP.ret.curExpr
            Console.WriteLine("...* i * Pi = " + product.ToStringExpr(cfg)) ' 
            Console.WriteLine("")
            nextSample()

            ' Custom functions:
            oVars.Clear()
            Dim msg As String = String.Empty
            Dim sF As String = "f(x,y)=sin(x)^y"
            Dim sG As String = "g(x)=x"
            If m8.VarsAndFns.tryParseVariables(sF, oVars, msg) AndAlso _
            m8.VarsAndFns.tryParseVariables(sG, oVars, msg) Then
                ' Now, both functions, f and g, are defined and contained in oVars instance.
                ' Get Ids for both (the postpending "(" in "f(" differentiates
                ' functions from variables:
                Dim id_f As Int32 = oVars.getVarIDByName("f(")
                Dim id_g As Int32 = oVars.getVarIDByName("g(")
                ' f could have been an exprMatrix object (a matrix with 
                ' expressions at its entries):
                Dim f As m8.Expression = oVars.getValueByID(id_f).getExpr(0, 0) ' get expression at entry (0,0)
                Dim g As m8.Expression = oVars.getValueByID(id_g).getExpr(0, 0)
                Dim f_Div_g As m8.Expression = f / g
                Dim xy As New m8.VarsAndFns(cfg)
                xy.AddVar("x", New m8.Expression(Math.PI / 2))
                xy.AddVar("y", New m8.Expression(2.0))
                Console.WriteLine("Defined " + sF + " and " + sG + ":")
                Console.WriteLine("Evaluation of f(pi/2,2):")
                Console.WriteLine(f.evalExprToExpr(xy).ToStringExpr(cfg))
                Console.WriteLine("Evaluation of f(-1,2)/g(-1):")
                xy.setValue(0, New m8.ExprMatrix(-1.0))
                Console.WriteLine(f_Div_g.evalExprToExpr(xy).ToStringExpr(cfg))
            Else
                Console.WriteLine("Couldn't define function f or g")
            End If
            nextSample()

            ' For simple expressions, you may use the
            ' following shortcut (note: there is no syntax checking
            ' in parseExpression() method!):
            Dim myExpression As m8.Expression = m8.Expression.parseExpression("x^2+2*x+2")
            Dim myRoots() As m8.Complex = m8.Polynomial.opRoots(myExpression.getPolynomial).cjo
            Console.WriteLine("The roots of x^2+2*x+2 are:")
            For i As Int32 = 0 To myRoots.Length - 1
                Console.WriteLine(myRoots(i).toStringComplex(cfg))
            Next
            nextSample()

            strQuery = "x^2+(2*cos(x)+2)*3"
            Dim myExpressionB As m8.Expression = m8.Expression.parseExpression(strQuery)
            Console.WriteLine("Evaluation of " + strQuery + " at x=0 is:")
            Console.WriteLine(myExpressionB.eval_1var_DblToCjo(0).toStringComplex(cfg))
            nextSample()

            Console.WriteLine("Parse and evaluate -1^2 - (-3 + 12) ^ 0.5:")
            Console.WriteLine(m8.Expression.parseExpression("-1^2 - (-3 + 12) ^ 0.5").ToStringExpr(New m8.Config))
            nextSample()

            Console.WriteLine("Version:")
            Console.WriteLine(mates8.MathGlobal8.NameAndVersion)
            Console.WriteLine("")


        Catch ex As Exception
            Console.WriteLine(ex.ToString)
        End Try
        Console.WriteLine("Press 'Enter' to exit.")
        Console.ReadLine()
    End Sub
    Sub nextSample()
        Console.WriteLine(vbCrLf + "--------------------" + vbCrLf)
        N += 1
    End Sub
    Sub DisplaySolution(ByVal mP As m8.matrixParser, ByVal cfg As m8.Config)
        Try
            Console.WriteLine("Result: ") ' + mP.ToString) 
            If mP.errMsg.Length Then
                Console.WriteLine(mP.errMsg)
            Else
                Console.WriteLine(mP.ToString(cfg))
            End If
            Console.WriteLine("")
        Catch ex As Exception

        End Try
    End Sub
End Module
